USE [master]
GO
CREATE DATABASE [hammerdb_250a] ON 
( FILENAME = N'E:\SQL_Data\hammerdb_250.mdf' ),
( FILENAME = N'F:\SQL_Logs\hammerdb_250_log.ldf' )
 FOR ATTACH
GO

USE hammerdb_250a;
GO
SELECT file_id, name as [logical_file_name], physical_name
FROM sys.database_files

USE [master];
GO
--Disconnect all existing session.
ALTER DATABASE hammerdb_250a SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
--Change database in to OFFLINE mode.
ALTER DATABASE hammerdb_250a SET OFFLINE

ALTER DATABASE hammerdb_250a MODIFY FILE (Name='hammerdb_250a', FILENAME='E:\SQL_Data\hammerdb_250a.mdf')
GO
ALTER DATABASE hammerdb_250a MODIFY FILE (Name='hammerdb_250a_log', FILENAME='F:\SQL_Logs\hammerdb_250a_log.ldf')
GO


ALTER DATABASE hammerdb_250a SET ONLINE
Go
ALTER DATABASE hammerdb_250a SET MULTI_USER
Go