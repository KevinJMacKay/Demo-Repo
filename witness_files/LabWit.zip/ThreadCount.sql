--https://www.mssqltips.com/sqlservertip/3198/monitoring-sql-server-2012-capture-and-parse-spserverdiagnostics-output/
USE tempdb
IF OBJECT_ID(N'#ServerStats', N'U') IS NOT NULL  
   DROP TABLE #ServerStats;  
GO

CREATE TABLE #ServerStats (create_time datetime,
                           component_type sysname,
                           component_name sysname,
                           state int,
                           state_desc sysname,
                           data xml)
INSERT INTO #ServerStats execute sp_server_diagnostics

select 
	(Select count(*) from sys.databases where replica_id is not NULL) DB_Count,
       data.value('(/queryProcessing/@maxWorkers)[1]','bigint') as "MaxWorkers",
       data.value('(/queryProcessing/@workersCreated)[1]','bigint') as "WorkersCreated",
       data.value('(/queryProcessing/@workersIdle)[1]','bigint') as "WorkersIdles"
  from #ServerStats 
 where component_name in ('query_processing')
 
 
 /*
DB_Count	MaxWorkers	WorkersCreated	WorkersIdles
10	704	170	56
30	704	264	50
50	704	346	66
75	704	453	54
100	704	511	63
110	704	538	73
106	704	607	143
failover to 466
106	512	554	20
failover to 467

*/