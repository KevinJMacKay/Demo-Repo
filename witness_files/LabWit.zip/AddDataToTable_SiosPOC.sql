INSERT INTO SIOSTest1..sios_table1
select @@version,Getdate()
go 100

select Count(*) from SIOSTest1..sios_table1