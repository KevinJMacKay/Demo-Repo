USE [master]
RESTORE DATABASE [snhudevlms] FROM  DISK = N'V:\SQL_Backups\snhudevlms\snhudevlms_FULL_2023_5_8__05_01_29_LAB1APSQLX509.bak' WITH  FILE = 1, 
MOVE N'Demeter-B-Core_base_base_main' TO N'E:\SQL_Data\snhudevlms.mdf',  
MOVE N'Demeter-B-Core_base_base_main_log' TO N'F:\SQL_Logs\snhudevlms_Log.ldf',  NOUNLOAD,  STATS = 5,  NORECOVERY 
--07:43:55
--05:10:33

RESTORE DATABASE [snhudevlms_lor] FROM  DISK = N'V:\SQL_Backups\snhudevlms_lor\snhudevlms_lor_FULL_2023_5_8__05_01_27_LAB1APSQLX509.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'dev_workspace0_lor' TO N'E:\SQL_Data\snhudevlms_lor.mdf'  ,MOVE N'dev_workspace0_lor_log' TO N'F:\SQL_Logs\snhudevlms_lor_Log.ldf'
RESTORE DATABASE [snhudevlms_reporting] FROM  DISK = N'V:\SQL_Backups\snhudevlms_reporting\snhudevlms_reporting_FULL_2023_5_8__05_01_26_LAB1APSQLX509.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'dev_workspace0_reporting' TO N'E:\SQL_Data\snhudevlms_reporting.mdf'  ,MOVE N'dev_workspace0_reporting_log' TO N'F:\SQL_Logs\snhudevlms_reporting_Log.ldf'
RESTORE DATABASE [snhudevlms_warehouse] FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse\snhudevlms_warehouse_FULL_2023_5_8__05_01_24_LAB1APSQLX509.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'dev_workspace0_warehouse' TO N'E:\SQL_Data\snhudevlms_warehouse.mdf'  ,MOVE N'dev_workspace0_warehouse_log' TO N'F:\SQL_Logs\snhudevlms_warehouse_Log.ldf'
--00:00:02

RESTORE DATABASE [snhudevlms]
RESTORE DATABASE [snhudevlms_lor]
RESTORE DATABASE [snhudevlms_reporting]
RESTORE DATABASE [snhudevlms_warehouse]


-- Login: snhudevlms_sqluser
CREATE LOGIN [snhudevlms_sqluser] WITH PASSWORD = 0x0200FCF45E8C256D843634C63D3E0E1A32E560798D17D7354DEFEAC8EBEBD6BD121C23F4FA4D28E0AD97EE2B7E5D036448EAD39AA6B6818B8008AD91E5ED345AC669AE66FC4A HASHED, SID = 0x0854BF8A1225634887619EB52DE9F761, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF

-- Login: rhu\SQL_RW_Only
CREATE LOGIN [rhu\SQL_RW_Only] FROM WINDOWS WITH DEFAULT_DATABASE = [master]

-- Login: RHU\lab_SQL_RO
CREATE LOGIN [RHU\lab_SQL_RO] FROM WINDOWS WITH DEFAULT_DATABASE = [master]
 
-- Login: lab\lab_SQL_Engine
CREATE LOGIN [lab\lab_SQL_Engine] FROM WINDOWS WITH DEFAULT_DATABASE = [master]
 




 
