BACKUP DATABASE [model] TO  DISK = N'E:\SQL_Backups\model.bak' WITH NOFORMAT, NOINIT,  NAME = N'model-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

RESTORE HEADERONLY FROM DISK = 'X:\SQL_Backups\Temp\snhudevlms_FULL_2023_3_20__05_02_34_LAB1APSQLT509.bak'
GO
RESTORE FILELISTONLY FROM DISK = 'X:\SQL_Backups\Temp\snhudevlms_FULL_2023_3_20__05_02_34_LAB1APSQLT509.bak'
GO
RESTORE LABELONLY FROM DISK = 'X:\SQL_Backups\Temp\snhudevlms_FULL_2023_3_20__05_02_34_LAB1APSQLT509.bak'
GO

select * from sys.databases

USE [master]
RESTORE DATABASE [snhudevlms2] FROM  DISK = N'X:\SQL_Backups\Temp\snhudevlms_FULL_2023_3_20__05_02_34_LAB1APSQLT509.bak' WITH  FILE = 1,  
MOVE N'Demeter-B-Core_base_base_main' TO N'E:\SQL_Data\snhudevlms2.mdf',  
MOVE N'Demeter-B-Core_base_base_main_log' TO N'F:\SQL_Logs\snhudevlms_Log2.ldf', NOUNLOAD,  STATS = 5
--01:10:24 [snhudevlms]
--01:10:30 [snhudevlms2]

BACKUP DATABASE [snhudevlms] TO  DISK = N'X:\SQL_Backups\FULL\snhudevlms_FULL_2023_3_24_14_15_LAB1APSQLT453.bak' WITH STATS = 5
--1:43:09 - ebs @ 512 MB/s fsx @ 512 MB/s - RESTORE DATABASE successfully processed 299284984 pages in 4226.684 seconds (553.191 MB/sec)
--1:56:18 - ebs @ 1000 MB/s fsx @ 1024 MB/s (in grogress) ( Requested 2023-03-24 13:56:59 - Completed 14:35 @ 20 min point of backup)
--BACKUP DATABASE successfully processed 299275902 pages in 6976.395 seconds (335.143 MB/sec).