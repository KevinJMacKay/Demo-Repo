--https://www.mssqltips.com/sqlservertip/3198/monitoring-sql-server-2012-capture-and-parse-spserverdiagnostics-output/


Drop table #ServerStats
CREATE TABLE #ServerStats (create_time datetime,
                           component_type sysname,
                           component_name sysname,
                           state int,
                           state_desc sysname,
                           data xml)
INSERT INTO #ServerStats execute sp_server_diagnostics

--SELECT create_time as "Date",
--       component_name as "Component",
--       state_desc as "Status",
--	   data
-- FROM #ServerStats

select 'queryProcessing' as "query_processing",
       data.value('(/queryProcessing/@maxWorkers)[1]','bigint') as "MaxWorkers",
       data.value('(/queryProcessing/@workersCreated)[1]','bigint') as "WorkersCreated",
       data.value('(/queryProcessing/@workersIdle)[1]','bigint') as "WorkersIdles"
  from #ServerStats 
 where component_name in ('query_processing')


