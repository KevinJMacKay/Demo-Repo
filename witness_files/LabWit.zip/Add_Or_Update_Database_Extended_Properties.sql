--------------Make Changes Here------------------
 
--'Enter Database Name Here'
DECLARE @DatabaseName SYSNAME = 'Stats'
--'Enter CName Value Here or Empty String'
DECLARE @CNameValue NVARCHAR(4000) = ''
--'Enter Instance Name Here or Empty String'
DECLARE @InstanceValue NVARCHAR(4000) = ''
--'Enter Split Value Here or Empty String'
DECLARE @SplitValue NVARCHAR(4000) = ''

--------------Stop Making Changes Here-----------

DECLARE @SQLCmd NVARCHAR(MAX)

SET @SQLCmd = 
'
BEGIN TRY
	EXEC [' + @DatabaseName + '].sys.sp_addextendedproperty @name=N''cname'', @value=N''' + @CNameValue + ''';
	EXEC [' + @DatabaseName + '].sys.sp_addextendedproperty @name=N''instance'', @value=N''' + @InstanceValue + ''';
	EXEC [' + @DatabaseName + '].sys.sp_addextendedproperty @name=N''split'', @value=N''' + @SplitValue + ''';
END TRY
BEGIN CATCH
	EXEC [' + @DatabaseName + '].sys.sp_updateextendedproperty @name=N''cname'', @value=N''' + @CNameValue + ''';
	EXEC [' + @DatabaseName + '].sys.sp_updateextendedproperty @name=N''instance'', @value=N''' + @InstanceValue + ''';
	EXEC [' + @DatabaseName + '].sys.sp_updateextendedproperty @name=N''split'', @value=N''' + @SplitValue + ''';
END CATCH
'
--SELECT @SQLCmd

EXEC(@SQLCmd)