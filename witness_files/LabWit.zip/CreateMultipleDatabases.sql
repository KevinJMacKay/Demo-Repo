DECLARE @statement as nvarchar(max)

CREATE TABLE #db_names(dbname varchar(250))

declare @id int 
select @id = 1
while @id >=1 and @id <= 100
begin
    insert into #db_names  values('Database_' + convert(varchar(5), @id))
    select @id = @id + 1
end

--select * from #db_names

SELECT 'CREATE DATABASE [' + dbname + '];' FROM #db_names
select 'BACKUP DATABASE [' + dbname + '] TO  DISK = N''V:\SQL_Backups\' + dbname + '.bak'' WITH STATS = 10'  FROM #db_names

drop table #db_names



