USE [master]
GO

ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = [dbo].[ResourceGovernorClassifier]);
GO

ALTER RESOURCE GOVERNOR WITH (MAX_OUTSTANDING_IO_PER_VOLUME = DEFAULT);
GO

ALTER RESOURCE GOVERNOR RECONFIGURE;
GO


USE [master]
GO

/****** Object:  ResourcePool [SwartPool]    Script Date: 7/17/2023 2:14:29 PM ******/
CREATE RESOURCE POOL [SwartPool] WITH(min_cpu_percent=0, 
		max_cpu_percent=100, 
		min_memory_percent=0, 
		max_memory_percent=100, 
		cap_cpu_percent=100, 
		AFFINITY SCHEDULER = AUTO
, 
		min_iops_per_volume=0, 
		max_iops_per_volume=40)
GO

USE [master]
GO

/****** Object:  WorkloadGroup [SwartGroup]    Script Date: 7/17/2023 2:17:04 PM ******/
CREATE WORKLOAD GROUP [SwartGroup] WITH(group_max_requests=0, 
		importance=Medium, 
		request_max_cpu_time_sec=0, 
		request_max_memory_grant_percent=25, 
		request_memory_grant_timeout_sec=0, 
		max_dop=0) USING [SwartPool], EXTERNAL [default]
GO



USE [master]
GO

/****** Object:  ResourcePool [default]    Script Date: 7/17/2023 2:15:51 PM ******/
ALTER RESOURCE POOL [default] WITH(min_cpu_percent=0, 
		max_cpu_percent=100, 
		min_memory_percent=0, 
		max_memory_percent=100, 
		cap_cpu_percent=100, 
		AFFINITY SCHEDULER = AUTO
, 
		min_iops_per_volume=0, 
		max_iops_per_volume=0)
GO
USE [master]
GO

/****** Object:  WorkloadGroup [default]    Script Date: 7/17/2023 2:16:13 PM ******/
ALTER WORKLOAD GROUP [default] WITH(group_max_requests=0, 
		importance=Medium, 
		request_max_cpu_time_sec=0, 
		request_max_memory_grant_percent=25, 
		request_memory_grant_timeout_sec=0, 
		max_dop=0)
GO



/****** Object:  ExternalResourcePool [default]    Script Date: 7/17/2023 2:15:26 PM ******/
ALTER EXTERNAL RESOURCE POOL [default] WITH (AFFINITY CPU = AUTO
)
GO

