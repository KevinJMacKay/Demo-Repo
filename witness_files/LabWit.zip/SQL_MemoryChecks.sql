SELECT
  database_id AS DatabaseID,
  DB_NAME(database_id) AS DatabaseName,
  COUNT(file_id) * 8/1024.0 AS BufferSizeInMB
FROM sys.dm_os_buffer_descriptors
GROUP BY DB_NAME(database_id),database_id
ORDER BY BufferSizeInMB DESC
GO 

SELECT 
  CASE WHEN database_id = 32767 THEN 'ResourceDB' ELSE DB_NAME(database_id) END AS DatabaseName,
  COUNT(*) AS cached_pages,
  (COUNT(*) * 8.0) / 1024 AS MBsInBufferPool
FROM  sys.dm_os_buffer_descriptors
GROUP BY  database_id
ORDER BY  MBsInBufferPool DESC
GO


SELECT * FROM sys.dm_os_buffer_descriptors

SELECT TOP(5) [type] AS [ClerkType],
SUM(pages_kb) / 1024 AS [SizeMb]
FROM sys.dm_os_memory_clerks WITH (NOLOCK)
GROUP BY [type]
ORDER BY SUM(pages_kb) DESC

checkpoint

sp_whoisactive

--The following query returns information about currently allocated memory:
SELECT
  physical_memory_in_use_kb/1024/1024 AS sql_physical_memory_in_use_MB,
    large_page_allocations_kb/1024/1024 AS sql_large_page_allocations_MB,
    locked_page_allocations_kb/1024/1024 AS sql_locked_page_allocations_MB,
    virtual_address_space_reserved_kb/1024/1024 AS sql_VAS_reserved_MB,
    virtual_address_space_committed_kb/1024/1024 AS sql_VAS_committed_MB,
    virtual_address_space_available_kb/1024/1024 AS sql_VAS_available_MB,
    page_fault_count AS sql_page_fault_count,
    memory_utilization_percentage AS sql_memory_utilization_percentage,
    process_physical_memory_low AS sql_process_physical_memory_low,
    process_virtual_memory_low AS sql_process_virtual_memory_low
FROM sys.dm_os_process_memory;


select physical_memory_kb/1024/1024 AS PhysicalMem_GB,
committed_kb/1024/1024 AS CommitMem_GB,
committed_target_kb/1024/1024 AS CommitMemTarget_GB
from sys.dm_os_sys_info 

Select * from sys.dm_os_sys_memory
Select * from sys.dm_os_sys_info 

SELECT session_id, requested_memory_kb / 1024 as RequestedMemMb, 
granted_memory_kb / 1024 as GrantedMemMb, text
FROM sys.dm_exec_query_memory_grants qmg
CROSS APPLY sys.dm_exec_sql_text(sql_handle)

select * FROM sys.dm_os_buffer_descriptors 

SELECT TOP 5 DB_NAME(database_id) AS [Database Name],
COUNT(*) * 8/1024.0 AS [Cached Size (MB)]
FROM sys.dm_os_buffer_descriptors WITH (NOLOCK)
GROUP BY DB_NAME(database_id)
ORDER BY [Cached Size (MB)] DESC OPTION (RECOMPILE);


SELECT COUNT(1)/128 AS megabytes_in_cache
,name ,index_id
FROM sys.dm_os_buffer_descriptors AS bd
INNER JOIN
(
SELECT object_name(object_id) AS name
,index_id ,allocation_unit_id
FROM sys.allocation_units AS au
INNER JOIN sys.partitions AS p
ON au.container_id = p.hobt_id
AND (au.type = 1 OR au.type = 3)
UNION ALL
SELECT object_name(object_id) AS name
,index_id, allocation_unit_id
FROM sys.allocation_units AS au
INNER JOIN sys.partitions AS p
ON au.container_id = p.partition_id
AND au.type = 2
) AS obj
ON bd.allocation_unit_id = obj.allocation_unit_id
WHERE database_id = DB_ID()
GROUP BY name, index_id
ORDER BY megabytes_in_cache DESC;