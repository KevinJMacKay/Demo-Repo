sp_server_diagnostics

select * from sys.databases

/*
Lab1APSQLR467 - r5.4xlarge 704 max
WorkersCreated
112
Add 100 dbs and ags
534
Add 100 dbs and ags
1508 idle 1380
*/