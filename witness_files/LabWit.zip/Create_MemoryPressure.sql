SELECT TOP (1000000)
	DISCUSSION_POSTS.Title AS Title,
	DISCUSSION_POSTS.Body AS body,
	USERs.FirstName as First
FROM DISCUSSION_POSTS
INNER JOIN USERS ON DISCUSSION_POSTS.PostingUserId=USERS.UserId
WHERE Title Like '%test%'

--or

DECLARE @sometable table (id uniqueidentifier)
insert into @sometable
SELECT NEWID()
FROM sys.columns A
CROSS JOIN sys.columns B
CROSS JOIN sys.columns C