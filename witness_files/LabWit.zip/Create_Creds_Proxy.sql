USE [master]
GO
CREATE CREDENTIAL [TaskAdmin] WITH IDENTITY = N'LAB\DBA_TaskAdmin', SECRET = N'!@$%^&*(2121#$%^&@!The'
GO
--DROP CREDENTIAL [TaskAdmin]



USE [msdb]
GO

/****** Object:  Operator [SQL Admin]    Script Date: 6/21/2023 6:34:49 PM ******/
EXEC msdb.dbo.sp_add_operator @name=N'SQL Admin', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'd2ldba@desire2learn.com', 
		@category_name=N'[Uncategorized]'
GO


USE [msdb]
GO
--EXEC msdb.dbo.sp_delete_proxy @proxy_name=N'TaskAdmin'

/****** Object:  ProxyAccount [TaskAdmin]    Script Date: 6/21/2023 6:35:19 PM ******/
EXEC msdb.dbo.sp_add_proxy @proxy_name=N'TaskAdmin',@credential_name=N'TaskAdmin', 
		@enabled=1
GO

EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'TaskAdmin', @subsystem_id=3
GO

EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'TaskAdmin', @subsystem_id=11
GO

EXEC msdb.dbo.sp_grant_proxy_to_subsystem @proxy_name=N'TaskAdmin', @subsystem_id=12
GO

