:Connect LAB1APSQLX466
BACKUP DATABASE snhudevlms_warehouse TO  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak' WITH  STATS = 10
BACKUP DATABASE snhudevlms_warehouse TO  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak' WITH  DIFFERENTIAL ,  STATS = 10
BACKUP LOG snhudevlms_warehouse TO  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak' WITH STATS = 10
RESTORE filelistonly FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak'
RESTORE Headeronly FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak'

:Connect LAB1APSQLX467
RESTORE DATABASE snhudevlms_warehouse FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE snhudevlms_warehouse FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.BAK' WITH FILE = 2, STATS = 5, NORECOVERY
RESTORE DATABASE snhudevlms_warehouse FROM  DISK = N'V:\SQL_Backups\snhudevlms_warehouse.BAK' WITH FILE = 3, STATS = 5, NORECOVERY

ALTER DATABASE [snhudevlms_warehouse] SET HADR AVAILABILITY GROUP = [snhudevlms_warehouse_ag];
GO


