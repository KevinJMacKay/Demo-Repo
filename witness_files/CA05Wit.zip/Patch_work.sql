--check	
Select @@servername
select * from sys.databases
where state_desc <>'Online'
OR  user_access_desc <>'MULTI_USER'

select db_name(database_id),synchronization_state_desc from sys.dm_hadr_database_replica_states 
where synchronization_state_desc <> 'NOT SYNCHRONIZING'

ALTER LOGIN [nautest_SQLUser] DISABLE
GO

USE [master]
GO
ALTER DATABASE [nautest] SET  Multi_USER WITH NO_WAIT
GO

ALTER LOGIN [nautest_SQLUser] Enable
GO

