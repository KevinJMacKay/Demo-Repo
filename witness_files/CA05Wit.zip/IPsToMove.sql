--Ip's to move.
select [dns_name],[ip_address] from sys.availability_group_listeners agl
inner join sys.availability_group_listener_ip_addresses aglip
on agl.listener_id = aglip.listener_id
where state_desc = 'OFFLINE'
order by ip_address asc