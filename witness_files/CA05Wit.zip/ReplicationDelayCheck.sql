SELECT d.[name]
,(log_send_queue_size / 1024) as [Log_Send_Queue_(MB)]
,(redo_queue_size / 1024) as [Redo_Send_Queue_(MB)]
,(redo_rate / 1024) as [Redo_Rate_(MB)]
,last_commit_time,(log_send_rate / 1024) as [Log_Send_Rate_(MB)]
,CASE 
	WHEN log_send_rate <= 0
	THEN NULL
	ELSE (log_send_queue_size / log_send_rate) / 60 
	END as [Time_Until_Up_To_Date_(Minutes)]
,(DATEDIFF(hour, (GetDate()), last_commit_time)) AS [HoursBehind]
FROM   [master].[sys].[dm_hadr_database_replica_states] drs
inner join sys.databases d
on d.database_id = drs.database_id
where [name] = 'elo'