DECLARE @db_nm AS SYSNAME
SET @db_nm = 'sql_trace'

SELECT s.database_name as 'Database Name', 
m.physical_device_name as 'Backup Path', 
cast(s.backup_size/1000000 as nvarchar(1000))+' '+'MB' as 'Backup Size', 
CAST (DATEDIFF(second,s.backup_start_date , s.backup_finish_date)AS NVARCHAR(1000))+' '+'Seconds' TimeTaken,
s.backup_start_date as 'Backup Start Date', 
CASE s.[type] 
WHEN 'D' THEN 'Full'
WHEN 'I' THEN 'Differential'
WHEN 'L' THEN 'Transaction Log'
END as 'Backup Type', 
CASE s.is_copy_only
WHEN 1 THEN 'Yes'
WHEN 0 THEN 'No'
END as 'Copy-Only',
s.server_name as 'SQL Instance', 
s.recovery_model as 'Recovery Model'
FROM msdb.dbo.backupset s 
inner join msdb.dbo.backupmediafamily m
ON s.media_set_id = m.media_set_id
WHERE s.database_name = @db_nm
AND ( s.[Type] = 'D'
OR s.[Type] = 'I'
--OR s.[Type] = 'L'
)
ORDER BY backup_start_date desc

