/*
--DBCC FREEPROCCACHE (0x05000A000A17CC6DC01D13AFD101000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x06000B0006BAA40010E6A4DCF301000001000000000000000000000000000000000000000000000000000000)
--s_LE_DISCUSSIONS_FetchDiscussionTopicsByOrgUnitId_v2

select * from sys.dm_exec_query_plan(0x0200000073D1103753B26AE0553EA4983DD26F64A8768E7C0000000000000000000000000000000000000000)  

DBCC FREEPROCCACHE (0x06000500B9D9892E30D6F3A01A02000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x06000500003C1C34B07D7DAE1202000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x05007300CE5E2869303F7D8D2002000001000000000000000000000000000000000000000000000000000000)

*/

WITH SystemIO AS
(
      SELECT 
            SUM(total_worker_time) AS [totalSystemCPU],
            SUM(execution_count) AS [totalExecutionsInCache]
      FROM sys.dm_exec_query_stats
),
TopTwenty AS
(
      SELECT TOP 20 
            [Row Number] = ROW_NUMBER() OVER (ORDER BY total_worker_time DESC),
            [Query Text] = CASE 
                  WHEN [sql_handle] IS NULL THEN ' '
                  ELSE (SUBSTRING(ST.TEXT,(QS.statement_start_offset + 2) / 2,
                        (CASE 
                              WHEN QS.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX),ST.text)) * 2
                              ELSE QS.statement_end_offset
                              END - QS.statement_start_offset) / 2))
                  END,
            [Execution Count] = execution_count,
            [Total CPU] = total_worker_time,
            [DB Name] = DB_NAME(ST.dbid),
            [Object Name] = OBJECT_NAME(ST.objectid, ST.dbid),
            [SQL Handle] = [sql_handle],
            [Plan Handle] = [plan_handle]
      FROM sys.dm_exec_query_stats QS
      CROSS APPLY sys.dm_exec_sql_text ([sql_handle]) ST
      WHERE total_worker_time > 0
      ORDER BY [Row Number] ASC
)
SELECT [totalSystemCPU], [totalExecutionsInCache],
      T20.[Row Number], T20.[Query Text], T20.[Execution Count], T20.[Total CPU], 
      T20.[DB Name], T20.[Object Name], T20.[SQL Handle],
      [Average CPU] = T20.[Total CPU] / (T20.[Execution Count] + 0.0),
      [System Percentage] = 100.0 * T20.[Total CPU] / ([totalSystemCPU]+0.0),
      [Cumulative Percentage] = 100.0 * SUM(T20_secondary.[Total CPU]) / ([totalSystemCPU]+0.0),
      [Max CPU] = MAX(T20_secondary.[Total CPU]),
      T20.[Plan Handle],
	  'DBCC FREEPROCCACHE ('+CONVERT(VARCHAR(1000), T20.[plan handle], 1)+')' AS RecompileScript
FROM TopTwenty T20
JOIN TopTwenty T20_secondary
      ON T20.[Row Number] >= T20_secondary.[Row Number]
CROSS JOIN SystemIO SIO
GROUP BY [totalSystemCPU], [totalExecutionsInCache], 
      T20.[Row Number],
      T20.[Query Text],
      T20.[Execution Count],
      T20.[Total CPU],
      T20.[DB Name],
      T20.[Object Name],
      T20.[SQL Handle],
      T20.[Plan Handle]

/*

SELECT TOP 30 SUBSTRING(qt.TEXT, (qs.statement_start_offset/2)+1,
((CASE qs.statement_end_offset
WHEN -1 THEN DATALENGTH(qt.TEXT)
ELSE qs.statement_end_offset
END - qs.statement_start_offset)/2)+1),
qs.execution_count,
qs.total_logical_reads, qs.last_logical_reads,
qs.total_logical_writes, qs.last_logical_writes,
qs.total_worker_time,
qs.last_worker_time,
qs.total_elapsed_time/1000000 total_elapsed_time_in_S,
qs.last_elapsed_time/1000000 last_elapsed_time_in_S,
qs.last_execution_time,
qp.query_plan
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
--ORDER BY qs.total_logical_reads DESC -- logical reads
-- ORDER BY qs.total_logical_writes DESC -- logical writes
 ORDER BY qs.total_worker_time DESC -- CPU time
*/