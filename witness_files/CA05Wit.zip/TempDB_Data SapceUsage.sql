USE tempdb
select
[TotalDataSize(MB)] =
        sum(convert(numeric(10,2),round(a.size/128.,2))),
[DataSpaceUsed(MB)] =
        sum(convert(numeric(10,2),round(fileproperty( a.name,'SpaceUsed')/128.,2))) ,
[DataSpaceUsed%] =
((sum(convert(numeric(10,2),round(fileproperty( a.name,'SpaceUsed')/128.,2)))) / (sum(convert(numeric(10,2),round(a.size/128.,2))))) * 100 ,
[DatabaseName] = db_name()
from
sysfiles a
where a.[groupid] = 1

--EXEC ('DBCC SQLPERF(logspace)')