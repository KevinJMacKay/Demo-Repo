SELECT AGC.name as 'AvailabilityGroup', 'ALTER DATABASE ['+d.name+'] SET HADR OFF;',
'ALTER AVAILABILITY GROUP ['+AGC.name+'] REMOVE DATABASE ['+d.name+'];'
FROM
sys.availability_groups_cluster AS AGC
INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS
ON AGC.group_id = RCS.group_id
INNER JOIN sys.dm_hadr_availability_replica_states AS ARS
ON ARS.replica_id = RCS.replica_id
INNER JOIN sys.availability_group_listeners AS AGL
ON AGL.group_id = ARS.group_id
INNER JOIN sys.availability_replicas AS AR
ON AR.replica_id=RCS.replica_id
left JOIN sys.databases AS D
ON ARS.replica_id = D.replica_id
WHERE 1=1
--AND AGC.name = '$AG'
--AND AR.replica_metadata_id is not NULL
--AND d.name in ( select name from sys.databases where 
--name like '%instance%' 
--)
Group by AGC.name,ARS.role_desc,AR.[availability_mode],AGL.dns_name, d.name

		
	/*	
SELECT AGC.name as 'AvailabilityGroup', 'ALTER DATABASE ['+d.name+'] SET HADR OFF;',
		'ALTER AVAILABILITY GROUP ['+AGC.name+'] REMOVE DATABASE ['+d.name+'];',
		'DROP DATABASE ['+d.[name]+'];'
		FROM
		sys.availability_groups_cluster AS AGC
		INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS
		ON AGC.group_id = RCS.group_id
		INNER JOIN sys.dm_hadr_availability_replica_states AS ARS
		ON ARS.replica_id = RCS.replica_id
		INNER JOIN sys.availability_group_listeners AS AGL
		ON AGL.group_id = ARS.group_id
		INNER JOIN sys.availability_replicas AS AR
		ON AR.replica_id=RCS.replica_id
		left JOIN sys.databases AS D
		ON ARS.replica_id = D.replica_id
		WHERE 1=1
		AND AGC.name in ('US04PSQL001-AGRPT29','US04PSQL001-AGRPT04','US04PSQL001-AGRPT05','US04PSQL001-AGRPT20')
		AND AR.replica_metadata_id is not NULL
		Group by AGC.name,ARS.role_desc,AR.[availability_mode],AGL.dns_name, d.name

'US04PSQL001-AGRPT29','US04PSQL001-AGRPT04','US04PSQL001-AGRPT05','US04PSQL001-AGRPT20'



	


*/