--Compatible with SQL 2014 / 2016

--FULL restore
/*
--Use this one...
Get-Childitem -Path Z:\SQL_Backups\Temp -Recurse |  where {$_.extension -eq ".bak" -OR $_.extension -eq ".trn"} | ForEach-Object  {$a = $_.fullname ; "('$a'),"}
Get-Childitem -Path T:\TELO\ -Recurse  | ForEach-Object  {$a = $_.fullname ; "('$a'),"}
*/

IF OBJECT_ID (N'tempdb..#tmp') IS NOT NULL Drop table #tmp
IF OBJECT_ID (N'tempdb..#Results') IS NOT NULL Drop table #Results
IF OBJECT_ID (N'tempdb..#BackupPaths') IS NOT NULL Drop table #BackupPaths
IF OBJECT_ID (N'tempdb..#HeaderTable') IS NOT NULL Drop table #HeaderTable

create table #BackupPaths
(Path varchar(555) null)

insert into #BackupPaths
values
-----------------------paste backup paths below (including filename)-----test------------------


('Z:\SQL_Backups\Temp\algonquincollege\algonquincollege_FULL_2019_10_14__12_45_19_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\algonquincollege_lor\algonquincollege_lor_FULL_2019_10_14__12_45_18_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\algonquincollege_reporting\algonquincollege_reporting_FULL_2019_10_14__12_44_01_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\algonquincollege_warehouse\algonquincollege_warehouse_FULL_2019_10_14__12_44_00_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\cegepsthyacinthe\cegepsthyacinthe_FULL_2019_10_14__11_53_00_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\cegepsthyacinthe_lor\cegepsthyacinthe_lor_FULL_2019_10_14__11_52_59_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\cegepsthyacinthe_reporting\cegepsthyacinthe_reporting_FULL_2019_10_14__11_52_57_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\cegepsthyacinthe_warehouse\cegepsthyacinthe_warehouse_FULL_2019_10_14__11_52_56_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\ryerson\ryerson_FULL_2019_10_14__06_33_04_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\ryerson_LOR\ryerson_LOR_FULL_2019_10_14__06_33_03_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\ryerson_Reporting\ryerson_Reporting_FULL_2019_10_14__06_28_51_CA05PSQL001E.bak'),
('Z:\SQL_Backups\Temp\ryerson_Warehouse\ryerson_Warehouse_FULL_2019_10_14__06_28_50_CA05PSQL001E.bak'),


--RESTORE HEADERONLY FROM DISK = N'V:\SQL_Backups\Temp\CFE\polestarpilates_FULL_2018_5_6__08_42_54_US04PSQL001D.bak'
--restore filelistonly from disk = 'V:\SQL_Backups\Temp\CFE\polestarpilates_FULL_2018_5_6__08_42_54_US04PSQL001D.bak'

-------------------------------------------------------------------------
('')--intenitional blank entry
declare @BackupPath varchar(525)
declare @dbname varchar(525)
declare @datapath varchar(525)
declare @logpath varchar(525)
declare @BackupType int
create table #Results (script varchar(max))
set @datapath = 'E:\SQL_Data\'
set @logpath = 'F:\SQL_Logs\'

--set @datapath = 'N:\MP_data_1\SQL_Data\'
--set @logpath = 'N:\MP_logs_1\SQL_Logs\'



WHILE (Select count(*) from #BackupPaths)>0
BEGIN
set @BackupPath = (select top 1 path from #BackupPaths)
IF LEN(@BackupPath)=0 BREAK
create table #tmp
(LogicalName nvarchar(128) ,PhysicalName nvarchar(260) ,Type char(1) ,FileGroupName nvarchar(128) ,Size numeric(20,0) ,MaxSize numeric(20,0),
Fileid tinyint,CreateLSN numeric(25,0),DropLSN numeric(25, 0),UniqueID uniqueidentifier,ReadOnlyLSN numeric(25,0),ReadWriteLSN numeric(25,0),
BackupSizeInBytes bigint,SourceBlocSize int,FileGroupId int,LogGroupGUID uniqueidentifier,DifferentialBaseLSN numeric(25,0),
DifferentialBaseGUID uniqueidentifier,IsReadOnly bit,IsPresent bit,TDEThumbprint char(1),snapshoturl nvarchar(128))

IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '12%')--SQL2014
--drop columns not found in SQL 2008
	BEGIN
	ALTER TABLE #tmp drop COLUMN snapshoturl
	END

insert #tmp
EXEC ('restore filelistonly from disk = ''' + @BackupPath + '''')

--select * from #tmp
--Header table
create table #HeaderTable (BackupName  nvarchar(128),  BackupDescription  nvarchar(255) ,BackupType  smallint ,ExpirationDate  datetime ,
Compressed  bit ,Position  smallint ,DeviceType  tinyint ,UserName  nvarchar(128) ,ServerName  nvarchar(128) ,DatabaseName  nvarchar(128) ,
DatabaseVersion  int ,DatabaseCreationDate  datetime ,BackupSize  numeric(20,0) ,FirstLSN  numeric(25,0) ,LastLSN  numeric(25,0) ,
CheckpointLSN  numeric(25,0) ,DatabaseBackupLSN  numeric(25,0) ,BackupStartDate  datetime ,BackupFinishDate  datetime ,SortOrder  smallint ,
CodePage  smallint ,UnicodeLocaleId  int ,UnicodeComparisonStyle  int ,CompatibilityLevel  tinyint ,SoftwareVendorId  int ,SoftwareVersionMajor  int ,
SoftwareVersionMinor  int ,SoftwareVersionBuild  int ,MachineName  nvarchar(128) ,Flags  int ,BindingID  uniqueidentifier ,RecoveryForkID  uniqueidentifier ,
Collation  nvarchar(128) ,FamilyGUID  uniqueidentifier ,HasBulkLoggedData  bit ,IsSnapshot  bit ,IsReadOnly  bit ,IsSingleUser  bit ,HasBackupChecksums  bit ,
IsDamaged  bit ,BeginsLogChain  bit ,HasIncompleteMetaData  bit ,IsForceOffline  bit ,IsCopyOnly  bit ,FirstRecoveryForkID  uniqueidentifier ,
ForkPointLSN  numeric(25,0) NULL,RecoveryModel  nvarchar(60) ,DifferentialBaseLSN  numeric(25,0) NULL,DifferentialBaseGUID  uniqueidentifier ,
BackupTypeDescription  nvarchar(60) ,BackupSetGUID  uniqueidentifier NULL,CompressedBackupSize bigint NULL,	Containment	INT null,
KeyAlgorithm	nvarchar(60) null,EncryptorThumbprint	varbinary(20) null,EncryptorType nvarchar(60) null)

IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '11%')--SQL2012
--drop columns not found in SQL 2012
	BEGIN
	ALTER TABLE #HeaderTable drop COLUMN KeyAlgorithm
	ALTER TABLE #HeaderTable drop COLUMN EncryptorThumbprint
	ALTER TABLE #HeaderTable drop COLUMN EncryptorType
	END
IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '10%')--SQL2008
--drop columns not found in SQL 2008
	BEGIN
	ALTER TABLE #HeaderTable drop COLUMN KeyAlgorithm
	ALTER TABLE #HeaderTable drop COLUMN EncryptorThumbprint
	ALTER TABLE #HeaderTable drop COLUMN EncryptorType
	ALTER TABLE #HeaderTable drop COLUMN Containment
	END

INSERT INTO #HeaderTable 
EXEC('RESTORE HEADERONLY FROM DISK = N''' + @BackupPath+'''')
SET @dbname = (select DatabaseName from #HeaderTable)
SET @BackupType = (select BackupType from #HeaderTable)
print @dbname
print @BackupType

--Fulls
Declare @RestoreCMD varchar(max)
set @RestoreCMD = ''

SET @RestoreCMD = (select 'RESTORE DATABASE ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY
,MOVE N''' + t1.LogicalName+''' TO N'''+@datapath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'D' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'D'))

	delete from #tmp where type = 'D' AND fileid = (select min(fileid) from #tmp where type = 'D' AND @BackupType=1)

--Data Files - .mdf, .ndf
	 WHILE (Select count(*) from #tmp where type = 'D' AND @BackupType=1 )>0
	BEGIN

	set @RestoreCMD = @RestoreCMD + 
	(select '
,MOVE N''' + t1.LogicalName+''' TO N'''+@datapath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'D' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'D'))
 
	delete from #tmp where type = 'D' AND fileid = (select min(fileid) from #tmp where type = 'D' AND @BackupType=1)
	END
--Log Files - .ldf
	 WHILE (Select count(*) from #tmp where type = 'L' AND @BackupType=1)>0
	BEGIN

	set @RestoreCMD = @RestoreCMD + 
	(select '
,MOVE N''' + t1.LogicalName+''' TO N'''+@logpath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'L' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'L'))
 
	delete from #tmp where type = 'L' AND fileid = (select min(fileid) from #tmp where type = 'L' AND @BackupType=1)
	END

IF (@BackupType=1)
	BEGIN
	insert into #Results
	Select @RestoreCMD
	END

--Diffs
insert into #Results
select 'RESTORE DATABASE ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY'
from #tmp t1 where t1.type = 'D' AND @BackupType=5 AND t1.fileid = 1

--Logs
insert into #Results
select 'RESTORE LOG ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY'
from #tmp t1 where t1.type = 'D' AND @BackupType=2 AND t1.fileid = 1

drop table #tmp 
drop table #HeaderTable

Delete from #BackupPaths where path = @BackupPath
END

select * from #Results
drop table #Results
drop table #BackupPaths
