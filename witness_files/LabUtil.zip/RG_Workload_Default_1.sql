/*
SELECT group_id
   FROM sys.dm_exec_sessions
   WHERE session_id = @@SPID;
*/
SELECT s1.*, s3.*
    FROM sys.columns AS s1
    CROSS JOIN sys.columns AS s2
    CROSS JOIN sys.columns AS s3
    CROSS JOIN sys.columns AS s4
    WHERE
        s2.name LIKE '%a%'
    ORDER BY 
        s3.name DESC, 
        s2.[object_id];