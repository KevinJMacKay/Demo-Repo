select connect_time, s.session_id, net_transport, auth_scheme, encrypt_option, host_name, login_name, program_name, original_login_name from sys.dm_exec_connections c
inner join sys.dm_exec_sessions s
on c.session_id = s.session_id
where s.login_name like '%' 
and auth_scheme like '%'
order by s.host_name

/*
SELECT InstanceName = @@SERVERNAME
    , InstancePortNumber = CONVERT(varchar(255), local_tcp_port)
    , dec.auth_scheme
    , USER_NAME = USER_NAME()
    , SUSER_SNAME = SUSER_SNAME()
FROM sys.dm_exec_connections dec
WHERE dec.session_id = @@SPID;
*/


exec sp_whoisactive @help = 1;