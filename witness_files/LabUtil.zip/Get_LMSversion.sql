SELECT top 10 * FROM [dbo].[DB_VERSION_INFORMATION]
order by version desc