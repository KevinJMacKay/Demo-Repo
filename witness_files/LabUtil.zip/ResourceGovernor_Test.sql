/*
https://www.mssqltips.com/sqlservertip/2368/using-dmvs-to-adjust-sql-server-resource-governor-settings/

Running on LAB1APSQLE451

*/

USE [master];
GO

-- create two logins, one to simulate concurrency:
CREATE LOGIN default_pool_login
   WITH PASSWORD = 'foo', CHECK_POLICY = OFF;

CREATE LOGIN limited_pool_login 
      WITH PASSWORD = 'foo', CHECK_POLICY = OFF;

-- create a separate database for testing:
IF DB_ID('ResourceGovernor') IS NULL
BEGIN
   CREATE DATABASE ResourceGovernor;
END
GO

USE ResourceGovernor;
GO

-- create db users tied to our logins:
CREATE USER default_pool_login FOR LOGIN default_pool_login;
CREATE USER limited_pool_login FOR LOGIN limited_pool_login;

-- give them the keys to the castle:
GRANT CONTROL ON SCHEMA::dbo TO default_pool_login;
GRANT CONTROL ON SCHEMA::dbo TO limited_pool_login;
GO


--------------------

USE [master];
GO

-- resource pool with low memory / CPU thresholds:
CREATE RESOURCE POOL limited
WITH
(
   MAX_MEMORY_PERCENT = 10,
   MAX_CPU_PERCENT = 10
);

-- workload group with low maxdop / duration / concurrency:
CREATE WORKLOAD GROUP limited
WITH
(
   MAX_DOP = 1,
   REQUEST_MAX_CPU_TIME_SEC = 5,
   GROUP_MAX_REQUESTS = 1
)
USING limited; 
GO

-- classifier function to route "limited_pool_login" to the limited pool:
CREATE FUNCTION dbo.TestClassifierFunction()
RETURNS SYSNAME
WITH SCHEMABINDING
AS
BEGIN
   RETURN (SELECT CASE SUSER_SNAME() 
       WHEN N'limited_pool_login' THEN N'limited' 
       ELSE N'default' 
   END);
END;
GO
GRANT EXEC ON [dbo].[TestClassifierFunction] TO [Public];
GO

-- assign this function as the classifier function:
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = dbo.TestClassifierFunction);
GO
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO

--------------------

SELECT group_id
   FROM sys.dm_exec_sessions
   WHERE session_id = @@SPID;

   --------------------
   --run this query in 4 separate windows, 2 of each login created above.
   SELECT s1.*, s3.*
    FROM sys.columns AS s1
    CROSS JOIN sys.columns AS s2
    CROSS JOIN sys.columns AS s3
    CROSS JOIN sys.columns AS s4
    WHERE
        s2.name LIKE '%a%'
    ORDER BY 
        s3.name DESC, 
        s2.[object_id];
   --------------------

   SELECT 
   name,
   [start] = statistics_start_time,
   cpu = total_cpu_usage_ms,
   memgrant_timeouts = total_memgrant_timeout_count,
   out_of_mem = out_of_memory_count,     mem_waiters = memgrant_waiter_count
FROM 
   sys.dm_resource_governor_resource_pools
WHERE
   pool_id > 1;
   
SELECT 
   name,
   [start] = statistics_start_time,
   waiters = queued_request_count, -- or total_queued_request_count
   [cpu_violations] = total_cpu_limit_violation_count,
   subopt_plans = total_suboptimal_plan_generation_count,
   reduced_mem = total_reduced_memgrant_count
FROM
   sys.dm_resource_governor_workload_groups
WHERE
   group_id > 1;

   --------------------
   sp_whoisactive 
   sp_who2