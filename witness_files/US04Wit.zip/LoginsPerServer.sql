
SET NOCOUNT ON

DECLARE @command NVARCHAR(MAX)
DECLARE @command_temp AS NVARCHAR(MAX)
DECLARE @selectDB AS NVARCHAR(128)

SET @selectDB = ''

IF (OBJECT_ID('tempdb..##Warehouse_DBS_temp') IS NOT NULL)
DROP TABLE ##Warehouse_DBS_temp;

CREATE TABLE ##Warehouse_DBS_temp
(
      [DatabaseName] SYSNAME,
      [Year] INT,
      [Month] INT,
      [Day] INT,
      [Total] INT
)

SET @command = 
'
IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ''PRODUCT_VERSION'')
Begin
INSERT INTO ##Warehouse_DBS_temp
SELECT db_name(),YEAR(UL.AttemptDate) AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate) AS [Day], 
COUNT(*) AS Total_Login
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
            INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
            ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0 
AND UL.AttemptDate >= ''2020-02-03'' 
AND UL.AttemptDate < ''2020-02-04''
--AND UL.AttemptDate < ''2014-09-05''
GROUP BY  YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate)
ORDER BY 1,2,3 desc
End
'

IF (OBJECT_ID('tempdb..#ALL_Warehouse_DBS') IS NOT NULL)
DROP TABLE #ALL_Warehouse_DBS

SELECT [name] INTO #ALL_Warehouse_DBS
FROM master.sys.databases WHERE database_id > 4 
AND is_read_only = 0 
AND [name] NOT LIKE '%_Logging' 
AND [name] NOT LIKE '%_Reporting' 
AND [name] NOT LIKE '%_SIS'
ORDER BY [name]

WHILE (SELECT COUNT(*) FROM #ALL_Warehouse_DBS) > 0
BEGIN
      SELECT @selectdb = (SELECT TOP 1 * FROM #ALL_Warehouse_DBS)

      SELECT @command_temp = 'USE [' +  @selectdb + ']; ' + @command

      EXEC(@command_temp)

      DELETE FROM #ALL_Warehouse_DBS WHERE [name] = @selectdb
END


DROP TABLE #ALL_Warehouse_DBS

SELECT * FROM  ##Warehouse_DBS_temp
order by Total desc


DROP TABLE ##Warehouse_DBS_temp
