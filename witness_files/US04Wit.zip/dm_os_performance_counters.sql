select * from sys.dm_os_performance_counters
--where object_name = 'SQLServer:Database Replica'
where counter_name like '%cpu%'



--https://www.sqlshack.com/troubleshooting-sql-server-issues-sys-dm_os_performance_counters/
select distinct cntr_type, count(cntr_value) from sys.dm_os_performance_counters
group by cntr_type

Select
*,
case cntr_type
WHEN 65792 then  'PERF_COUNTER_LARGE_RAWCOUNT - no additional calculations, last observed'
WHEN 1073939712 then  'PERF_LARGE_RAW_BASE - denominator for further calculation'
WHEN 1073874176 then  'PERF_AVERAGE_BULK - to be used with corresponding BASE value'
WHEN 537003264 then  'PERF_LARGE_RAW_FRACTION - ratio between itself and BASE value'
WHEN 272696576 then  'PERF_COUNTER_BULK_COUNT - accumulated values, determine value over time interval'
WHEN 272696320 then  'PERF_COUNTER_COUNTER - Average number of operations completed for each second of the sample interval'
end
from sys.dm_os_performance_counters
Where 1=1
--where object_name = 'SQLServer:Database Replica'
--AND counter_name = 'Log Send Queue'
AND counter_name like '%cpu usage%'

DECLARE @PageLookups1 BIGINT;
 
SELECT @PageLookups1 = cntr_value
FROM sys.dm_os_performance_counters
WHERE counter_name = 'Page lookups/sec';
 
WAITFOR DELAY '00:00:10';
 
SELECT (cntr_value - @PageLookups1) / 10 AS 'Page lookups/sec'
FROM sys.dm_os_performance_counters
WHERE counter_name = 'Page lookups/sec';

SELECT cntr_value
FROM sys.dm_os_performance_counters
WHERE counter_name = 'Page lookups/sec';
 
select  (3922980672726-3922977445231)/10


SELECT ms_ticks
FROM sys.dm_os_sys_info;
 
SELECT *
FROM sys.dm_os_performance_counters
WHERE counter_name = 'Page lookups/sec';
    
