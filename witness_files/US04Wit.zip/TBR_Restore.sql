USE [master]
RESTORE DATABASE [TBR] FROM  DISK = N'R:\TBR_FULL_2019_2_18__05_32_57_US04PSQL001N.bak' WITH  FILE = 1,  
MOVE N'd2l_Data' TO N'T:\SQL_Data\TBR.mdf',  
MOVE N'd2l_Data_P1' TO N'T:\SQL_Data\TBR_Data1.ndf',  
MOVE N'd2l_Data_P2' TO N'T:\SQL_Data\TBR_Data2.ndf',  
MOVE N'd2l_Data_P3' TO N'T:\SQL_Data\TBR_Data3.ndf',  
MOVE N'd2l_Data_P4' TO N'T:\SQL_Data\TBR_Data4.ndf',  
MOVE N'd2l_Data_P5' TO N'T:\SQL_Data\TBR_Data5.ndf',  
MOVE N'd2l_Data_P6' TO N'T:\SQL_Data\TBR_Data6.ndf',  
MOVE N'd2l_Data_P7' TO N'T:\SQL_Data\TBR_Data7.ndf',  
MOVE N'd2l_Log' TO N'T:\SQL_Logs\TBR_Log.ldf',  NOUNLOAD,  STATS = 5

GO

--03:21:52.035
