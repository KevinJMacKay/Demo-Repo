-- FETCH JOBS FOR INDEX REBUILDS --

-- Log Space Check
-- DBCC SQLPerf (logspace)

use master;
GO

-- Fetch index rebuild for all databases containing
-- the relevant table

DECLARE @DbName NVARCHAR(MAX)
DECLARE @TableName NVARCHAR(MAX) = N'QA_ATOMS'
DECLARE @IndexName NVARCHAR(MAX) = N'PK_QA_ATOMS'

-- Get all databases containing the relevant table
DECLARE db_cursor CURSOR FOR
SELECT name 
FROM sys.databases 
WHERE database_id > 4

OPEN db_cursor
FETCH NEXT FROM db_cursor INTO @DbName  

WHILE @@FETCH_STATUS = 0  
BEGIN 
	-- Run schedule script in database
	DECLARE @SQL NVARCHAR(MAX)
	SET @SQL =
	'
	USE ' + QUOTENAME(@DbName) + ';
	
	IF EXISTS(
		SELECT *
		FROM sys.extended_properties
		WHERE [name] = N''Target Compression''
	)
	SELECT
		DB_NAME() AS [Database],
		OB.name AS TableName,
		IX.name AS IndexName,
		P.data_compression_desc AS CurrentLevel,
		EP.value AS TargetLevel,
		IIF(CAST(EP.value AS NVARCHAR(MAX)) <> P.data_compression_desc, 0, 1) AS IsDone,
		CASE
			WHEN R.percent_complete IS NOT NULL THEN CAST(R.percent_complete AS DECIMAL(10,2))
			ELSE IIF(CAST(EP.value AS NVARCHAR(MAX)) <> P.data_compression_desc, 0, 100)
		END AS PercentComplete,
		R.State_Desc AS State
	FROM sys.extended_properties EP
	INNER JOIN sys.objects OB
		ON OB.object_id = EP.major_id
	INNER JOIN sys.indexes IX
		ON IX.index_id = EP.minor_id
		AND IX.object_id = OB.object_id
	INNER JOIN sys.partitions P
		ON P.object_id = OB.object_id
		AND P.index_id = IX.index_id
	LEFT JOIN sys.index_resumable_operations R
		ON R.object_id = OB.object_id
		AND R.index_id = IX.index_id
	WHERE
		EP.[name] = N''Target Compression''
	ORDER BY EP.major_id, EP.minor_id
	'
	EXECUTE(@SQL)

	-- Fetch next database
	FETCH NEXT FROM db_cursor INTO @DbName
END 

CLOSE db_cursor  
DEALLOCATE db_cursor 

