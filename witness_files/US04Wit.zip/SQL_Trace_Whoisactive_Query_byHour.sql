DECLARE @Starttime varchar (100)
DECLARE @Endtime varchar (100)
--select getdate()
SET @Starttime = '2021-02-01 01:25'
SET @Endtime = '2021-02-01 01:55'
--*******************************************************************************************
	
	SELECT  [dd hh:mm:ss.mss],[collection_time],[session_id],[sql_text],[login_name],[wait_info]
	,[blocking_session_id],[tran_log_writes],[CPU],[tempdb_allocations],[tempdb_current],[reads]
	,[writes],[physical_reads],[query_plan],[used_memory],[status],[tran_start_time],[open_tran_count]
	,[percent_complete],[host_name],[database_name],[program_name],[start_time],[login_time],[request_id]
	  FROM [SQL_Trace].[dbo].[WhoIsActive]
	  WHERE 1=1
	  AND collection_time between @Starttime AND @Endtime
	  AND login_name not in ('NT AUTHORITY\SYSTEM')
	  AND login_name not in ('AUE1\aue1_SQL_Agent','AUE1\AUE1TaskAdmin')
	  --AND session_id = 1372
	  --AND CAST([sql_text] as nvarchar (max)) like '%_reporting%'
	  order by 1 desc
/*
--by minute
select 
TT.login_name,TT.[Month],TT.[Day],TT.[Hour],TT.[Minute],COUNT(*) AS Total_Unique
from (SELECT [login_name],YEAR(collection_time)  AS [Year], MONTH(collection_time) AS [Month], DAY(collection_time)AS [Day], Datepart(hh,collection_time)AS [Hour], Datepart(MINUTE,collection_time)AS [Minute],
COUNT(*) AS Total
 FROM [SQL_Trace].[dbo].[WhoIsActive]
	  WHERE 1=1
	  AND collection_time between @Starttime AND @Endtime
	  AND login_name not in ('AUE1\aue1_SQL_Agent','NT AUTHORITY\SYSTEM','AUE1\AUE1TaskAdmin')
	  --AND session_id = 1372
	  --AND CAST([sql_text] as nvarchar (max)) like '%_reporting%'

GROUP BY [login_name],YEAR(collection_time), MONTH(collection_time), DAY(collection_time), Datepart(hh,collection_time),Datepart(MINUTE,collection_time)) TT
group by tt.[login_name],TT.[Year], TT.[Month], TT.[Day], TT.[Hour],TT.[Minute]

*/
--by hour
select 
TT.login_name,TT.[Month],TT.[Day],TT.[Hour], tt.[count]
from (SELECT [login_name],YEAR(collection_time)  AS [Year], MONTH(collection_time) AS [Month], DAY(collection_time)AS [Day], Datepart(hh,collection_time)AS [Hour], 
COUNT(*) AS [count]
 FROM [SQL_Trace].[dbo].[WhoIsActive]
	  WHERE 1=1
	  AND collection_time between @Starttime AND @Endtime
	  --AND collection_time between '2021-01-05 05:30' AND '2021-01-05 05:31'
	  AND login_name not in ('AUE1\aue1_SQL_Agent','NT AUTHORITY\SYSTEM','AUE1\AUE1TaskAdmin')
	  --AND session_id = 1372
	  --AND CAST([sql_text] as nvarchar (max)) like '%_reporting%'

GROUP BY [login_name],YEAR(collection_time), MONTH(collection_time), DAY(collection_time), Datepart(hh,collection_time)) TT
group by tt.[login_name],TT.[Year], TT.[Month], TT.[Day], TT.[Hour],tt.[count]
Order by TT.[Year], TT.[Month], TT.[Day]desc, TT.[Hour]desc,tt.[count]desc