:CONNECT US04APSQLB308
SELECT 'K12 Main'
SELECT d.[name]
,(log_send_queue_size / 1024) as [Log_Send_Queue_(MB)]
,(redo_queue_size / 1024) as [Redo_Send_Queue_(MB)]
,(redo_rate / 1024) as [Redo_Rate_(MB)]
,last_commit_time,(log_send_rate / 1024) as [Log_Send_Rate_(MB)]
,ar.replica_server_name
,CASE 
	WHEN log_send_rate <= 0
	THEN NULL
	ELSE (log_send_queue_size / log_send_rate) / 60 
	END as [Log_Send_Time_Until_Up_To_Date_(Minutes)]
,CASE 
	WHEN redo_rate <= 0
	THEN NULL
	ELSE (redo_queue_size / redo_rate) / 60 
	END as [Redo_Time_Until_Up_To_Date_(Minutes)]
,(DATEDIFF(hour, (GetDate()), last_commit_time)) AS [HoursBehind]
FROM   [master].[sys].[dm_hadr_database_replica_states] drs
inner join sys.availability_replicas ar
on drs.replica_id = ar.replica_id
inner join sys.databases d
on d.database_id = drs.database_id
where [name] = 'k12'
GO