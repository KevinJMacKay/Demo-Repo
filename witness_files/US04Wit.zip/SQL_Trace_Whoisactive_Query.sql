SELECT TOP (20000) 
	  --count (*)
	   [dd hh:mm:ss.mss]
	  ,[collection_time]
      ,[session_id]
	  ,status
	  ,CAST([sql_text] as nvarchar (max)) as query
      ,[sql_text]
      ,[login_name]
      ,[wait_info]
      ,[tran_log_writes]
      ,[CPU]
      ,cast(replace([tempdb_allocations] ,',','') as int) as TempUsage
      ,[tempdb_allocations]
      ,[tempdb_current]
      ,[blocking_session_id]
      ,[reads]
      ,[writes]
      ,[physical_reads]
      ,[query_plan]
      ,[used_memory]
      ,[status]
      ,[tran_start_time]
      ,[open_tran_count]
      ,[percent_complete]
      ,[host_name]
      ,[database_name]
      ,[program_name]
      ,[start_time]
      ,[login_time]
      ,[request_id]
  FROM [SQL_Trace].[dbo].[WhoIsActive]
  where 1=1
AND collection_time between '2020-03-02 19:00' AND '2020-03-02 21:00'
  --AND login_name not in ('NT AUTHORITY\SYSTEM','AUE1\AUE1_SQL_Agent')
--AND cast(replace([tempdb_allocations] ,',','') as int) > 1000
--AND login_name = 'jasperUser'
AND database_name = 'coc'
--AND [session_id] = 128
  --AND CAST([sql_text] as nvarchar (max)) like '%INSERT Dim_OrgUnitHierarchy%'
  --ORDER by [tempdb_allocations] desc
ORDER by collection_time desc
	--ORDER BY [dd hh:mm:ss.mss] desc
  --ORDER BY 1 desc


------------------------------------------------------------------------------------------------------------------  
  /*

SELECT
	  count (*)
	  --,login_name 
	  ,CAST([sql_text] as nvarchar (max)) as query

  FROM [SQL_Trace].[dbo].[WhoIsActive]
  where 1=1
  AND collection_time between '2019-10-18 10:00' AND '2019-10-21 12:25' 
AND login_name = 'byui_production_SQLUser'
 group by CAST([sql_text] as nvarchar (max))
  --group by login_name 
  --ORDER by collection_time asc
  --ORDER BY [dd hh:mm:ss.mss] desc
  ORDER BY 1 desc

  */