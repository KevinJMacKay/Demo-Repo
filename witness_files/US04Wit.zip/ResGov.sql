USE master;  
go  
-- Get the stored metadata.  
SELECT   
*
FROM   
sys.resource_governor_configuration;  
go 

select * from sys.dm_resource_governor_resource_pools

SELECT name, max_iops_per_volume FROM sys.resource_governor_resource_pools
WHERE name = 'MainDataExportPool'