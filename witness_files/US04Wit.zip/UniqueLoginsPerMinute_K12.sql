select 
db_name(),TT.[Month],TT.[Day],TT.[Hour],TT.[Minute],COUNT(*) AS Total_Unique
from (SELECT UL.UserId,YEAR(UL.AttemptDate)  AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate)AS [Day], Datepart(hh,UL.AttemptDate)AS [Hour], Datepart(MINUTE,UL.AttemptDate)AS [Minute],
COUNT(*) AS Total
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0 
AND UL.AttemptDate between '2020-08-31 12:15' AND '2020-08-31 13:12'  -- Specific date range
GROUP BY UL.UserId,YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate), Datepart(hh,UL.AttemptDate),Datepart(MINUTE,UL.AttemptDate)) TT
group by TT.[Year], TT.[Month], TT.[Day], TT.[Hour],TT.[Minute]
order by TT.[Month],TT.[Day],TT.[Hour] desc,TT.[Minute]desc