select top 10  [tran_start_time], [collection_time], [dd hh:mm:ss.mss],[session_id], [sql_text], [login_name], [wait_info], [tran_log_writes], [CPU], [tempdb_allocations], [tempdb_current], [blocking_session_id], [reads], [writes], [physical_reads], [query_plan], [used_memory], [status],  [implicit_tran], [open_tran_count], [percent_complete], [host_name], [database_name], [program_name], [start_time], [login_time], [request_id]
from SQL_Trace..WhoIsActive
where 1=1
AND login_name like '%RHU\TIngliscolo%'
AND session_id = 178
AND database_name = 'minnstateqab'
order by collection_time desc

Select top 10  [tran_start_time], [collection_time], [dd hh:mm:ss.mss],[session_id], [sql_text], [query_plan]
from SQL_Trace..WhoIsActive
where 1=1
AND login_name like '%RHU\TIngliscolo%'
AND session_id = 178
AND database_name = 'minnstateqab'
order by collection_time desc


DBCC SQLPERF(LOGSPACE);
GO

sp_whoisactive @get_plans=1