
SET NOCOUNT ON

DECLARE @command NVARCHAR(MAX)
DECLARE @command_temp AS NVARCHAR(MAX)
DECLARE @selectDB AS NVARCHAR(128)

SET @selectDB = ''

IF (OBJECT_ID('tempdb..##Warehouse_DBS_temp') IS NOT NULL)
DROP TABLE ##Warehouse_DBS_temp;

CREATE TABLE ##Warehouse_DBS_temp
(
      [DatabaseName] SYSNAME,
      [Month] INT,
      [Day] INT,
      [Hour] INT,
	  [Minute] INT,
      [Total] INT
)

SET @command = 
'
IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = ''PRODUCT_VERSION'')
Begin
INSERT INTO ##Warehouse_DBS_temp
select 
db_name(),TT.[Month],TT.[Day],TT.[Hour],TT.[Minute],COUNT(*) AS Total_Unique
from (SELECT UL.UserId,YEAR(UL.AttemptDate)  AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate)AS [Day], Datepart(hh,UL.AttemptDate)AS [Hour], Datepart(MINUTE,UL.AttemptDate)AS [Minute],
COUNT(*) AS Total
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0 
AND UL.AttemptDate >= ''2020-03-19 12:00:00'' 
AND UL.AttemptDate < ''2020-03-20 22:10:00''

GROUP BY UL.UserId,YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate), Datepart(hh,UL.AttemptDate),Datepart(MINUTE,UL.AttemptDate)) TT
group by TT.[Year], TT.[Month], TT.[Day], TT.[Hour],TT.[Minute]

End
'

IF (OBJECT_ID('tempdb..#ALL_Warehouse_DBS') IS NOT NULL)
DROP TABLE #ALL_Warehouse_DBS

SELECT [name] INTO #ALL_Warehouse_DBS
FROM master.sys.databases WHERE database_id > 4 
AND is_read_only = 0
And state_desc = 'online'
AND [name] NOT LIKE '%_Logging' 
AND [name] NOT LIKE '%_Reporting' 
AND [name] NOT LIKE '%_SIS'
ORDER BY [name]

WHILE (SELECT COUNT(*) FROM #ALL_Warehouse_DBS) > 0
BEGIN
      SELECT @selectdb = (SELECT TOP 1 * FROM #ALL_Warehouse_DBS)

      SELECT @command_temp = 'USE [' +  @selectdb + ']; ' + @command

      EXEC(@command_temp)

      DELETE FROM #ALL_Warehouse_DBS WHERE [name] = @selectdb
END


DROP TABLE #ALL_Warehouse_DBS

SELECT * FROM  ##Warehouse_DBS_temp
ORDER BY 1,2,3,4,5 
DROP TABLE ##Warehouse_DBS_temp
/*
select username, count(username)
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0 
AND UL.AttemptDate >= '2020-03-18 12:00:00' 
AND UL.AttemptDate < '2020-03-20 22:10:00'
group by UserName
*/