--Execute locally on server running Audit trace

SET NOCOUNT ON


DECLARE @FilePath NVARCHAR(4000)

SELECT @FilePath = REVERSE(SUBSTRING(REVERSE(XEventData.XEVent.value('@name', 'nvarchar(4000)')), PATINDEX('%\%', REVERSE(XEventData.XEVent.value('@name', 'nvarchar(4000)'))), LEN(REVERSE(XEventData.XEVent.value('@name', 'nvarchar(4000)'))))) + '*.xel'
	FROM 
    (
        SELECT CAST(target_data AS XML) as target_data
        FROM sys.dm_xe_sessions AS s 
        JOIN sys.dm_xe_session_targets AS t 
            ON t.event_session_address = s.address
        WHERE s.name = 'Audit_User_Actions'
          AND t.target_name = 'event_file'
    ) AS sub
    CROSS APPLY target_data.nodes ('EventFileTarget/File') AS XEventData (XEVent)

--Extract the events

SELECT 
DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), XEventData.XEVent.value('@timestamp', 'datetime2')) AS [TimeStamp], 
XEventData.XEVent.value('(action[@name="is_system"]/value)[1]', 'bit') AS [Is_System],
XEventData.XEVent.value('(action[@name="server_instance_name"]/value)[1]', 'nvarchar(256)') AS [Server_Instance_Name],
XEventData.XEVent.value('(action[@name="session_id"]/value)[1]', 'int') AS [Session_ID],
XEventData.XEVent.value('(action[@name="session_nt_username"]/value)[1]', 'nvarchar(256)') AS [Session_NT_Username],
XEventData.XEVent.value('(action[@name="session_server_principal_name"]/value)[1]', 'nvarchar(256)') AS [Session_Server_Principal_Name],
XEventData.XEVent.value('(action[@name="database_name"]/value)[1]', 'nvarchar(256)') AS [Database_Name],
XEventData.XEVent.value('(action[@name="client_hostname"]/value)[1]', 'nvarchar(256)') AS [Client_Host_Name],
XEventData.XEVent.value('(action[@name="client_app_name"]/value)[1]', 'nvarchar(256)') AS [Client_Aplication_Name],
XEventData.XEVent.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS [SQL_Text]
    FROM 
(    SELECT CAST(event_data AS XML) as target_data
        FROM sys.fn_xe_file_target_read_file(@FilePath, null, null, null)
) as tab
CROSS APPLY target_data.nodes ('event') AS XEventData (XEVent)
WHERE 
    DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), CURRENT_TIMESTAMP), XEventData.XEVent.value('@timestamp', 'datetime2')) > '2019-08-19 12:48:00.00'
	AND XEventData.XEVent.value('(action[@name="session_nt_username"]/value)[1]', 'nvarchar(256)')  = 'RHU\slukiccolo'
	AND XEventData.XEVent.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)')  LIKE '%ALTER LOGIN%'