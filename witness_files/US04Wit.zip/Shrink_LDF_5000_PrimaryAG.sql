SELECT 'USE ['+DB_NAME(mf.[database_id])+']
DBCC SHRINKFILE (N'''+mf.[name]+''' , 5000)'AS Script
,DB_NAME(mf.[database_id])AS [Database Name],  
       CONVERT( bigint, size/128.0) AS [Total Size in MB],
       [file_id], mf.[name], mf.[physical_name], type_desc, mf.[state_desc],
          mf.[is_percent_growth], mf.[growth]
FROM sys.master_files mf WITH (NOLOCK)
INNER JOIN sys.databases d
ON d.database_id = mf.database_id
WHERE 1=1
AND type_desc = 'LOG'
AND  CONVERT( bigint, size/128.0) > 5000
AND mf.[database_id] > 4
AND mf.[is_read_only] <> 1
AND mf.[state_desc] = 'ONLINE'
--
--AND mf.[physical_name] like '%E:\%'
--order by size desc
AND
-----------
d.[name] in
(select DISTINCT ADC.database_name 
from 
sys.availability_databases_cluster ADC 
inner join 
sys.dm_hadr_availability_replica_states HARS 
on ADC.group_id = HARS.group_id 
inner join sys.availability_group_listeners AGL 
on HARS.group_id = AGL.group_id 
where is_local = 'TRUE' 
and HARS.role_desc = 'PRIMARY' 
UNION
select DISTINCT name 
from master.sys.databases 
where name not in
(
select database_name from
sys.availability_databases_cluster ADC 
)
)
--order by size desc