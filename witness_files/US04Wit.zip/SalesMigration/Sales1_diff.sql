use [aau42lines];
GO
use [master];
GO
BACKUP DATABASE [aau42lines] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aau42lines_backup_2020_04_28_115445_1431647.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aau42lines_backup_2020_04_28_115445_1431647', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aau42lines_lor];
GO
use [master];
GO
BACKUP DATABASE [aau42lines_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aau42lines_lor_backup_2020_04_28_115445_1587783.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aau42lines_lor_backup_2020_04_28_115445_1587783', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aau42lines_reporting];
GO
use [master];
GO
BACKUP DATABASE [aau42lines_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aau42lines_reporting_backup_2020_04_28_115445_1745459.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aau42lines_reporting_backup_2020_04_28_115445_1745459', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aau42lines_warehouse];
GO
use [master];
GO
BACKUP DATABASE [aau42lines_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aau42lines_warehouse_backup_2020_04_28_115445_2057829.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aau42lines_warehouse_backup_2020_04_28_115445_2057829', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [abs1];
GO
use [master];
GO
BACKUP DATABASE [abs1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\abs1_backup_2020_04_28_115445_2057829.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'abs1_backup_2020_04_28_115445_2057829', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [abs1_lor];
GO
use [master];
GO
BACKUP DATABASE [abs1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\abs1_lor_backup_2020_04_28_115445_2383622.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'abs1_lor_backup_2020_04_28_115445_2383622', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [abs1_reporting];
GO
use [master];
GO
BACKUP DATABASE [abs1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\abs1_reporting_backup_2020_04_28_115445_2525009.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'abs1_reporting_backup_2020_04_28_115445_2525009', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [abs1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [abs1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\abs1_warehouse_backup_2020_04_28_115445_2683308.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'abs1_warehouse_backup_2020_04_28_115445_2683308', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [academyart];
GO
use [master];
GO
BACKUP DATABASE [academyart] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\academyart_backup_2020_04_28_115445_2838395.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'academyart_backup_2020_04_28_115445_2838395', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [academyart_lor];
GO
use [master];
GO
BACKUP DATABASE [academyart_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\academyart_lor_backup_2020_04_28_115445_2995035.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'academyart_lor_backup_2020_04_28_115445_2995035', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [academyart_reporting];
GO
use [master];
GO
BACKUP DATABASE [academyart_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\academyart_reporting_backup_2020_04_28_115445_3153838.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'academyart_reporting_backup_2020_04_28_115445_3153838', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [academyart_warehouse];
GO
use [master];
GO
BACKUP DATABASE [academyart_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\academyart_warehouse_backup_2020_04_28_115445_3306537.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'academyart_warehouse_backup_2020_04_28_115445_3306537', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [acessibilidade];
GO
use [master];
GO
BACKUP DATABASE [acessibilidade] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\acessibilidade_backup_2020_04_28_115445_3465962.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'acessibilidade_backup_2020_04_28_115445_3465962', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [acessibilidade_lor];
GO
use [master];
GO
BACKUP DATABASE [acessibilidade_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\acessibilidade_lor_backup_2020_04_28_115445_3619219.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'acessibilidade_lor_backup_2020_04_28_115445_3619219', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [acessibilidade_reporting];
GO
use [master];
GO
BACKUP DATABASE [acessibilidade_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\acessibilidade_reporting_backup_2020_04_28_115445_3773893.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'acessibilidade_reporting_backup_2020_04_28_115445_3773893', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [acessibilidade_warehouse];
GO
use [master];
GO
BACKUP DATABASE [acessibilidade_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\acessibilidade_warehouse_backup_2020_04_28_115445_3931802.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'acessibilidade_warehouse_backup_2020_04_28_115445_3931802', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anahuactrial];
GO
use [master];
GO
BACKUP DATABASE [anahuactrial] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anahuactrial_backup_2020_04_28_115445_4086492.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anahuactrial_backup_2020_04_28_115445_4086492', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anahuactrial_lor];
GO
use [master];
GO
BACKUP DATABASE [anahuactrial_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anahuactrial_lor_backup_2020_04_28_115445_4246294.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anahuactrial_lor_backup_2020_04_28_115445_4246294', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anahuactrial_reporting];
GO
use [master];
GO
BACKUP DATABASE [anahuactrial_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anahuactrial_reporting_backup_2020_04_28_115445_4400145.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anahuactrial_reporting_backup_2020_04_28_115445_4400145', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anahuactrial_warehouse];
GO
use [master];
GO
BACKUP DATABASE [anahuactrial_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anahuactrial_warehouse_backup_2020_04_28_115445_4556506.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anahuactrial_warehouse_backup_2020_04_28_115445_4556506', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anthonylealk12];
GO
use [master];
GO
BACKUP DATABASE [anthonylealk12] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anthonylealk12_backup_2020_04_28_115445_4712548.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anthonylealk12_backup_2020_04_28_115445_4712548', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anthonylealk12_lor];
GO
use [master];
GO
BACKUP DATABASE [anthonylealk12_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anthonylealk12_lor_backup_2020_04_28_115445_4869610.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anthonylealk12_lor_backup_2020_04_28_115445_4869610', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anthonylealk12_reporting];
GO
use [master];
GO
BACKUP DATABASE [anthonylealk12_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anthonylealk12_reporting_backup_2020_04_28_115445_5026234.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anthonylealk12_reporting_backup_2020_04_28_115445_5026234', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [anthonylealk12_warehouse];
GO
use [master];
GO
BACKUP DATABASE [anthonylealk12_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\anthonylealk12_warehouse_backup_2020_04_28_115445_5181993.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'anthonylealk12_warehouse_backup_2020_04_28_115445_5181993', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [apa];
GO
use [master];
GO
BACKUP DATABASE [apa] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\apa_backup_2020_04_28_115445_5338420.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'apa_backup_2020_04_28_115445_5338420', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [apa_lor];
GO
use [master];
GO
BACKUP DATABASE [apa_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\apa_lor_backup_2020_04_28_115445_5495400.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'apa_lor_backup_2020_04_28_115445_5495400', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [apa_reporting];
GO
use [master];
GO
BACKUP DATABASE [apa_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\apa_reporting_backup_2020_04_28_115445_5653858.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'apa_reporting_backup_2020_04_28_115445_5653858', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [apa_warehouse];
GO
use [master];
GO
BACKUP DATABASE [apa_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\apa_warehouse_backup_2020_04_28_115445_5806373.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'apa_warehouse_backup_2020_04_28_115445_5806373', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [athabasca];
GO
use [master];
GO
BACKUP DATABASE [athabasca] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\athabasca_backup_2020_04_28_115445_5964566.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'athabasca_backup_2020_04_28_115445_5964566', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [athabasca_lor];
GO
use [master];
GO
BACKUP DATABASE [athabasca_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\athabasca_lor_backup_2020_04_28_115445_6117154.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'athabasca_lor_backup_2020_04_28_115445_6117154', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [athabasca_reporting];
GO
use [master];
GO
BACKUP DATABASE [athabasca_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\athabasca_reporting_backup_2020_04_28_115445_6273442.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'athabasca_reporting_backup_2020_04_28_115445_6273442', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [athabasca_warehouse];
GO
use [master];
GO
BACKUP DATABASE [athabasca_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\athabasca_warehouse_backup_2020_04_28_115445_6431106.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'athabasca_warehouse_backup_2020_04_28_115445_6431106', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aviso];
GO
use [master];
GO
BACKUP DATABASE [aviso] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aviso_backup_2020_04_28_115445_6586554.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aviso_backup_2020_04_28_115445_6586554', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aviso_lor];
GO
use [master];
GO
BACKUP DATABASE [aviso_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aviso_lor_backup_2020_04_28_115445_6586554.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aviso_lor_backup_2020_04_28_115445_6586554', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aviso_reporting];
GO
use [master];
GO
BACKUP DATABASE [aviso_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aviso_reporting_backup_2020_04_28_115445_6742420.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aviso_reporting_backup_2020_04_28_115445_6742420', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [aviso_warehouse];
GO
use [master];
GO
BACKUP DATABASE [aviso_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\aviso_warehouse_backup_2020_04_28_115445_6898695.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'aviso_warehouse_backup_2020_04_28_115445_6898695', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [baglassdemo];
GO
use [master];
GO
BACKUP DATABASE [baglassdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\baglassdemo_backup_2020_04_28_115445_7054684.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'baglassdemo_backup_2020_04_28_115445_7054684', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [baglassdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [baglassdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\baglassdemo_lor_backup_2020_04_28_115445_7211135.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'baglassdemo_lor_backup_2020_04_28_115445_7211135', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [baglassdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [baglassdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\baglassdemo_reporting_backup_2020_04_28_115445_7367230.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'baglassdemo_reporting_backup_2020_04_28_115445_7367230', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [baglassdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [baglassdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\baglassdemo_warehouse_backup_2020_04_28_115445_7523624.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'baglassdemo_warehouse_backup_2020_04_28_115445_7523624', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bbickar];
GO
use [master];
GO
BACKUP DATABASE [bbickar] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bbickar_backup_2020_04_28_115445_7679670.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bbickar_backup_2020_04_28_115445_7679670', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bbickar_lor];
GO
use [master];
GO
BACKUP DATABASE [bbickar_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bbickar_lor_backup_2020_04_28_115445_7679670.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bbickar_lor_backup_2020_04_28_115445_7679670', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bbickar_reporting];
GO
use [master];
GO
BACKUP DATABASE [bbickar_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bbickar_reporting_backup_2020_04_28_115445_7835905.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bbickar_reporting_backup_2020_04_28_115445_7835905', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bbickar_warehouse];
GO
use [master];
GO
BACKUP DATABASE [bbickar_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bbickar_warehouse_backup_2020_04_28_115445_7992266.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bbickar_warehouse_backup_2020_04_28_115445_7992266', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bdahl];
GO
use [master];
GO
BACKUP DATABASE [bdahl] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bdahl_backup_2020_04_28_115445_8148390.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bdahl_backup_2020_04_28_115445_8148390', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bdahl_lor];
GO
use [master];
GO
BACKUP DATABASE [bdahl_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bdahl_lor_backup_2020_04_28_115445_8304677.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bdahl_lor_backup_2020_04_28_115445_8304677', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bdahl_reporting];
GO
use [master];
GO
BACKUP DATABASE [bdahl_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bdahl_reporting_backup_2020_04_28_115445_8461018.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bdahl_reporting_backup_2020_04_28_115445_8461018', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bdahl_warehouse];
GO
use [master];
GO
BACKUP DATABASE [bdahl_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bdahl_warehouse_backup_2020_04_28_115445_8617310.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bdahl_warehouse_backup_2020_04_28_115445_8617310', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bethel];
GO
use [master];
GO
BACKUP DATABASE [bethel] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bethel_backup_2020_04_28_115445_8773422.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bethel_backup_2020_04_28_115445_8773422', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bethel_lor];
GO
use [master];
GO
BACKUP DATABASE [bethel_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bethel_lor_backup_2020_04_28_115445_8929803.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bethel_lor_backup_2020_04_28_115445_8929803', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bethel_reporting];
GO
use [master];
GO
BACKUP DATABASE [bethel_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bethel_reporting_backup_2020_04_28_115445_8929803.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bethel_reporting_backup_2020_04_28_115445_8929803', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [bethel_warehouse];
GO
use [master];
GO
BACKUP DATABASE [bethel_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\bethel_warehouse_backup_2020_04_28_115445_9085870.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'bethel_warehouse_backup_2020_04_28_115445_9085870', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [boisestate];
GO
use [master];
GO
BACKUP DATABASE [boisestate] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\boisestate_backup_2020_04_28_115445_9243513.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'boisestate_backup_2020_04_28_115445_9243513', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [boisestate_lor];
GO
use [master];
GO
BACKUP DATABASE [boisestate_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\boisestate_lor_backup_2020_04_28_115445_9398466.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'boisestate_lor_backup_2020_04_28_115445_9398466', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [boisestate_reporting];
GO
use [master];
GO
BACKUP DATABASE [boisestate_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\boisestate_reporting_backup_2020_04_28_115445_9555310.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'boisestate_reporting_backup_2020_04_28_115445_9555310', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [boisestate_warehouse];
GO
use [master];
GO
BACKUP DATABASE [boisestate_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\boisestate_warehouse_backup_2020_04_28_115445_9711257.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'boisestate_warehouse_backup_2020_04_28_115445_9711257', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [brightspacea11y];
GO
use [master];
GO
BACKUP DATABASE [brightspacea11y] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\brightspacea11y_backup_2020_04_28_115445_9882650.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'brightspacea11y_backup_2020_04_28_115445_9882650', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [brightspacea11y_lor];
GO
use [master];
GO
BACKUP DATABASE [brightspacea11y_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\brightspacea11y_lor_backup_2020_04_28_115445_9882650.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'brightspacea11y_lor_backup_2020_04_28_115445_9882650', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [brightspacea11y_reporting];
GO
use [master];
GO
BACKUP DATABASE [brightspacea11y_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\brightspacea11y_reporting_backup_2020_04_28_115446_0024952.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'brightspacea11y_reporting_backup_2020_04_28_115446_0024952', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [brightspacea11y_warehouse];
GO
use [master];
GO
BACKUP DATABASE [brightspacea11y_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\brightspacea11y_warehouse_backup_2020_04_28_115446_0179900.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'brightspacea11y_warehouse_backup_2020_04_28_115446_0179900', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [businessithe3];
GO
use [master];
GO
BACKUP DATABASE [businessithe3] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\businessithe3_backup_2020_04_28_115446_0336149.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'businessithe3_backup_2020_04_28_115446_0336149', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [businessithe3_lor];
GO
use [master];
GO
BACKUP DATABASE [businessithe3_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\businessithe3_lor_backup_2020_04_28_115446_0493427.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'businessithe3_lor_backup_2020_04_28_115446_0493427', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [businessithe3_reporting];
GO
use [master];
GO
BACKUP DATABASE [businessithe3_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\businessithe3_reporting_backup_2020_04_28_115446_0648420.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'businessithe3_reporting_backup_2020_04_28_115446_0648420', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [businessithe3_warehouse];
GO
use [master];
GO
BACKUP DATABASE [businessithe3_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\businessithe3_warehouse_backup_2020_04_28_115446_0804698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'businessithe3_warehouse_backup_2020_04_28_115446_0804698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [caanz1];
GO
use [master];
GO
BACKUP DATABASE [caanz1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\caanz1_backup_2020_04_28_115446_0960956.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'caanz1_backup_2020_04_28_115446_0960956', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [caanz1_lor];
GO
use [master];
GO
BACKUP DATABASE [caanz1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\caanz1_lor_backup_2020_04_28_115446_1117206.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'caanz1_lor_backup_2020_04_28_115446_1117206', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [caanz1_reporting];
GO
use [master];
GO
BACKUP DATABASE [caanz1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\caanz1_reporting_backup_2020_04_28_115446_1273480.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'caanz1_reporting_backup_2020_04_28_115446_1273480', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [caanz1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [caanz1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\caanz1_warehouse_backup_2020_04_28_115446_1273480.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'caanz1_warehouse_backup_2020_04_28_115446_1273480', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cabrini];
GO
use [master];
GO
BACKUP DATABASE [cabrini] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cabrini_backup_2020_04_28_115446_1429951.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cabrini_backup_2020_04_28_115446_1429951', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cabrini_lor];
GO
use [master];
GO
BACKUP DATABASE [cabrini_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cabrini_lor_backup_2020_04_28_115446_1586057.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cabrini_lor_backup_2020_04_28_115446_1586057', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cabrini_reporting];
GO
use [master];
GO
BACKUP DATABASE [cabrini_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cabrini_reporting_backup_2020_04_28_115446_1742397.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cabrini_reporting_backup_2020_04_28_115446_1742397', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cabrini_warehouse];
GO
use [master];
GO
BACKUP DATABASE [cabrini_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cabrini_warehouse_backup_2020_04_28_115446_1898389.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cabrini_warehouse_backup_2020_04_28_115446_1898389', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [carleton];
GO
use [master];
GO
BACKUP DATABASE [carleton] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\carleton_backup_2020_04_28_115446_2054671.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'carleton_backup_2020_04_28_115446_2054671', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [carleton_lor];
GO
use [master];
GO
BACKUP DATABASE [carleton_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\carleton_lor_backup_2020_04_28_115446_2210909.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'carleton_lor_backup_2020_04_28_115446_2210909', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [carleton_reporting];
GO
use [master];
GO
BACKUP DATABASE [carleton_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\carleton_reporting_backup_2020_04_28_115446_2367195.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'carleton_reporting_backup_2020_04_28_115446_2367195', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [carleton_warehouse];
GO
use [master];
GO
BACKUP DATABASE [carleton_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\carleton_warehouse_backup_2020_04_28_115446_2367195.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'carleton_warehouse_backup_2020_04_28_115446_2367195', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [catolicadelnorte];
GO
use [master];
GO
BACKUP DATABASE [catolicadelnorte] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\catolicadelnorte_backup_2020_04_28_115446_2523392.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'catolicadelnorte_backup_2020_04_28_115446_2523392', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [catolicadelnorte_lor];
GO
use [master];
GO
BACKUP DATABASE [catolicadelnorte_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\catolicadelnorte_lor_backup_2020_04_28_115446_2681079.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'catolicadelnorte_lor_backup_2020_04_28_115446_2681079', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [catolicadelnorte_reporting];
GO
use [master];
GO
BACKUP DATABASE [catolicadelnorte_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\catolicadelnorte_reporting_backup_2020_04_28_115446_2836178.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'catolicadelnorte_reporting_backup_2020_04_28_115446_2836178', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [catolicadelnorte_warehouse];
GO
use [master];
GO
BACKUP DATABASE [catolicadelnorte_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\catolicadelnorte_warehouse_backup_2020_04_28_115446_2992149.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'catolicadelnorte_warehouse_backup_2020_04_28_115446_2992149', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cca];
GO
use [master];
GO
BACKUP DATABASE [cca] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cca_backup_2020_04_28_115446_3148542.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cca_backup_2020_04_28_115446_3148542', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cca_lor];
GO
use [master];
GO
BACKUP DATABASE [cca_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cca_lor_backup_2020_04_28_115446_3319267.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cca_lor_backup_2020_04_28_115446_3319267', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cca_reporting];
GO
use [master];
GO
BACKUP DATABASE [cca_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cca_reporting_backup_2020_04_28_115446_3461255.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cca_reporting_backup_2020_04_28_115446_3461255', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cca_warehouse];
GO
use [master];
GO
BACKUP DATABASE [cca_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cca_warehouse_backup_2020_04_28_115446_3617427.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cca_warehouse_backup_2020_04_28_115446_3617427', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ccbcmd];
GO
use [master];
GO
BACKUP DATABASE [ccbcmd] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ccbcmd_backup_2020_04_28_115446_3773701.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ccbcmd_backup_2020_04_28_115446_3773701', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ccbcmd_lor];
GO
use [master];
GO
BACKUP DATABASE [ccbcmd_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ccbcmd_lor_backup_2020_04_28_115446_3929955.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ccbcmd_lor_backup_2020_04_28_115446_3929955', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ccbcmd_reporting];
GO
use [master];
GO
BACKUP DATABASE [ccbcmd_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ccbcmd_reporting_backup_2020_04_28_115446_3929955.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ccbcmd_reporting_backup_2020_04_28_115446_3929955', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ccbcmd_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ccbcmd_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ccbcmd_warehouse_backup_2020_04_28_115446_4086025.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ccbcmd_warehouse_backup_2020_04_28_115446_4086025', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ceipacorp];
GO
use [master];
GO
BACKUP DATABASE [ceipacorp] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ceipacorp_backup_2020_04_28_115446_5336174.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ceipacorp_backup_2020_04_28_115446_5336174', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ceipacorp_lor];
GO
use [master];
GO
BACKUP DATABASE [ceipacorp_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ceipacorp_lor_backup_2020_04_28_115446_5492293.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ceipacorp_lor_backup_2020_04_28_115446_5492293', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ceipacorp_reporting];
GO
use [master];
GO
BACKUP DATABASE [ceipacorp_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ceipacorp_reporting_backup_2020_04_28_115446_5492293.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ceipacorp_reporting_backup_2020_04_28_115446_5492293', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ceipacorp_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ceipacorp_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ceipacorp_warehouse_backup_2020_04_28_115446_5649108.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ceipacorp_warehouse_backup_2020_04_28_115446_5649108', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [centrumpucp];
GO
use [master];
GO
BACKUP DATABASE [centrumpucp] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\centrumpucp_backup_2020_04_28_115446_5804641.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'centrumpucp_backup_2020_04_28_115446_5804641', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [centrumpucp_lor];
GO
use [master];
GO
BACKUP DATABASE [centrumpucp_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\centrumpucp_lor_backup_2020_04_28_115446_5961066.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'centrumpucp_lor_backup_2020_04_28_115446_5961066', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [centrumpucp_reporting];
GO
use [master];
GO
BACKUP DATABASE [centrumpucp_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\centrumpucp_reporting_backup_2020_04_28_115446_6117202.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'centrumpucp_reporting_backup_2020_04_28_115446_6117202', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [centrumpucp_warehouse];
GO
use [master];
GO
BACKUP DATABASE [centrumpucp_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\centrumpucp_warehouse_backup_2020_04_28_115446_6273521.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'centrumpucp_warehouse_backup_2020_04_28_115446_6273521', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ciidemo];
GO
use [master];
GO
BACKUP DATABASE [ciidemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ciidemo_backup_2020_04_28_115446_6429738.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ciidemo_backup_2020_04_28_115446_6429738', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ciidemo_lor];
GO
use [master];
GO
BACKUP DATABASE [ciidemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ciidemo_lor_backup_2020_04_28_115446_6586029.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ciidemo_lor_backup_2020_04_28_115446_6586029', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ciidemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [ciidemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ciidemo_reporting_backup_2020_04_28_115446_6742352.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ciidemo_reporting_backup_2020_04_28_115446_6742352', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ciidemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ciidemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ciidemo_warehouse_backup_2020_04_28_115446_6898626.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ciidemo_warehouse_backup_2020_04_28_115446_6898626', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cisco];
GO
use [master];
GO
BACKUP DATABASE [cisco] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cisco_backup_2020_04_28_115446_6898626.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cisco_backup_2020_04_28_115446_6898626', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cisco_lor];
GO
use [master];
GO
BACKUP DATABASE [cisco_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cisco_lor_backup_2020_04_28_115446_7054811.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cisco_lor_backup_2020_04_28_115446_7054811', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cisco_reporting];
GO
use [master];
GO
BACKUP DATABASE [cisco_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cisco_reporting_backup_2020_04_28_115446_7211241.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cisco_reporting_backup_2020_04_28_115446_7211241', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cisco_warehouse];
GO
use [master];
GO
BACKUP DATABASE [cisco_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cisco_warehouse_backup_2020_04_28_115446_7367445.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cisco_warehouse_backup_2020_04_28_115446_7367445', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [clienttest];
GO
use [master];
GO
BACKUP DATABASE [clienttest] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\clienttest_backup_2020_04_28_115446_7523830.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'clienttest_backup_2020_04_28_115446_7523830', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [clienttest_lor];
GO
use [master];
GO
BACKUP DATABASE [clienttest_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\clienttest_lor_backup_2020_04_28_115446_7679842.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'clienttest_lor_backup_2020_04_28_115446_7679842', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [clienttest_reporting];
GO
use [master];
GO
BACKUP DATABASE [clienttest_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\clienttest_reporting_backup_2020_04_28_115446_7679842.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'clienttest_reporting_backup_2020_04_28_115446_7679842', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [clienttest_warehouse];
GO
use [master];
GO
BACKUP DATABASE [clienttest_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\clienttest_warehouse_backup_2020_04_28_115446_7836096.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'clienttest_warehouse_backup_2020_04_28_115446_7836096', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [comfama];
GO
use [master];
GO
BACKUP DATABASE [comfama] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\comfama_backup_2020_04_28_115446_7992280.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'comfama_backup_2020_04_28_115446_7992280', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [comfama_lor];
GO
use [master];
GO
BACKUP DATABASE [comfama_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\comfama_lor_backup_2020_04_28_115446_8148706.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'comfama_lor_backup_2020_04_28_115446_8148706', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [comfama_reporting];
GO
use [master];
GO
BACKUP DATABASE [comfama_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\comfama_reporting_backup_2020_04_28_115446_8304936.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'comfama_reporting_backup_2020_04_28_115446_8304936', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [comfama_warehouse];
GO
use [master];
GO
BACKUP DATABASE [comfama_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\comfama_warehouse_backup_2020_04_28_115446_8460919.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'comfama_warehouse_backup_2020_04_28_115446_8460919', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [conference19];
GO
use [master];
GO
BACKUP DATABASE [conference19] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\conference19_backup_2020_04_28_115446_8617304.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'conference19_backup_2020_04_28_115446_8617304', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [conference19_lor];
GO
use [master];
GO
BACKUP DATABASE [conference19_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\conference19_lor_backup_2020_04_28_115446_8773570.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'conference19_lor_backup_2020_04_28_115446_8773570', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [conference19_reporting];
GO
use [master];
GO
BACKUP DATABASE [conference19_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\conference19_reporting_backup_2020_04_28_115446_8773570.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'conference19_reporting_backup_2020_04_28_115446_8773570', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [conference19_warehouse];
GO
use [master];
GO
BACKUP DATABASE [conference19_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\conference19_warehouse_backup_2020_04_28_115446_8929758.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'conference19_warehouse_backup_2020_04_28_115446_8929758', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [credly];
GO
use [master];
GO
BACKUP DATABASE [credly] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\credly_backup_2020_04_28_115446_9086102.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'credly_backup_2020_04_28_115446_9086102', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [credly_lor];
GO
use [master];
GO
BACKUP DATABASE [credly_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\credly_lor_backup_2020_04_28_115446_9242381.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'credly_lor_backup_2020_04_28_115446_9242381', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [credly_reporting];
GO
use [master];
GO
BACKUP DATABASE [credly_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\credly_reporting_backup_2020_04_28_115446_9398508.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'credly_reporting_backup_2020_04_28_115446_9398508', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [credly_warehouse];
GO
use [master];
GO
BACKUP DATABASE [credly_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\credly_warehouse_backup_2020_04_28_115446_9554704.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'credly_warehouse_backup_2020_04_28_115446_9554704', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [critiqueit];
GO
use [master];
GO
BACKUP DATABASE [critiqueit] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\critiqueit_backup_2020_04_28_115446_9554704.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'critiqueit_backup_2020_04_28_115446_9554704', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [critiqueit_lor];
GO
use [master];
GO
BACKUP DATABASE [critiqueit_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\critiqueit_lor_backup_2020_04_28_115446_9711060.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'critiqueit_lor_backup_2020_04_28_115446_9711060', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [critiqueit_reporting];
GO
use [master];
GO
BACKUP DATABASE [critiqueit_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\critiqueit_reporting_backup_2020_04_28_115446_9867257.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'critiqueit_reporting_backup_2020_04_28_115446_9867257', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [critiqueit_warehouse];
GO
use [master];
GO
BACKUP DATABASE [critiqueit_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\critiqueit_warehouse_backup_2020_04_28_115447_0023720.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'critiqueit_warehouse_backup_2020_04_28_115447_0023720', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [csctrial];
GO
use [master];
GO
BACKUP DATABASE [csctrial] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\csctrial_backup_2020_04_28_115447_0179801.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'csctrial_backup_2020_04_28_115447_0179801', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [csctrial_lor];
GO
use [master];
GO
BACKUP DATABASE [csctrial_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\csctrial_lor_backup_2020_04_28_115447_0336297.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'csctrial_lor_backup_2020_04_28_115447_0336297', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [csctrial_reporting];
GO
use [master];
GO
BACKUP DATABASE [csctrial_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\csctrial_reporting_backup_2020_04_28_115447_0336297.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'csctrial_reporting_backup_2020_04_28_115447_0336297', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [csctrial_warehouse];
GO
use [master];
GO
BACKUP DATABASE [csctrial_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\csctrial_warehouse_backup_2020_04_28_115447_0492354.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'csctrial_warehouse_backup_2020_04_28_115447_0492354', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cspssandbox];
GO
use [master];
GO
BACKUP DATABASE [cspssandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cspssandbox_backup_2020_04_28_115447_0648624.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cspssandbox_backup_2020_04_28_115447_0648624', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cspssandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [cspssandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cspssandbox_lor_backup_2020_04_28_115447_0804825.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cspssandbox_lor_backup_2020_04_28_115447_0804825', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cspssandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [cspssandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cspssandbox_reporting_backup_2020_04_28_115447_0960997.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cspssandbox_reporting_backup_2020_04_28_115447_0960997', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [cspssandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [cspssandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\cspssandbox_warehouse_backup_2020_04_28_115447_1117456.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'cspssandbox_warehouse_backup_2020_04_28_115447_1117456', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lbrasil];
GO
use [master];
GO
BACKUP DATABASE [d2lbrasil] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lbrasil_backup_2020_04_28_115447_1273877.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lbrasil_backup_2020_04_28_115447_1273877', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lbrasil_lor];
GO
use [master];
GO
BACKUP DATABASE [d2lbrasil_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lbrasil_lor_backup_2020_04_28_115447_1273877.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lbrasil_lor_backup_2020_04_28_115447_1273877', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lbrasil_reporting];
GO
use [master];
GO
BACKUP DATABASE [d2lbrasil_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lbrasil_reporting_backup_2020_04_28_115447_1429959.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lbrasil_reporting_backup_2020_04_28_115447_1429959', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lbrasil_warehouse];
GO
use [master];
GO
BACKUP DATABASE [d2lbrasil_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lbrasil_warehouse_backup_2020_04_28_115447_1586111.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lbrasil_warehouse_backup_2020_04_28_115447_1586111', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lent];
GO
use [master];
GO
BACKUP DATABASE [d2lent] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lent_backup_2020_04_28_115447_1742295.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lent_backup_2020_04_28_115447_1742295', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lent_lor];
GO
use [master];
GO
BACKUP DATABASE [d2lent_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lent_lor_backup_2020_04_28_115447_1898532.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lent_lor_backup_2020_04_28_115447_1898532', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lent_reporting];
GO
use [master];
GO
BACKUP DATABASE [d2lent_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lent_reporting_backup_2020_04_28_115447_2054733.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lent_reporting_backup_2020_04_28_115447_2054733', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lent_warehouse];
GO
use [master];
GO
BACKUP DATABASE [d2lent_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lent_warehouse_backup_2020_04_28_115447_2211073.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lent_warehouse_backup_2020_04_28_115447_2211073', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lhe];
GO
use [master];
GO
BACKUP DATABASE [d2lhe] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lhe_backup_2020_04_28_115447_2211073.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lhe_backup_2020_04_28_115447_2211073', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lhe_lor];
GO
use [master];
GO
BACKUP DATABASE [d2lhe_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lhe_lor_backup_2020_04_28_115447_2367240.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lhe_lor_backup_2020_04_28_115447_2367240', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lhe_reporting];
GO
use [master];
GO
BACKUP DATABASE [d2lhe_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lhe_reporting_backup_2020_04_28_115447_2523728.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lhe_reporting_backup_2020_04_28_115447_2523728', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [d2lhe_warehouse];
GO
use [master];
GO
BACKUP DATABASE [d2lhe_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\d2lhe_warehouse_backup_2020_04_28_115447_2679990.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'd2lhe_warehouse_backup_2020_04_28_115447_2679990', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [darmstrong];
GO
use [master];
GO
BACKUP DATABASE [darmstrong] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\darmstrong_backup_2020_04_28_115447_2836043.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'darmstrong_backup_2020_04_28_115447_2836043', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [darmstrong_lor];
GO
use [master];
GO
BACKUP DATABASE [darmstrong_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\darmstrong_lor_backup_2020_04_28_115447_2992280.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'darmstrong_lor_backup_2020_04_28_115447_2992280', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [darmstrong_reporting];
GO
use [master];
GO
BACKUP DATABASE [darmstrong_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\darmstrong_reporting_backup_2020_04_28_115447_3148534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'darmstrong_reporting_backup_2020_04_28_115447_3148534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [darmstrong_warehouse];
GO
use [master];
GO
BACKUP DATABASE [darmstrong_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\darmstrong_warehouse_backup_2020_04_28_115447_3148534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'darmstrong_warehouse_backup_2020_04_28_115447_3148534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dcouto];
GO
use [master];
GO
BACKUP DATABASE [dcouto] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dcouto_backup_2020_04_28_115447_3304911.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dcouto_backup_2020_04_28_115447_3304911', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dcouto_lor];
GO
use [master];
GO
BACKUP DATABASE [dcouto_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dcouto_lor_backup_2020_04_28_115447_3461173.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dcouto_lor_backup_2020_04_28_115447_3461173', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dcouto_reporting];
GO
use [master];
GO
BACKUP DATABASE [dcouto_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dcouto_reporting_backup_2020_04_28_115447_3617509.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dcouto_reporting_backup_2020_04_28_115447_3617509', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dcouto_warehouse];
GO
use [master];
GO
BACKUP DATABASE [dcouto_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dcouto_warehouse_backup_2020_04_28_115447_3773644.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dcouto_warehouse_backup_2020_04_28_115447_3773644', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dm];
GO
use [master];
GO
BACKUP DATABASE [dm] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dm_backup_2020_04_28_115447_3930086.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dm_backup_2020_04_28_115447_3930086', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dm_lor];
GO
use [master];
GO
BACKUP DATABASE [dm_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dm_lor_backup_2020_04_28_115447_3930086.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dm_lor_backup_2020_04_28_115447_3930086', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dm_reporting];
GO
use [master];
GO
BACKUP DATABASE [dm_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dm_reporting_backup_2020_04_28_115447_4086172.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dm_reporting_backup_2020_04_28_115447_4086172', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [dm_warehouse];
GO
use [master];
GO
BACKUP DATABASE [dm_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\dm_warehouse_backup_2020_04_28_115447_4242405.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'dm_warehouse_backup_2020_04_28_115447_4242405', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecopetrol];
GO
use [master];
GO
BACKUP DATABASE [ecopetrol] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecopetrol_backup_2020_04_28_115447_4398508.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecopetrol_backup_2020_04_28_115447_4398508', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecopetrol_lor];
GO
use [master];
GO
BACKUP DATABASE [ecopetrol_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecopetrol_lor_backup_2020_04_28_115447_4554798.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecopetrol_lor_backup_2020_04_28_115447_4554798', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecopetrol_reporting];
GO
use [master];
GO
BACKUP DATABASE [ecopetrol_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecopetrol_reporting_backup_2020_04_28_115447_4711232.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecopetrol_reporting_backup_2020_04_28_115447_4711232', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecopetrol_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ecopetrol_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecopetrol_warehouse_backup_2020_04_28_115447_4867286.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecopetrol_warehouse_backup_2020_04_28_115447_4867286', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecudemo];
GO
use [master];
GO
BACKUP DATABASE [ecudemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecudemo_backup_2020_04_28_115447_4867286.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecudemo_backup_2020_04_28_115447_4867286', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecudemo_lor];
GO
use [master];
GO
BACKUP DATABASE [ecudemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecudemo_lor_backup_2020_04_28_115447_5023687.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecudemo_lor_backup_2020_04_28_115447_5023687', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecudemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [ecudemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecudemo_reporting_backup_2020_04_28_115447_5179900.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecudemo_reporting_backup_2020_04_28_115447_5179900', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ecudemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ecudemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ecudemo_warehouse_backup_2020_04_28_115447_5336137.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ecudemo_warehouse_backup_2020_04_28_115447_5336137', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ellucian];
GO
use [master];
GO
BACKUP DATABASE [ellucian] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ellucian_backup_2020_04_28_115447_5492497.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ellucian_backup_2020_04_28_115447_5492497', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ellucian_lor];
GO
use [master];
GO
BACKUP DATABASE [ellucian_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ellucian_lor_backup_2020_04_28_115447_5648559.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ellucian_lor_backup_2020_04_28_115447_5648559', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ellucian_reporting];
GO
use [master];
GO
BACKUP DATABASE [ellucian_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ellucian_reporting_backup_2020_04_28_115447_5648559.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ellucian_reporting_backup_2020_04_28_115447_5648559', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ellucian_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ellucian_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ellucian_warehouse_backup_2020_04_28_115447_5804981.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ellucian_warehouse_backup_2020_04_28_115447_5804981', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [elluciandemo];
GO
use [master];
GO
BACKUP DATABASE [elluciandemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\elluciandemo_backup_2020_04_28_115447_5961234.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'elluciandemo_backup_2020_04_28_115447_5961234', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [elluciandemo_lor];
GO
use [master];
GO
BACKUP DATABASE [elluciandemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\elluciandemo_lor_backup_2020_04_28_115447_6118889.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'elluciandemo_lor_backup_2020_04_28_115447_6118889', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [elluciandemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [elluciandemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\elluciandemo_reporting_backup_2020_04_28_115447_6283945.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'elluciandemo_reporting_backup_2020_04_28_115447_6283945', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [elluciandemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [elluciandemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\elluciandemo_warehouse_backup_2020_04_28_115447_6432875.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'elluciandemo_warehouse_backup_2020_04_28_115447_6432875', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [Elsevier];
GO
use [master];
GO
BACKUP DATABASE [Elsevier] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\Elsevier_backup_2020_04_28_115447_6607451.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Elsevier_backup_2020_04_28_115447_6607451', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [Elsevier_lor];
GO
use [master];
GO
BACKUP DATABASE [Elsevier_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\Elsevier_lor_backup_2020_04_28_115447_6746641.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Elsevier_lor_backup_2020_04_28_115447_6746641', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [Elsevier_reporting];
GO
use [master];
GO
BACKUP DATABASE [Elsevier_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\Elsevier_reporting_backup_2020_04_28_115447_6900453.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Elsevier_reporting_backup_2020_04_28_115447_6900453', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [Elsevier_warehouse];
GO
use [master];
GO
BACKUP DATABASE [Elsevier_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\Elsevier_warehouse_backup_2020_04_28_115447_7059541.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Elsevier_warehouse_backup_2020_04_28_115447_7059541', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emea];
GO
use [master];
GO
BACKUP DATABASE [emea] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emea_backup_2020_04_28_115447_7213366.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emea_backup_2020_04_28_115447_7213366', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emea_lor];
GO
use [master];
GO
BACKUP DATABASE [emea_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emea_lor_backup_2020_04_28_115447_7369071.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emea_lor_backup_2020_04_28_115447_7369071', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emea_reporting];
GO
use [master];
GO
BACKUP DATABASE [emea_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emea_reporting_backup_2020_04_28_115447_7525972.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emea_reporting_backup_2020_04_28_115447_7525972', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emea_warehouse];
GO
use [master];
GO
BACKUP DATABASE [emea_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emea_warehouse_backup_2020_04_28_115447_7683619.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emea_warehouse_backup_2020_04_28_115447_7683619', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emeaent];
GO
use [master];
GO
BACKUP DATABASE [emeaent] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emeaent_backup_2020_04_28_115447_7837812.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emeaent_backup_2020_04_28_115447_7837812', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emeaent_lor];
GO
use [master];
GO
BACKUP DATABASE [emeaent_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emeaent_lor_backup_2020_04_28_115447_7837812.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emeaent_lor_backup_2020_04_28_115447_7837812', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emeaent_reporting];
GO
use [master];
GO
BACKUP DATABASE [emeaent_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emeaent_reporting_backup_2020_04_28_115447_7995868.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emeaent_reporting_backup_2020_04_28_115447_7995868', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [emeaent_warehouse];
GO
use [master];
GO
BACKUP DATABASE [emeaent_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\emeaent_warehouse_backup_2020_04_28_115447_8165582.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'emeaent_warehouse_backup_2020_04_28_115447_8165582', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entdemo];
GO
use [master];
GO
BACKUP DATABASE [entdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entdemo_backup_2020_04_28_115447_8307475.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entdemo_backup_2020_04_28_115447_8307475', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [entdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entdemo_lor_backup_2020_04_28_115447_8496505.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entdemo_lor_backup_2020_04_28_115447_8496505', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [entdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entdemo_reporting_backup_2020_04_28_115447_8622465.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entdemo_reporting_backup_2020_04_28_115447_8622465', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [entdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entdemo_warehouse_backup_2020_04_28_115447_8778760.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entdemo_warehouse_backup_2020_04_28_115447_8778760', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entsales];
GO
use [master];
GO
BACKUP DATABASE [entsales] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entsales_backup_2020_04_28_115447_8931565.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entsales_backup_2020_04_28_115447_8931565', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entsales_lor];
GO
use [master];
GO
BACKUP DATABASE [entsales_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entsales_lor_backup_2020_04_28_115447_9088871.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entsales_lor_backup_2020_04_28_115447_9088871', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entsales_reporting];
GO
use [master];
GO
BACKUP DATABASE [entsales_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entsales_reporting_backup_2020_04_28_115447_9244523.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entsales_reporting_backup_2020_04_28_115447_9244523', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [entsales_warehouse];
GO
use [master];
GO
BACKUP DATABASE [entsales_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\entsales_warehouse_backup_2020_04_28_115447_9401674.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'entsales_warehouse_backup_2020_04_28_115447_9401674', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ep];
GO
use [master];
GO
BACKUP DATABASE [ep] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ep_backup_2020_04_28_115447_9401674.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ep_backup_2020_04_28_115447_9401674', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ep_lor];
GO
use [master];
GO
BACKUP DATABASE [ep_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ep_lor_backup_2020_04_28_115447_9556871.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ep_lor_backup_2020_04_28_115447_9556871', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ep_reporting];
GO
use [master];
GO
BACKUP DATABASE [ep_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ep_reporting_backup_2020_04_28_115447_9714837.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ep_reporting_backup_2020_04_28_115447_9714837', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ep_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ep_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ep_warehouse_backup_2020_04_28_115447_9868908.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ep_warehouse_backup_2020_04_28_115447_9868908', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [evanza];
GO
use [master];
GO
BACKUP DATABASE [evanza] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\evanza_backup_2020_04_28_115448_0025841.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'evanza_backup_2020_04_28_115448_0025841', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [evanza_lor];
GO
use [master];
GO
BACKUP DATABASE [evanza_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\evanza_lor_backup_2020_04_28_115448_0184528.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'evanza_lor_backup_2020_04_28_115448_0184528', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [evanza_reporting];
GO
use [master];
GO
BACKUP DATABASE [evanza_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\evanza_reporting_backup_2020_04_28_115448_0184528.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'evanza_reporting_backup_2020_04_28_115448_0184528', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [evanza_warehouse];
GO
use [master];
GO
BACKUP DATABASE [evanza_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\evanza_warehouse_backup_2020_04_28_115448_0338906.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'evanza_warehouse_backup_2020_04_28_115448_0338906', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [examity];
GO
use [master];
GO
BACKUP DATABASE [examity] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\examity_backup_2020_04_28_115448_0494189.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'examity_backup_2020_04_28_115448_0494189', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [examity_lor];
GO
use [master];
GO
BACKUP DATABASE [examity_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\examity_lor_backup_2020_04_28_115448_0652094.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'examity_lor_backup_2020_04_28_115448_0652094', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [examity_reporting];
GO
use [master];
GO
BACKUP DATABASE [examity_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\examity_reporting_backup_2020_04_28_115448_0807500.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'examity_reporting_backup_2020_04_28_115448_0807500', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [examity_warehouse];
GO
use [master];
GO
BACKUP DATABASE [examity_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\examity_warehouse_backup_2020_04_28_115448_0963188.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'examity_warehouse_backup_2020_04_28_115448_0963188', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [explorancedemo];
GO
use [master];
GO
BACKUP DATABASE [explorancedemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\explorancedemo_backup_2020_04_28_115448_1118824.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'explorancedemo_backup_2020_04_28_115448_1118824', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [explorancedemo_lor];
GO
use [master];
GO
BACKUP DATABASE [explorancedemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\explorancedemo_lor_backup_2020_04_28_115448_1279853.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'explorancedemo_lor_backup_2020_04_28_115448_1279853', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [explorancedemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [explorancedemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\explorancedemo_reporting_backup_2020_04_28_115448_1432155.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'explorancedemo_reporting_backup_2020_04_28_115448_1432155', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [explorancedemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [explorancedemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\explorancedemo_warehouse_backup_2020_04_28_115448_1432155.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'explorancedemo_warehouse_backup_2020_04_28_115448_1432155', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fadavis];
GO
use [master];
GO
BACKUP DATABASE [fadavis] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fadavis_backup_2020_04_28_115448_1588118.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fadavis_backup_2020_04_28_115448_1588118', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fadavis_lor];
GO
use [master];
GO
BACKUP DATABASE [fadavis_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fadavis_lor_backup_2020_04_28_115448_1745817.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fadavis_lor_backup_2020_04_28_115448_1745817', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fadavis_reporting];
GO
use [master];
GO
BACKUP DATABASE [fadavis_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fadavis_reporting_backup_2020_04_28_115448_1900072.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fadavis_reporting_backup_2020_04_28_115448_1900072', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fadavis_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fadavis_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fadavis_warehouse_backup_2020_04_28_115448_2060144.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fadavis_warehouse_backup_2020_04_28_115448_2060144', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [farshler];
GO
use [master];
GO
BACKUP DATABASE [farshler] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\farshler_backup_2020_04_28_115448_2214169.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'farshler_backup_2020_04_28_115448_2214169', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [farshler_lor];
GO
use [master];
GO
BACKUP DATABASE [farshler_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\farshler_lor_backup_2020_04_28_115448_2369243.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'farshler_lor_backup_2020_04_28_115448_2369243', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [farshler_reporting];
GO
use [master];
GO
BACKUP DATABASE [farshler_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\farshler_reporting_backup_2020_04_28_115448_2526370.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'farshler_reporting_backup_2020_04_28_115448_2526370', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [farshler_warehouse];
GO
use [master];
GO
BACKUP DATABASE [farshler_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\farshler_warehouse_backup_2020_04_28_115448_2526370.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'farshler_warehouse_backup_2020_04_28_115448_2526370', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fcamargo];
GO
use [master];
GO
BACKUP DATABASE [fcamargo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fcamargo_backup_2020_04_28_115448_2687133.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fcamargo_backup_2020_04_28_115448_2687133', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fcamargo_lor];
GO
use [master];
GO
BACKUP DATABASE [fcamargo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fcamargo_lor_backup_2020_04_28_115448_2837956.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fcamargo_lor_backup_2020_04_28_115448_2837956', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fcamargo_reporting];
GO
use [master];
GO
BACKUP DATABASE [fcamargo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fcamargo_reporting_backup_2020_04_28_115448_2994246.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fcamargo_reporting_backup_2020_04_28_115448_2994246', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fcamargo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fcamargo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fcamargo_warehouse_backup_2020_04_28_115448_3153580.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fcamargo_warehouse_backup_2020_04_28_115448_3153580', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fishtailtech];
GO
use [master];
GO
BACKUP DATABASE [fishtailtech] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fishtailtech_backup_2020_04_28_115448_3306594.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fishtailtech_backup_2020_04_28_115448_3306594', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fishtailtech_lor];
GO
use [master];
GO
BACKUP DATABASE [fishtailtech_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fishtailtech_lor_backup_2020_04_28_115448_3493343.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fishtailtech_lor_backup_2020_04_28_115448_3493343', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fishtailtech_reporting];
GO
use [master];
GO
BACKUP DATABASE [fishtailtech_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fishtailtech_reporting_backup_2020_04_28_115448_3688607.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fishtailtech_reporting_backup_2020_04_28_115448_3688607', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fishtailtech_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fishtailtech_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fishtailtech_warehouse_backup_2020_04_28_115448_3835223.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fishtailtech_warehouse_backup_2020_04_28_115448_3835223', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion];
GO
use [master];
GO
BACKUP DATABASE [fusion] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion_backup_2020_04_28_115448_4012534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion_backup_2020_04_28_115448_4012534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion_lor];
GO
use [master];
GO
BACKUP DATABASE [fusion_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion_lor_backup_2020_04_28_115448_4012534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion_lor_backup_2020_04_28_115448_4012534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion_reporting];
GO
use [master];
GO
BACKUP DATABASE [fusion_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion_reporting_backup_2020_04_28_115448_4245334.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion_reporting_backup_2020_04_28_115448_4245334', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fusion_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion_warehouse_backup_2020_04_28_115448_4402305.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion_warehouse_backup_2020_04_28_115448_4402305', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion2];
GO
use [master];
GO
BACKUP DATABASE [fusion2] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion2_backup_2020_04_28_115448_4569757.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion2_backup_2020_04_28_115448_4569757', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion2_lor];
GO
use [master];
GO
BACKUP DATABASE [fusion2_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion2_lor_backup_2020_04_28_115448_4714648.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion2_lor_backup_2020_04_28_115448_4714648', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion2_reporting];
GO
use [master];
GO
BACKUP DATABASE [fusion2_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion2_reporting_backup_2020_04_28_115448_4868826.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion2_reporting_backup_2020_04_28_115448_4868826', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion2_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fusion2_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion2_warehouse_backup_2020_04_28_115448_5033181.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion2_warehouse_backup_2020_04_28_115448_5033181', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion3];
GO
use [master];
GO
BACKUP DATABASE [fusion3] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion3_backup_2020_04_28_115448_5033181.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion3_backup_2020_04_28_115448_5033181', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion3_lor];
GO
use [master];
GO
BACKUP DATABASE [fusion3_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion3_lor_backup_2020_04_28_115448_5181567.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion3_lor_backup_2020_04_28_115448_5181567', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion3_reporting];
GO
use [master];
GO
BACKUP DATABASE [fusion3_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion3_reporting_backup_2020_04_28_115448_5338947.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion3_reporting_backup_2020_04_28_115448_5338947', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [fusion3_warehouse];
GO
use [master];
GO
BACKUP DATABASE [fusion3_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\fusion3_warehouse_backup_2020_04_28_115448_5494218.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'fusion3_warehouse_backup_2020_04_28_115448_5494218', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gary];
GO
use [master];
GO
BACKUP DATABASE [gary] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gary_backup_2020_04_28_115448_5653490.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gary_backup_2020_04_28_115448_5653490', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gary_lor];
GO
use [master];
GO
BACKUP DATABASE [gary_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gary_lor_backup_2020_04_28_115448_5806644.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gary_lor_backup_2020_04_28_115448_5806644', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gary_reporting];
GO
use [master];
GO
BACKUP DATABASE [gary_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gary_reporting_backup_2020_04_28_115448_5963143.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gary_reporting_backup_2020_04_28_115448_5963143', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gary_warehouse];
GO
use [master];
GO
BACKUP DATABASE [gary_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gary_warehouse_backup_2020_04_28_115448_6117550.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gary_warehouse_backup_2020_04_28_115448_6117550', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [google];
GO
use [master];
GO
BACKUP DATABASE [google] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\google_backup_2020_04_28_115448_6117550.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'google_backup_2020_04_28_115448_6117550', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [google_lor];
GO
use [master];
GO
BACKUP DATABASE [google_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\google_lor_backup_2020_04_28_115448_6273713.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'google_lor_backup_2020_04_28_115448_6273713', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [google_reporting];
GO
use [master];
GO
BACKUP DATABASE [google_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\google_reporting_backup_2020_04_28_115448_6429975.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'google_reporting_backup_2020_04_28_115448_6429975', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [google_warehouse];
GO
use [master];
GO
BACKUP DATABASE [google_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\google_warehouse_backup_2020_04_28_115448_6586192.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'google_warehouse_backup_2020_04_28_115448_6586192', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gordon];
GO
use [master];
GO
BACKUP DATABASE [gordon] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gordon_backup_2020_04_28_115448_6586192.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gordon_backup_2020_04_28_115448_6586192', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gordon_lor];
GO
use [master];
GO
BACKUP DATABASE [gordon_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gordon_lor_backup_2020_04_28_115448_6742491.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gordon_lor_backup_2020_04_28_115448_6742491', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gordon_reporting];
GO
use [master];
GO
BACKUP DATABASE [gordon_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gordon_reporting_backup_2020_04_28_115448_6898803.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gordon_reporting_backup_2020_04_28_115448_6898803', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [gordon_warehouse];
GO
use [master];
GO
BACKUP DATABASE [gordon_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\gordon_warehouse_backup_2020_04_28_115448_7055060.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'gordon_warehouse_backup_2020_04_28_115448_7055060', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hesales1];
GO
use [master];
GO
BACKUP DATABASE [hesales1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hesales1_backup_2020_04_28_115448_7211159.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hesales1_backup_2020_04_28_115448_7211159', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hesales1_lor];
GO
use [master];
GO
BACKUP DATABASE [hesales1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hesales1_lor_backup_2020_04_28_115448_7367425.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hesales1_lor_backup_2020_04_28_115448_7367425', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hesales1_reporting];
GO
use [master];
GO
BACKUP DATABASE [hesales1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hesales1_reporting_backup_2020_04_28_115448_7367425.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hesales1_reporting_backup_2020_04_28_115448_7367425', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hesales1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [hesales1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hesales1_warehouse_backup_2020_04_28_115448_7523990.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hesales1_warehouse_backup_2020_04_28_115448_7523990', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hillsdale];
GO
use [master];
GO
BACKUP DATABASE [hillsdale] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hillsdale_backup_2020_04_28_115448_7680059.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hillsdale_backup_2020_04_28_115448_7680059', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hillsdale_lor];
GO
use [master];
GO
BACKUP DATABASE [hillsdale_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hillsdale_lor_backup_2020_04_28_115448_7836248.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hillsdale_lor_backup_2020_04_28_115448_7836248', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hillsdale_reporting];
GO
use [master];
GO
BACKUP DATABASE [hillsdale_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hillsdale_reporting_backup_2020_04_28_115448_7836248.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hillsdale_reporting_backup_2020_04_28_115448_7836248', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hillsdale_warehouse];
GO
use [master];
GO
BACKUP DATABASE [hillsdale_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hillsdale_warehouse_backup_2020_04_28_115448_7992436.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hillsdale_warehouse_backup_2020_04_28_115448_7992436', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hr1];
GO
use [master];
GO
BACKUP DATABASE [hr1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hr1_backup_2020_04_28_115448_8148735.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hr1_backup_2020_04_28_115448_8148735', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hr1_lor];
GO
use [master];
GO
BACKUP DATABASE [hr1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hr1_lor_backup_2020_04_28_115448_8305140.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hr1_lor_backup_2020_04_28_115448_8305140', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hr1_reporting];
GO
use [master];
GO
BACKUP DATABASE [hr1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hr1_reporting_backup_2020_04_28_115448_8461341.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hr1_reporting_backup_2020_04_28_115448_8461341', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [hr1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [hr1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\hr1_warehouse_backup_2020_04_28_115448_8617730.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'hr1_warehouse_backup_2020_04_28_115448_8617730', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [humberto];
GO
use [master];
GO
BACKUP DATABASE [humberto] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\humberto_backup_2020_04_28_115448_8617730.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'humberto_backup_2020_04_28_115448_8617730', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [humberto_lor];
GO
use [master];
GO
BACKUP DATABASE [humberto_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\humberto_lor_backup_2020_04_28_115448_8773812.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'humberto_lor_backup_2020_04_28_115448_8773812', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [humberto_reporting];
GO
use [master];
GO
BACKUP DATABASE [humberto_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\humberto_reporting_backup_2020_04_28_115448_8930086.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'humberto_reporting_backup_2020_04_28_115448_8930086', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [humberto_warehouse];
GO
use [master];
GO
BACKUP DATABASE [humberto_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\humberto_warehouse_backup_2020_04_28_115448_9086188.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'humberto_warehouse_backup_2020_04_28_115448_9086188', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [iindemo];
GO
use [master];
GO
BACKUP DATABASE [iindemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\iindemo_backup_2020_04_28_115448_9242672.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'iindemo_backup_2020_04_28_115448_9242672', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [iindemo_lor];
GO
use [master];
GO
BACKUP DATABASE [iindemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\iindemo_lor_backup_2020_04_28_115448_9398868.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'iindemo_lor_backup_2020_04_28_115448_9398868', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [iindemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [iindemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\iindemo_reporting_backup_2020_04_28_115448_9398868.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'iindemo_reporting_backup_2020_04_28_115448_9398868', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [iindemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [iindemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\iindemo_warehouse_backup_2020_04_28_115448_9555069.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'iindemo_warehouse_backup_2020_04_28_115448_9555069', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ingegno];
GO
use [master];
GO
BACKUP DATABASE [ingegno] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ingegno_backup_2020_04_28_115448_9711253.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ingegno_backup_2020_04_28_115448_9711253', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ingegno_lor];
GO
use [master];
GO
BACKUP DATABASE [ingegno_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ingegno_lor_backup_2020_04_28_115448_9867523.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ingegno_lor_backup_2020_04_28_115448_9867523', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ingegno_reporting];
GO
use [master];
GO
BACKUP DATABASE [ingegno_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ingegno_reporting_backup_2020_04_28_115449_0024076.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ingegno_reporting_backup_2020_04_28_115449_0024076', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ingegno_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ingegno_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ingegno_warehouse_backup_2020_04_28_115449_0180018.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ingegno_warehouse_backup_2020_04_28_115449_0180018', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [intodemo];
GO
use [master];
GO
BACKUP DATABASE [intodemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\intodemo_backup_2020_04_28_115449_0180018.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'intodemo_backup_2020_04_28_115449_0180018', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [intodemo_lor];
GO
use [master];
GO
BACKUP DATABASE [intodemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\intodemo_lor_backup_2020_04_28_115449_0336334.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'intodemo_lor_backup_2020_04_28_115449_0336334', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [intodemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [intodemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\intodemo_reporting_backup_2020_04_28_115449_0492461.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'intodemo_reporting_backup_2020_04_28_115449_0492461', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [intodemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [intodemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\intodemo_warehouse_backup_2020_04_28_115449_0648723.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'intodemo_warehouse_backup_2020_04_28_115449_0648723', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [involvio];
GO
use [master];
GO
BACKUP DATABASE [involvio] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\involvio_backup_2020_04_28_115449_0804968.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'involvio_backup_2020_04_28_115449_0804968', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [involvio_lor];
GO
use [master];
GO
BACKUP DATABASE [involvio_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\involvio_lor_backup_2020_04_28_115449_0804968.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'involvio_lor_backup_2020_04_28_115449_0804968', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [involvio_reporting];
GO
use [master];
GO
BACKUP DATABASE [involvio_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\involvio_reporting_backup_2020_04_28_115449_0961181.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'involvio_reporting_backup_2020_04_28_115449_0961181', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [involvio_warehouse];
GO
use [master];
GO
BACKUP DATABASE [involvio_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\involvio_warehouse_backup_2020_04_28_115449_1117509.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'involvio_warehouse_backup_2020_04_28_115449_1117509', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jane];
GO
use [master];
GO
BACKUP DATABASE [jane] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jane_backup_2020_04_28_115449_1273734.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jane_backup_2020_04_28_115449_1273734', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jane_lor];
GO
use [master];
GO
BACKUP DATABASE [jane_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jane_lor_backup_2020_04_28_115449_1430107.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jane_lor_backup_2020_04_28_115449_1430107', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jane_reporting];
GO
use [master];
GO
BACKUP DATABASE [jane_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jane_reporting_backup_2020_04_28_115449_1586274.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jane_reporting_backup_2020_04_28_115449_1586274', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jane_warehouse];
GO
use [master];
GO
BACKUP DATABASE [jane_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jane_warehouse_backup_2020_04_28_115449_1586274.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jane_warehouse_backup_2020_04_28_115449_1586274', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javecolombia];
GO
use [master];
GO
BACKUP DATABASE [javecolombia] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javecolombia_backup_2020_04_28_115449_1742467.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javecolombia_backup_2020_04_28_115449_1742467', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javecolombia_lor];
GO
use [master];
GO
BACKUP DATABASE [javecolombia_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javecolombia_lor_backup_2020_04_28_115449_1898741.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javecolombia_lor_backup_2020_04_28_115449_1898741', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javecolombia_reporting];
GO
use [master];
GO
BACKUP DATABASE [javecolombia_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javecolombia_reporting_backup_2020_04_28_115449_2055020.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javecolombia_reporting_backup_2020_04_28_115449_2055020', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javecolombia_warehouse];
GO
use [master];
GO
BACKUP DATABASE [javecolombia_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javecolombia_warehouse_backup_2020_04_28_115449_2211576.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javecolombia_warehouse_backup_2020_04_28_115449_2211576', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javerianacali];
GO
use [master];
GO
BACKUP DATABASE [javerianacali] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javerianacali_backup_2020_04_28_115449_2211576.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javerianacali_backup_2020_04_28_115449_2211576', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javerianacali_lor];
GO
use [master];
GO
BACKUP DATABASE [javerianacali_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javerianacali_lor_backup_2020_04_28_115449_2367810.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javerianacali_lor_backup_2020_04_28_115449_2367810', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javerianacali_reporting];
GO
use [master];
GO
BACKUP DATABASE [javerianacali_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javerianacali_reporting_backup_2020_04_28_115449_2524203.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javerianacali_reporting_backup_2020_04_28_115449_2524203', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [javerianacali_warehouse];
GO
use [master];
GO
BACKUP DATABASE [javerianacali_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\javerianacali_warehouse_backup_2020_04_28_115449_2680236.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'javerianacali_warehouse_backup_2020_04_28_115449_2680236', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeannettemc];
GO
use [master];
GO
BACKUP DATABASE [jeannettemc] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeannettemc_backup_2020_04_28_115449_2836350.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeannettemc_backup_2020_04_28_115449_2836350', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeannettemc_lor];
GO
use [master];
GO
BACKUP DATABASE [jeannettemc_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeannettemc_lor_backup_2020_04_28_115449_2992547.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeannettemc_lor_backup_2020_04_28_115449_2992547', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeannettemc_reporting];
GO
use [master];
GO
BACKUP DATABASE [jeannettemc_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeannettemc_reporting_backup_2020_04_28_115449_3148764.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeannettemc_reporting_backup_2020_04_28_115449_3148764', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeannettemc_warehouse];
GO
use [master];
GO
BACKUP DATABASE [jeannettemc_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeannettemc_warehouse_backup_2020_04_28_115449_3305136.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeannettemc_warehouse_backup_2020_04_28_115449_3305136', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeffco];
GO
use [master];
GO
BACKUP DATABASE [jeffco] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeffco_backup_2020_04_28_115449_3305136.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeffco_backup_2020_04_28_115449_3305136', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeffco_lor];
GO
use [master];
GO
BACKUP DATABASE [jeffco_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeffco_lor_backup_2020_04_28_115449_3461230.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeffco_lor_backup_2020_04_28_115449_3461230', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeffco_reporting];
GO
use [master];
GO
BACKUP DATABASE [jeffco_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeffco_reporting_backup_2020_04_28_115449_3617603.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeffco_reporting_backup_2020_04_28_115449_3617603', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jeffco_warehouse];
GO
use [master];
GO
BACKUP DATABASE [jeffco_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jeffco_warehouse_backup_2020_04_28_115449_3774029.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jeffco_warehouse_backup_2020_04_28_115449_3774029', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jisctest];
GO
use [master];
GO
BACKUP DATABASE [jisctest] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jisctest_backup_2020_04_28_115449_3930045.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jisctest_backup_2020_04_28_115449_3930045', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jisctest_lor];
GO
use [master];
GO
BACKUP DATABASE [jisctest_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jisctest_lor_backup_2020_04_28_115449_3930045.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jisctest_lor_backup_2020_04_28_115449_3930045', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jisctest_reporting];
GO
use [master];
GO
BACKUP DATABASE [jisctest_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jisctest_reporting_backup_2020_04_28_115449_4086373.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jisctest_reporting_backup_2020_04_28_115449_4086373', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [jisctest_warehouse];
GO
use [master];
GO
BACKUP DATABASE [jisctest_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\jisctest_warehouse_backup_2020_04_28_115449_4243061.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'jisctest_warehouse_backup_2020_04_28_115449_4243061', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joao];
GO
use [master];
GO
BACKUP DATABASE [joao] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joao_backup_2020_04_28_115449_4398909.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joao_backup_2020_04_28_115449_4398909', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joao_lor];
GO
use [master];
GO
BACKUP DATABASE [joao_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joao_lor_backup_2020_04_28_115449_4555376.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joao_lor_backup_2020_04_28_115449_4555376', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joao_reporting];
GO
use [master];
GO
BACKUP DATABASE [joao_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joao_reporting_backup_2020_04_28_115449_4711507.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joao_reporting_backup_2020_04_28_115449_4711507', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joao_warehouse];
GO
use [master];
GO
BACKUP DATABASE [joao_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joao_warehouse_backup_2020_04_28_115449_4711507.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joao_warehouse_backup_2020_04_28_115449_4711507', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joelcorp];
GO
use [master];
GO
BACKUP DATABASE [joelcorp] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joelcorp_backup_2020_04_28_115449_4867818.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joelcorp_backup_2020_04_28_115449_4867818', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joelcorp_lor];
GO
use [master];
GO
BACKUP DATABASE [joelcorp_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joelcorp_lor_backup_2020_04_28_115449_5024219.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joelcorp_lor_backup_2020_04_28_115449_5024219', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joelcorp_reporting];
GO
use [master];
GO
BACKUP DATABASE [joelcorp_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joelcorp_reporting_backup_2020_04_28_115449_5180428.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joelcorp_reporting_backup_2020_04_28_115449_5180428', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joelcorp_warehouse];
GO
use [master];
GO
BACKUP DATABASE [joelcorp_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joelcorp_warehouse_backup_2020_04_28_115449_5336453.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joelcorp_warehouse_backup_2020_04_28_115449_5336453', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joubel];
GO
use [master];
GO
BACKUP DATABASE [joubel] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joubel_backup_2020_04_28_115449_5336453.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joubel_backup_2020_04_28_115449_5336453', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joubel_lor];
GO
use [master];
GO
BACKUP DATABASE [joubel_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joubel_lor_backup_2020_04_28_115449_5492915.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joubel_lor_backup_2020_04_28_115449_5492915', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joubel_reporting];
GO
use [master];
GO
BACKUP DATABASE [joubel_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joubel_reporting_backup_2020_04_28_115449_5649009.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joubel_reporting_backup_2020_04_28_115449_5649009', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [joubel_warehouse];
GO
use [master];
GO
BACKUP DATABASE [joubel_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\joubel_warehouse_backup_2020_04_28_115449_5805341.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'joubel_warehouse_backup_2020_04_28_115449_5805341', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12aus];
GO
use [master];
GO
BACKUP DATABASE [k12aus] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12aus_backup_2020_04_28_115449_5961402.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12aus_backup_2020_04_28_115449_5961402', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12aus_lor];
GO
use [master];
GO
BACKUP DATABASE [k12aus_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12aus_lor_backup_2020_04_28_115449_6117644.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12aus_lor_backup_2020_04_28_115449_6117644', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12aus_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12aus_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12aus_reporting_backup_2020_04_28_115449_6117644.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12aus_reporting_backup_2020_04_28_115449_6117644', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12aus_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12aus_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12aus_warehouse_backup_2020_04_28_115449_6273869.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12aus_warehouse_backup_2020_04_28_115449_6273869', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12emea];
GO
use [master];
GO
BACKUP DATABASE [k12emea] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12emea_backup_2020_04_28_115449_6430156.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12emea_backup_2020_04_28_115449_6430156', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12emea_lor];
GO
use [master];
GO
BACKUP DATABASE [k12emea_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12emea_lor_backup_2020_04_28_115449_6586500.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12emea_lor_backup_2020_04_28_115449_6586500', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12emea_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12emea_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12emea_reporting_backup_2020_04_28_115449_6742549.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12emea_reporting_backup_2020_04_28_115449_6742549', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12emea_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12emea_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12emea_warehouse_backup_2020_04_28_115449_6898794.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12emea_warehouse_backup_2020_04_28_115449_6898794', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12lunchbox];
GO
use [master];
GO
BACKUP DATABASE [k12lunchbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12lunchbox_backup_2020_04_28_115449_7055126.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12lunchbox_backup_2020_04_28_115449_7055126', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12lunchbox_lor];
GO
use [master];
GO
BACKUP DATABASE [k12lunchbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12lunchbox_lor_backup_2020_04_28_115449_7055126.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12lunchbox_lor_backup_2020_04_28_115449_7055126', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12lunchbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12lunchbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12lunchbox_reporting_backup_2020_04_28_115449_7211658.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12lunchbox_reporting_backup_2020_04_28_115449_7211658', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12lunchbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12lunchbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12lunchbox_warehouse_backup_2020_04_28_115449_7367671.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12lunchbox_warehouse_backup_2020_04_28_115449_7367671', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12pm];
GO
use [master];
GO
BACKUP DATABASE [k12pm] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12pm_backup_2020_04_28_115449_7523838.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12pm_backup_2020_04_28_115449_7523838', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12pm_lor];
GO
use [master];
GO
BACKUP DATABASE [k12pm_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12pm_lor_backup_2020_04_28_115449_7680260.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12pm_lor_backup_2020_04_28_115449_7680260', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12pm_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12pm_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12pm_reporting_backup_2020_04_28_115449_7680260.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12pm_reporting_backup_2020_04_28_115449_7680260', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12pm_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12pm_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12pm_warehouse_backup_2020_04_28_115449_7836387.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12pm_warehouse_backup_2020_04_28_115449_7836387', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox_backup_2020_04_28_115449_7992649.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox_backup_2020_04_28_115449_7992649', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox_lor_backup_2020_04_28_115449_8149018.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox_lor_backup_2020_04_28_115449_8149018', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox_reporting_backup_2020_04_28_115449_8305259.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox_reporting_backup_2020_04_28_115449_8305259', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox_warehouse_backup_2020_04_28_115449_8461390.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox_warehouse_backup_2020_04_28_115449_8461390', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox1];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox1_backup_2020_04_28_115449_8617664.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox1_backup_2020_04_28_115449_8617664', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox1_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox1_lor_backup_2020_04_28_115449_8617664.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox1_lor_backup_2020_04_28_115449_8617664', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox1_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox1_reporting_backup_2020_04_28_115449_8774062.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox1_reporting_backup_2020_04_28_115449_8774062', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox1_warehouse_backup_2020_04_28_115449_8930283.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox1_warehouse_backup_2020_04_28_115449_8930283', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox2];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox2] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox2_backup_2020_04_28_115449_9086385.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox2_backup_2020_04_28_115449_9086385', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox2_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox2_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox2_lor_backup_2020_04_28_115449_9242549.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox2_lor_backup_2020_04_28_115449_9242549', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox2_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox2_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox2_reporting_backup_2020_04_28_115449_9242549.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox2_reporting_backup_2020_04_28_115449_9242549', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox2_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox2_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox2_warehouse_backup_2020_04_28_115449_9398815.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox2_warehouse_backup_2020_04_28_115449_9398815', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox3];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox3] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox3_backup_2020_04_28_115449_9711589.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox3_backup_2020_04_28_115449_9711589', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox3_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox3_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox3_lor_backup_2020_04_28_115449_9711589.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox3_lor_backup_2020_04_28_115449_9711589', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox3_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox3_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox3_reporting_backup_2020_04_28_115449_9867806.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox3_reporting_backup_2020_04_28_115449_9867806', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox3_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox3_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox3_warehouse_backup_2020_04_28_115450_0180408.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox3_warehouse_backup_2020_04_28_115450_0180408', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox5];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox5] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox5_backup_2020_04_28_115450_0180408.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox5_backup_2020_04_28_115450_0180408', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox5_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox5_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox5_lor_backup_2020_04_28_115450_0336555.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox5_lor_backup_2020_04_28_115450_0336555', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox5_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox5_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox5_reporting_backup_2020_04_28_115450_0492829.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox5_reporting_backup_2020_04_28_115450_0492829', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox5_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox5_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox5_warehouse_backup_2020_04_28_115450_0648948.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox5_warehouse_backup_2020_04_28_115450_0648948', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox6];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox6] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox6_backup_2020_04_28_115450_0805284.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox6_backup_2020_04_28_115450_0805284', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox6_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox6_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox6_lor_backup_2020_04_28_115450_0961402.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox6_lor_backup_2020_04_28_115450_0961402', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox6_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox6_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox6_reporting_backup_2020_04_28_115450_0961402.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox6_reporting_backup_2020_04_28_115450_0961402', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox6_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox6_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox6_warehouse_backup_2020_04_28_115450_1117492.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox6_warehouse_backup_2020_04_28_115450_1117492', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox7];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox7] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox7_backup_2020_04_28_115450_1273902.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox7_backup_2020_04_28_115450_1273902', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox7_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox7_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox7_lor_backup_2020_04_28_115450_1430258.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox7_lor_backup_2020_04_28_115450_1430258', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox7_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox7_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox7_reporting_backup_2020_04_28_115450_1586438.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox7_reporting_backup_2020_04_28_115450_1586438', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox7_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox7_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox7_warehouse_backup_2020_04_28_115450_1586438.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox7_warehouse_backup_2020_04_28_115450_1586438', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox8];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox8] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox8_backup_2020_04_28_115450_1742569.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox8_backup_2020_04_28_115450_1742569', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox8_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox8_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox8_lor_backup_2020_04_28_115450_1898958.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox8_lor_backup_2020_04_28_115450_1898958', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox8_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox8_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox8_reporting_backup_2020_04_28_115450_2055114.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox8_reporting_backup_2020_04_28_115450_2055114', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sandbox8_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sandbox8_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sandbox8_warehouse_backup_2020_04_28_115450_2211425.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sandbox8_warehouse_backup_2020_04_28_115450_2211425', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sejahtera];
GO
use [master];
GO
BACKUP DATABASE [k12sejahtera] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sejahtera_backup_2020_04_28_115450_2367658.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sejahtera_backup_2020_04_28_115450_2367658', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sejahtera_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sejahtera_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sejahtera_lor_backup_2020_04_28_115450_2523945.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sejahtera_lor_backup_2020_04_28_115450_2523945', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sejahtera_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sejahtera_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sejahtera_reporting_backup_2020_04_28_115450_2523945.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sejahtera_reporting_backup_2020_04_28_115450_2523945', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sejahtera_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sejahtera_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sejahtera_warehouse_backup_2020_04_28_115450_2680256.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sejahtera_warehouse_backup_2020_04_28_115450_2680256', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sr];
GO
use [master];
GO
BACKUP DATABASE [k12sr] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sr_backup_2020_04_28_115450_2836657.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sr_backup_2020_04_28_115450_2836657', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sr_lor];
GO
use [master];
GO
BACKUP DATABASE [k12sr_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sr_lor_backup_2020_04_28_115450_2992698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sr_lor_backup_2020_04_28_115450_2992698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sr_reporting];
GO
use [master];
GO
BACKUP DATABASE [k12sr_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sr_reporting_backup_2020_04_28_115450_3148956.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sr_reporting_backup_2020_04_28_115450_3148956', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [k12sr_warehouse];
GO
use [master];
GO
BACKUP DATABASE [k12sr_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\k12sr_warehouse_backup_2020_04_28_115450_3305452.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'k12sr_warehouse_backup_2020_04_28_115450_3305452', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kce];
GO
use [master];
GO
BACKUP DATABASE [kce] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kce_backup_2020_04_28_115450_3461460.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kce_backup_2020_04_28_115450_3461460', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kce_lor];
GO
use [master];
GO
BACKUP DATABASE [kce_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kce_lor_backup_2020_04_28_115450_3617603.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kce_lor_backup_2020_04_28_115450_3617603', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kce_reporting];
GO
use [master];
GO
BACKUP DATABASE [kce_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kce_reporting_backup_2020_04_28_115450_3773984.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kce_reporting_backup_2020_04_28_115450_3773984', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kce_warehouse];
GO
use [master];
GO
BACKUP DATABASE [kce_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kce_warehouse_backup_2020_04_28_115450_3773984.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kce_warehouse_backup_2020_04_28_115450_3773984', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kentstate];
GO
use [master];
GO
BACKUP DATABASE [kentstate] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kentstate_backup_2020_04_28_115450_3930553.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kentstate_backup_2020_04_28_115450_3930553', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kentstate_lor];
GO
use [master];
GO
BACKUP DATABASE [kentstate_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kentstate_lor_backup_2020_04_28_115450_4086569.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kentstate_lor_backup_2020_04_28_115450_4086569', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kentstate_reporting];
GO
use [master];
GO
BACKUP DATABASE [kentstate_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kentstate_reporting_backup_2020_04_28_115450_4242983.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kentstate_reporting_backup_2020_04_28_115450_4242983', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [kentstate_warehouse];
GO
use [master];
GO
BACKUP DATABASE [kentstate_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\kentstate_warehouse_backup_2020_04_28_115450_4242983.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'kentstate_warehouse_backup_2020_04_28_115450_4242983', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [knowbility];
GO
use [master];
GO
BACKUP DATABASE [knowbility] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\knowbility_backup_2020_04_28_115450_4399114.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'knowbility_backup_2020_04_28_115450_4399114', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [knowbility_lor];
GO
use [master];
GO
BACKUP DATABASE [knowbility_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\knowbility_lor_backup_2020_04_28_115450_4555409.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'knowbility_lor_backup_2020_04_28_115450_4555409', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [knowbility_reporting];
GO
use [master];
GO
BACKUP DATABASE [knowbility_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\knowbility_reporting_backup_2020_04_28_115450_4711466.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'knowbility_reporting_backup_2020_04_28_115450_4711466', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [knowbility_warehouse];
GO
use [master];
GO
BACKUP DATABASE [knowbility_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\knowbility_warehouse_backup_2020_04_28_115450_4867683.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'knowbility_warehouse_backup_2020_04_28_115450_4867683', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [laboureedu];
GO
use [master];
GO
BACKUP DATABASE [laboureedu] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\laboureedu_backup_2020_04_28_115450_5023859.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'laboureedu_backup_2020_04_28_115450_5023859', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [laboureedu_lor];
GO
use [master];
GO
BACKUP DATABASE [laboureedu_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\laboureedu_lor_backup_2020_04_28_115450_5023859.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'laboureedu_lor_backup_2020_04_28_115450_5023859', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [laboureedu_reporting];
GO
use [master];
GO
BACKUP DATABASE [laboureedu_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\laboureedu_reporting_backup_2020_04_28_115450_5180342.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'laboureedu_reporting_backup_2020_04_28_115450_5180342', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [laboureedu_warehouse];
GO
use [master];
GO
BACKUP DATABASE [laboureedu_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\laboureedu_warehouse_backup_2020_04_28_115450_5336453.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'laboureedu_warehouse_backup_2020_04_28_115450_5336453', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lakevalley];
GO
use [master];
GO
BACKUP DATABASE [lakevalley] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lakevalley_backup_2020_04_28_115450_5492567.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lakevalley_backup_2020_04_28_115450_5492567', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lakevalley_lor];
GO
use [master];
GO
BACKUP DATABASE [lakevalley_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lakevalley_lor_backup_2020_04_28_115450_5649120.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lakevalley_lor_backup_2020_04_28_115450_5649120', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lakevalley_reporting];
GO
use [master];
GO
BACKUP DATABASE [lakevalley_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lakevalley_reporting_backup_2020_04_28_115450_5805517.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lakevalley_reporting_backup_2020_04_28_115450_5805517', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lakevalley_warehouse];
GO
use [master];
GO
BACKUP DATABASE [lakevalley_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lakevalley_warehouse_backup_2020_04_28_115450_5805517.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lakevalley_warehouse_backup_2020_04_28_115450_5805517', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
--3:53
--3:58