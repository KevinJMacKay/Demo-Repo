use [latam1];
GO
use [master];
GO
BACKUP DATABASE [latam1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latam1_backup_2020_04_28_115450_5961521.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latam1_backup_2020_04_28_115450_5961521', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latam1_lor];
GO
use [master];
GO
BACKUP DATABASE [latam1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latam1_lor_backup_2020_04_28_115450_6117709.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latam1_lor_backup_2020_04_28_115450_6117709', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latam1_reporting];
GO
use [master];
GO
BACKUP DATABASE [latam1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latam1_reporting_backup_2020_04_28_115450_6273894.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latam1_reporting_backup_2020_04_28_115450_6273894', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latam1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [latam1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latam1_warehouse_backup_2020_04_28_115450_6433228.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latam1_warehouse_backup_2020_04_28_115450_6433228', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamenterprise];
GO
use [master];
GO
BACKUP DATABASE [latamenterprise] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamenterprise_backup_2020_04_28_115450_6622249.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamenterprise_backup_2020_04_28_115450_6622249', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamenterprise_lor];
GO
use [master];
GO
BACKUP DATABASE [latamenterprise_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamenterprise_lor_backup_2020_04_28_115450_6742844.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamenterprise_lor_backup_2020_04_28_115450_6742844', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamenterprise_reporting];
GO
use [master];
GO
BACKUP DATABASE [latamenterprise_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamenterprise_reporting_backup_2020_04_28_115450_6904066.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamenterprise_reporting_backup_2020_04_28_115450_6904066', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamenterprise_warehouse];
GO
use [master];
GO
BACKUP DATABASE [latamenterprise_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamenterprise_warehouse_backup_2020_04_28_115450_7055073.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamenterprise_warehouse_backup_2020_04_28_115450_7055073', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamk12];
GO
use [master];
GO
BACKUP DATABASE [latamk12] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamk12_backup_2020_04_28_115450_7211449.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamk12_backup_2020_04_28_115450_7211449', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamk12_lor];
GO
use [master];
GO
BACKUP DATABASE [latamk12_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamk12_lor_backup_2020_04_28_115450_7367802.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamk12_lor_backup_2020_04_28_115450_7367802', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamk12_reporting];
GO
use [master];
GO
BACKUP DATABASE [latamk12_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamk12_reporting_backup_2020_04_28_115450_7523961.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamk12_reporting_backup_2020_04_28_115450_7523961', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamk12_warehouse];
GO
use [master];
GO
BACKUP DATABASE [latamk12_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamk12_warehouse_backup_2020_04_28_115450_7680580.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamk12_warehouse_backup_2020_04_28_115450_7680580', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamsa];
GO
use [master];
GO
BACKUP DATABASE [latamsa] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamsa_backup_2020_04_28_115450_7680580.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamsa_backup_2020_04_28_115450_7680580', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamsa_lor];
GO
use [master];
GO
BACKUP DATABASE [latamsa_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamsa_lor_backup_2020_04_28_115450_7836444.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamsa_lor_backup_2020_04_28_115450_7836444', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamsa_reporting];
GO
use [master];
GO
BACKUP DATABASE [latamsa_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamsa_reporting_backup_2020_04_28_115450_7992792.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamsa_reporting_backup_2020_04_28_115450_7992792', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [latamsa_warehouse];
GO
use [master];
GO
BACKUP DATABASE [latamsa_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\latamsa_warehouse_backup_2020_04_28_115450_8148960.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'latamsa_warehouse_backup_2020_04_28_115450_8148960', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lavernesandbox];
GO
use [master];
GO
BACKUP DATABASE [lavernesandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lavernesandbox_backup_2020_04_28_115450_8337261.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lavernesandbox_backup_2020_04_28_115450_8337261', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lavernesandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [lavernesandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lavernesandbox_lor_backup_2020_04_28_115450_8417014.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lavernesandbox_lor_backup_2020_04_28_115450_8417014', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lavernesandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [lavernesandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lavernesandbox_reporting_backup_2020_04_28_115450_8617832.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lavernesandbox_reporting_backup_2020_04_28_115450_8617832', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lavernesandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [lavernesandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lavernesandbox_warehouse_backup_2020_04_28_115450_8617832.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lavernesandbox_warehouse_backup_2020_04_28_115450_8617832', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [learnzillionk12];
GO
use [master];
GO
BACKUP DATABASE [learnzillionk12] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\learnzillionk12_backup_2020_04_28_115450_8775602.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'learnzillionk12_backup_2020_04_28_115450_8775602', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [learnzillionk12_lor];
GO
use [master];
GO
BACKUP DATABASE [learnzillionk12_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\learnzillionk12_lor_backup_2020_04_28_115450_8930242.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'learnzillionk12_lor_backup_2020_04_28_115450_8930242', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [learnzillionk12_reporting];
GO
use [master];
GO
BACKUP DATABASE [learnzillionk12_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\learnzillionk12_reporting_backup_2020_04_28_115450_9086487.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'learnzillionk12_reporting_backup_2020_04_28_115450_9086487', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [learnzillionk12_warehouse];
GO
use [master];
GO
BACKUP DATABASE [learnzillionk12_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\learnzillionk12_warehouse_backup_2020_04_28_115450_9242782.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'learnzillionk12_warehouse_backup_2020_04_28_115450_9242782', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lecom];
GO
use [master];
GO
BACKUP DATABASE [lecom] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lecom_backup_2020_04_28_115450_9398983.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lecom_backup_2020_04_28_115450_9398983', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lecom_lor];
GO
use [master];
GO
BACKUP DATABASE [lecom_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lecom_lor_backup_2020_04_28_115450_9398983.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lecom_lor_backup_2020_04_28_115450_9398983', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lecom_reporting];
GO
use [master];
GO
BACKUP DATABASE [lecom_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lecom_reporting_backup_2020_04_28_115450_9555138.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lecom_reporting_backup_2020_04_28_115450_9555138', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lecom_warehouse];
GO
use [master];
GO
BACKUP DATABASE [lecom_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lecom_warehouse_backup_2020_04_28_115450_9712375.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lecom_warehouse_backup_2020_04_28_115450_9712375', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lpcorp2020];
GO
use [master];
GO
BACKUP DATABASE [lpcorp2020] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lpcorp2020_backup_2020_04_28_115450_9867934.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lpcorp2020_backup_2020_04_28_115450_9867934', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lpcorp2020_lor];
GO
use [master];
GO
BACKUP DATABASE [lpcorp2020_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lpcorp2020_lor_backup_2020_04_28_115451_0024086.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lpcorp2020_lor_backup_2020_04_28_115451_0024086', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lpcorp2020_reporting];
GO
use [master];
GO
BACKUP DATABASE [lpcorp2020_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lpcorp2020_reporting_backup_2020_04_28_115451_0180534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lpcorp2020_reporting_backup_2020_04_28_115451_0180534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lpcorp2020_warehouse];
GO
use [master];
GO
BACKUP DATABASE [lpcorp2020_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lpcorp2020_warehouse_backup_2020_04_28_115451_0336682.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lpcorp2020_warehouse_backup_2020_04_28_115451_0336682', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lphe2020];
GO
use [master];
GO
BACKUP DATABASE [lphe2020] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lphe2020_backup_2020_04_28_115451_0336682.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lphe2020_backup_2020_04_28_115451_0336682', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lphe2020_lor];
GO
use [master];
GO
BACKUP DATABASE [lphe2020_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lphe2020_lor_backup_2020_04_28_115451_0492924.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lphe2020_lor_backup_2020_04_28_115451_0492924', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lphe2020_reporting];
GO
use [master];
GO
BACKUP DATABASE [lphe2020_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lphe2020_reporting_backup_2020_04_28_115451_0648983.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lphe2020_reporting_backup_2020_04_28_115451_0648983', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [lphe2020_warehouse];
GO
use [master];
GO
BACKUP DATABASE [lphe2020_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\lphe2020_warehouse_backup_2020_04_28_115451_0805160.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'lphe2020_warehouse_backup_2020_04_28_115451_0805160', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [macewan];
GO
use [master];
GO
BACKUP DATABASE [macewan] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\macewan_backup_2020_04_28_115451_0961554.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'macewan_backup_2020_04_28_115451_0961554', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [macewan_lor];
GO
use [master];
GO
BACKUP DATABASE [macewan_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\macewan_lor_backup_2020_04_28_115451_1117592.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'macewan_lor_backup_2020_04_28_115451_1117592', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [macewan_reporting];
GO
use [master];
GO
BACKUP DATABASE [macewan_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\macewan_reporting_backup_2020_04_28_115451_1273924.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'macewan_reporting_backup_2020_04_28_115451_1273924', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [macewan_warehouse];
GO
use [master];
GO
BACKUP DATABASE [macewan_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\macewan_warehouse_backup_2020_04_28_115451_1273924.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'macewan_warehouse_backup_2020_04_28_115451_1273924', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maine];
GO
use [master];
GO
BACKUP DATABASE [maine] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maine_backup_2020_04_28_115451_1430474.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maine_backup_2020_04_28_115451_1430474', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maine_lor];
GO
use [master];
GO
BACKUP DATABASE [maine_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maine_lor_backup_2020_04_28_115451_1586573.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maine_lor_backup_2020_04_28_115451_1586573', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maine_reporting];
GO
use [master];
GO
BACKUP DATABASE [maine_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maine_reporting_backup_2020_04_28_115451_1742849.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maine_reporting_backup_2020_04_28_115451_1742849', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maine_warehouse];
GO
use [master];
GO
BACKUP DATABASE [maine_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maine_warehouse_backup_2020_04_28_115451_1899026.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maine_warehouse_backup_2020_04_28_115451_1899026', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maria];
GO
use [master];
GO
BACKUP DATABASE [maria] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maria_backup_2020_04_28_115451_1899026.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maria_backup_2020_04_28_115451_1899026', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maria_lor];
GO
use [master];
GO
BACKUP DATABASE [maria_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maria_lor_backup_2020_04_28_115451_2055158.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maria_lor_backup_2020_04_28_115451_2055158', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maria_reporting];
GO
use [master];
GO
BACKUP DATABASE [maria_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maria_reporting_backup_2020_04_28_115451_2211662.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maria_reporting_backup_2020_04_28_115451_2211662', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [maria_warehouse];
GO
use [master];
GO
BACKUP DATABASE [maria_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\maria_warehouse_backup_2020_04_28_115451_2367803.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'maria_warehouse_backup_2020_04_28_115451_2367803', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mbird];
GO
use [master];
GO
BACKUP DATABASE [mbird] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mbird_backup_2020_04_28_115451_2524086.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mbird_backup_2020_04_28_115451_2524086', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mbird_lor];
GO
use [master];
GO
BACKUP DATABASE [mbird_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mbird_lor_backup_2020_04_28_115451_2680275.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mbird_lor_backup_2020_04_28_115451_2680275', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mbird_reporting];
GO
use [master];
GO
BACKUP DATABASE [mbird_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mbird_reporting_backup_2020_04_28_115451_2836698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mbird_reporting_backup_2020_04_28_115451_2836698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mbird_warehouse];
GO
use [master];
GO
BACKUP DATABASE [mbird_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mbird_warehouse_backup_2020_04_28_115451_2836698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mbird_warehouse_backup_2020_04_28_115451_2836698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mccs];
GO
use [master];
GO
BACKUP DATABASE [mccs] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mccs_backup_2020_04_28_115451_2992777.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mccs_backup_2020_04_28_115451_2992777', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mccs_lor];
GO
use [master];
GO
BACKUP DATABASE [mccs_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mccs_lor_backup_2020_04_28_115451_3148905.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mccs_lor_backup_2020_04_28_115451_3148905', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mccs_reporting];
GO
use [master];
GO
BACKUP DATABASE [mccs_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mccs_reporting_backup_2020_04_28_115451_3305160.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mccs_reporting_backup_2020_04_28_115451_3305160', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mccs_warehouse];
GO
use [master];
GO
BACKUP DATABASE [mccs_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mccs_warehouse_backup_2020_04_28_115451_3461390.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mccs_warehouse_backup_2020_04_28_115451_3461390', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mcgrawhillsndbx];
GO
use [master];
GO
BACKUP DATABASE [mcgrawhillsndbx] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mcgrawhillsndbx_backup_2020_04_28_115451_3461390.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mcgrawhillsndbx_backup_2020_04_28_115451_3461390', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mcgrawhillsndbx_lor];
GO
use [master];
GO
BACKUP DATABASE [mcgrawhillsndbx_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mcgrawhillsndbx_lor_backup_2020_04_28_115451_3774076.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mcgrawhillsndbx_lor_backup_2020_04_28_115451_3774076', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mcgrawhillsndbx_reporting];
GO
use [master];
GO
BACKUP DATABASE [mcgrawhillsndbx_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mcgrawhillsndbx_reporting_backup_2020_04_28_115451_3930286.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mcgrawhillsndbx_reporting_backup_2020_04_28_115451_3930286', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mcgrawhillsndbx_warehouse];
GO
use [master];
GO
BACKUP DATABASE [mcgrawhillsndbx_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mcgrawhillsndbx_warehouse_backup_2020_04_28_115451_3930286.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mcgrawhillsndbx_warehouse_backup_2020_04_28_115451_3930286', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mindefensaco];
GO
use [master];
GO
BACKUP DATABASE [mindefensaco] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mindefensaco_backup_2020_04_28_115451_4086487.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mindefensaco_backup_2020_04_28_115451_4086487', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mindefensaco_lor];
GO
use [master];
GO
BACKUP DATABASE [mindefensaco_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mindefensaco_lor_backup_2020_04_28_115451_4242775.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mindefensaco_lor_backup_2020_04_28_115451_4242775', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mindefensaco_reporting];
GO
use [master];
GO
BACKUP DATABASE [mindefensaco_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mindefensaco_reporting_backup_2020_04_28_115451_4399116.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mindefensaco_reporting_backup_2020_04_28_115451_4399116', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [mindefensaco_warehouse];
GO
use [master];
GO
BACKUP DATABASE [mindefensaco_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\mindefensaco_warehouse_backup_2020_04_28_115451_4556374.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'mindefensaco_warehouse_backup_2020_04_28_115451_4556374', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [naseej];
GO
use [master];
GO
BACKUP DATABASE [naseej] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\naseej_backup_2020_04_28_115451_4556374.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'naseej_backup_2020_04_28_115451_4556374', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [naseej_lor];
GO
use [master];
GO
BACKUP DATABASE [naseej_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\naseej_lor_backup_2020_04_28_115451_4711802.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'naseej_lor_backup_2020_04_28_115451_4711802', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [naseej_reporting];
GO
use [master];
GO
BACKUP DATABASE [naseej_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\naseej_reporting_backup_2020_04_28_115451_4870871.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'naseej_reporting_backup_2020_04_28_115451_4870871', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [naseej_warehouse];
GO
use [master];
GO
BACKUP DATABASE [naseej_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\naseej_warehouse_backup_2020_04_28_115451_5024213.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'naseej_warehouse_backup_2020_04_28_115451_5024213', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [national];
GO
use [master];
GO
BACKUP DATABASE [national] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\national_backup_2020_04_28_115451_5180603.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'national_backup_2020_04_28_115451_5180603', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [national_lor];
GO
use [master];
GO
BACKUP DATABASE [national_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\national_lor_backup_2020_04_28_115451_5336670.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'national_lor_backup_2020_04_28_115451_5336670', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [national_reporting];
GO
use [master];
GO
BACKUP DATABASE [national_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\national_reporting_backup_2020_04_28_115451_5492822.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'national_reporting_backup_2020_04_28_115451_5492822', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [national_warehouse];
GO
use [master];
GO
BACKUP DATABASE [national_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\national_warehouse_backup_2020_04_28_115451_5649265.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'national_warehouse_backup_2020_04_28_115451_5649265', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
--use [ndmu];
--GO
--use [master];
--GO
--BACKUP DATABASE [ndmu] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ndmu_backup_2020_04_28_115451_5805459.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ndmu_backup_2020_04_28_115451_5805459', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [ndmu_lor];
--GO
--use [master];
--GO
--BACKUP DATABASE [ndmu_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ndmu_lor_backup_2020_04_28_115451_5805459.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ndmu_lor_backup_2020_04_28_115451_5805459', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [ndmu_reporting];
--GO
--use [master];
--GO
--BACKUP DATABASE [ndmu_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ndmu_reporting_backup_2020_04_28_115451_5961853.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ndmu_reporting_backup_2020_04_28_115451_5961853', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [ndmu_warehouse];
--GO
--use [master];
--GO
--BACKUP DATABASE [ndmu_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ndmu_warehouse_backup_2020_04_28_115451_6118112.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ndmu_warehouse_backup_2020_04_28_115451_6118112', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
use [nrcystrial];
GO
use [master];
GO
BACKUP DATABASE [nrcystrial] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nrcystrial_backup_2020_04_28_115451_6274400.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nrcystrial_backup_2020_04_28_115451_6274400', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nrcystrial_lor];
GO
use [master];
GO
BACKUP DATABASE [nrcystrial_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nrcystrial_lor_backup_2020_04_28_115451_6430601.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nrcystrial_lor_backup_2020_04_28_115451_6430601', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nrcystrial_reporting];
GO
use [master];
GO
BACKUP DATABASE [nrcystrial_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nrcystrial_reporting_backup_2020_04_28_115451_6586700.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nrcystrial_reporting_backup_2020_04_28_115451_6586700', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nrcystrial_warehouse];
GO
use [master];
GO
BACKUP DATABASE [nrcystrial_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nrcystrial_warehouse_backup_2020_04_28_115451_6586700.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nrcystrial_warehouse_backup_2020_04_28_115451_6586700', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nyu];
GO
use [master];
GO
BACKUP DATABASE [nyu] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nyu_backup_2020_04_28_115451_6742742.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nyu_backup_2020_04_28_115451_6742742', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nyu_lor];
GO
use [master];
GO
BACKUP DATABASE [nyu_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nyu_lor_backup_2020_04_28_115451_6899063.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nyu_lor_backup_2020_04_28_115451_6899063', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nyu_reporting];
GO
use [master];
GO
BACKUP DATABASE [nyu_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nyu_reporting_backup_2020_04_28_115451_7055305.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nyu_reporting_backup_2020_04_28_115451_7055305', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [nyu_warehouse];
GO
use [master];
GO
BACKUP DATABASE [nyu_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\nyu_warehouse_backup_2020_04_28_115451_7211568.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'nyu_warehouse_backup_2020_04_28_115451_7211568', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [oreilly];
GO
use [master];
GO
BACKUP DATABASE [oreilly] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\oreilly_backup_2020_04_28_115451_7367958.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'oreilly_backup_2020_04_28_115451_7367958', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [oreilly_lor];
GO
use [master];
GO
BACKUP DATABASE [oreilly_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\oreilly_lor_backup_2020_04_28_115451_7367958.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'oreilly_lor_backup_2020_04_28_115451_7367958', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [oreilly_reporting];
GO
use [master];
GO
BACKUP DATABASE [oreilly_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\oreilly_reporting_backup_2020_04_28_115451_7524217.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'oreilly_reporting_backup_2020_04_28_115451_7524217', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [oreilly_warehouse];
GO
use [master];
GO
BACKUP DATABASE [oreilly_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\oreilly_warehouse_backup_2020_04_28_115451_7680480.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'oreilly_warehouse_backup_2020_04_28_115451_7680480', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [orupd];
GO
use [master];
GO
BACKUP DATABASE [orupd] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\orupd_backup_2020_04_28_115451_7836616.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'orupd_backup_2020_04_28_115451_7836616', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [orupd_lor];
GO
use [master];
GO
BACKUP DATABASE [orupd_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\orupd_lor_backup_2020_04_28_115451_7992851.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'orupd_lor_backup_2020_04_28_115451_7992851', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [orupd_reporting];
GO
use [master];
GO
BACKUP DATABASE [orupd_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\orupd_reporting_backup_2020_04_28_115451_8149659.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'orupd_reporting_backup_2020_04_28_115451_8149659', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [orupd_warehouse];
GO
use [master];
GO
BACKUP DATABASE [orupd_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\orupd_warehouse_backup_2020_04_28_115451_8305356.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'orupd_warehouse_backup_2020_04_28_115451_8305356', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pace];
GO
use [master];
GO
BACKUP DATABASE [pace] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pace_backup_2020_04_28_115451_8305356.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pace_backup_2020_04_28_115451_8305356', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pace_lor];
GO
use [master];
GO
BACKUP DATABASE [pace_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pace_lor_backup_2020_04_28_115451_8461689.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pace_lor_backup_2020_04_28_115451_8461689', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pace_reporting];
GO
use [master];
GO
BACKUP DATABASE [pace_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pace_reporting_backup_2020_04_28_115451_8618014.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pace_reporting_backup_2020_04_28_115451_8618014', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pace_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pace_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pace_warehouse_backup_2020_04_28_115451_8774121.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pace_warehouse_backup_2020_04_28_115451_8774121', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [panoptodemo];
GO
use [master];
GO
BACKUP DATABASE [panoptodemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\panoptodemo_backup_2020_04_28_115451_8930593.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'panoptodemo_backup_2020_04_28_115451_8930593', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [panoptodemo_lor];
GO
use [master];
GO
BACKUP DATABASE [panoptodemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\panoptodemo_lor_backup_2020_04_28_115451_9087003.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'panoptodemo_lor_backup_2020_04_28_115451_9087003', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [panoptodemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [panoptodemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\panoptodemo_reporting_backup_2020_04_28_115451_9242996.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'panoptodemo_reporting_backup_2020_04_28_115451_9242996', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [panoptodemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [panoptodemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\panoptodemo_warehouse_backup_2020_04_28_115451_9399620.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'panoptodemo_warehouse_backup_2020_04_28_115451_9399620', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pccsandbox];
GO
use [master];
GO
BACKUP DATABASE [pccsandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pccsandbox_backup_2020_04_28_115451_9399620.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pccsandbox_backup_2020_04_28_115451_9399620', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pccsandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [pccsandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pccsandbox_lor_backup_2020_04_28_115451_9555436.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pccsandbox_lor_backup_2020_04_28_115451_9555436', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pccsandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [pccsandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pccsandbox_reporting_backup_2020_04_28_115451_9711777.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pccsandbox_reporting_backup_2020_04_28_115451_9711777', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pccsandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pccsandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pccsandbox_warehouse_backup_2020_04_28_115451_9868511.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pccsandbox_warehouse_backup_2020_04_28_115451_9868511', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pcsandbox];
GO
use [master];
GO
BACKUP DATABASE [pcsandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pcsandbox_backup_2020_04_28_115452_0024134.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pcsandbox_backup_2020_04_28_115452_0024134', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pcsandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [pcsandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pcsandbox_lor_backup_2020_04_28_115452_0180486.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pcsandbox_lor_backup_2020_04_28_115452_0180486', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pcsandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [pcsandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pcsandbox_reporting_backup_2020_04_28_115452_0180486.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pcsandbox_reporting_backup_2020_04_28_115452_0180486', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pcsandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pcsandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pcsandbox_warehouse_backup_2020_04_28_115452_0336609.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pcsandbox_warehouse_backup_2020_04_28_115452_0336609', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pdm1];
GO
use [master];
GO
BACKUP DATABASE [pdm1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pdm1_backup_2020_04_28_115452_0492769.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pdm1_backup_2020_04_28_115452_0492769', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pdm1_lor];
GO
use [master];
GO
BACKUP DATABASE [pdm1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pdm1_lor_backup_2020_04_28_115452_0649449.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pdm1_lor_backup_2020_04_28_115452_0649449', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pdm1_reporting];
GO
use [master];
GO
BACKUP DATABASE [pdm1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pdm1_reporting_backup_2020_04_28_115452_0805596.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pdm1_reporting_backup_2020_04_28_115452_0805596', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pdm1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pdm1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pdm1_warehouse_backup_2020_04_28_115452_0961641.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pdm1_warehouse_backup_2020_04_28_115452_0961641', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonbrhe];
GO
use [master];
GO
BACKUP DATABASE [pearsonbrhe] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonbrhe_backup_2020_04_28_115452_1117915.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonbrhe_backup_2020_04_28_115452_1117915', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonbrhe_lor];
GO
use [master];
GO
BACKUP DATABASE [pearsonbrhe_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonbrhe_lor_backup_2020_04_28_115452_1117915.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonbrhe_lor_backup_2020_04_28_115452_1117915', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonbrhe_reporting];
GO
use [master];
GO
BACKUP DATABASE [pearsonbrhe_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonbrhe_reporting_backup_2020_04_28_115452_1274353.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonbrhe_reporting_backup_2020_04_28_115452_1274353', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonbrhe_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pearsonbrhe_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonbrhe_warehouse_backup_2020_04_28_115452_1430501.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonbrhe_warehouse_backup_2020_04_28_115452_1430501', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsongovpe];
GO
use [master];
GO
BACKUP DATABASE [pearsongovpe] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsongovpe_backup_2020_04_28_115452_1586697.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsongovpe_backup_2020_04_28_115452_1586697', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsongovpe_lor];
GO
use [master];
GO
BACKUP DATABASE [pearsongovpe_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsongovpe_lor_backup_2020_04_28_115452_1743353.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsongovpe_lor_backup_2020_04_28_115452_1743353', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsongovpe_reporting];
GO
use [master];
GO
BACKUP DATABASE [pearsongovpe_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsongovpe_reporting_backup_2020_04_28_115452_1743353.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsongovpe_reporting_backup_2020_04_28_115452_1743353', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsongovpe_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pearsongovpe_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsongovpe_warehouse_backup_2020_04_28_115452_1899373.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsongovpe_warehouse_backup_2020_04_28_115452_1899373', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonhesuk];
GO
use [master];
GO
BACKUP DATABASE [pearsonhesuk] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonhesuk_backup_2020_04_28_115452_2055426.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonhesuk_backup_2020_04_28_115452_2055426', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonhesuk_lor];
GO
use [master];
GO
BACKUP DATABASE [pearsonhesuk_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonhesuk_lor_backup_2020_04_28_115452_2211868.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonhesuk_lor_backup_2020_04_28_115452_2211868', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonhesuk_reporting];
GO
use [master];
GO
BACKUP DATABASE [pearsonhesuk_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonhesuk_reporting_backup_2020_04_28_115452_2367921.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonhesuk_reporting_backup_2020_04_28_115452_2367921', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pearsonhesuk_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pearsonhesuk_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pearsonhesuk_warehouse_backup_2020_04_28_115452_2524310.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pearsonhesuk_warehouse_backup_2020_04_28_115452_2524310', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pepijnhe];
GO
use [master];
GO
BACKUP DATABASE [pepijnhe] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pepijnhe_backup_2020_04_28_115452_2680499.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pepijnhe_backup_2020_04_28_115452_2680499', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pepijnhe_lor];
GO
use [master];
GO
BACKUP DATABASE [pepijnhe_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pepijnhe_lor_backup_2020_04_28_115452_2680499.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pepijnhe_lor_backup_2020_04_28_115452_2680499', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pepijnhe_reporting];
GO
use [master];
GO
BACKUP DATABASE [pepijnhe_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pepijnhe_reporting_backup_2020_04_28_115452_2836712.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pepijnhe_reporting_backup_2020_04_28_115452_2836712', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pepijnhe_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pepijnhe_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pepijnhe_warehouse_backup_2020_04_28_115452_2993043.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pepijnhe_warehouse_backup_2020_04_28_115452_2993043', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pgcc];
GO
use [master];
GO
BACKUP DATABASE [pgcc] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pgcc_backup_2020_04_28_115452_3149199.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pgcc_backup_2020_04_28_115452_3149199', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pgcc_lor];
GO
use [master];
GO
BACKUP DATABASE [pgcc_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pgcc_lor_backup_2020_04_28_115452_3305457.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pgcc_lor_backup_2020_04_28_115452_3305457', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pgcc_reporting];
GO
use [master];
GO
BACKUP DATABASE [pgcc_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pgcc_reporting_backup_2020_04_28_115452_3461735.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pgcc_reporting_backup_2020_04_28_115452_3461735', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pgcc_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pgcc_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pgcc_warehouse_backup_2020_04_28_115452_3619390.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pgcc_warehouse_backup_2020_04_28_115452_3619390', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [philv];
GO
use [master];
GO
BACKUP DATABASE [philv] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\philv_backup_2020_04_28_115452_3774591.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'philv_backup_2020_04_28_115452_3774591', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [philv_lor];
GO
use [master];
GO
BACKUP DATABASE [philv_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\philv_lor_backup_2020_04_28_115452_3774591.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'philv_lor_backup_2020_04_28_115452_3774591', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [philv_reporting];
GO
use [master];
GO
BACKUP DATABASE [philv_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\philv_reporting_backup_2020_04_28_115452_3930697.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'philv_reporting_backup_2020_04_28_115452_3930697', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [philv_warehouse];
GO
use [master];
GO
BACKUP DATABASE [philv_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\philv_warehouse_backup_2020_04_28_115452_4086722.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'philv_warehouse_backup_2020_04_28_115452_4086722', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pimapd];
GO
use [master];
GO
BACKUP DATABASE [pimapd] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pimapd_backup_2020_04_28_115452_4243025.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pimapd_backup_2020_04_28_115452_4243025', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pimapd_lor];
GO
use [master];
GO
BACKUP DATABASE [pimapd_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pimapd_lor_backup_2020_04_28_115452_4399189.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pimapd_lor_backup_2020_04_28_115452_4399189', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pimapd_reporting];
GO
use [master];
GO
BACKUP DATABASE [pimapd_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pimapd_reporting_backup_2020_04_28_115452_4399189.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pimapd_reporting_backup_2020_04_28_115452_4399189', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [pimapd_warehouse];
GO
use [master];
GO
BACKUP DATABASE [pimapd_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\pimapd_warehouse_backup_2020_04_28_115452_4556196.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'pimapd_warehouse_backup_2020_04_28_115452_4556196', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [plunkett];
GO
use [master];
GO
BACKUP DATABASE [plunkett] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\plunkett_backup_2020_04_28_115452_4711909.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'plunkett_backup_2020_04_28_115452_4711909', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [plunkett_lor];
GO
use [master];
GO
BACKUP DATABASE [plunkett_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\plunkett_lor_backup_2020_04_28_115452_4868012.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'plunkett_lor_backup_2020_04_28_115452_4868012', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [plunkett_reporting];
GO
use [master];
GO
BACKUP DATABASE [plunkett_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\plunkett_reporting_backup_2020_04_28_115452_5024306.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'plunkett_reporting_backup_2020_04_28_115452_5024306', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [plunkett_warehouse];
GO
use [master];
GO
BACKUP DATABASE [plunkett_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\plunkett_warehouse_backup_2020_04_28_115452_5180605.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'plunkett_warehouse_backup_2020_04_28_115452_5180605', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prescottdemo];
GO
use [master];
GO
BACKUP DATABASE [prescottdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prescottdemo_backup_2020_04_28_115452_5180605.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prescottdemo_backup_2020_04_28_115452_5180605', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prescottdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [prescottdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prescottdemo_lor_backup_2020_04_28_115452_5336896.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prescottdemo_lor_backup_2020_04_28_115452_5336896', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prescottdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [prescottdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prescottdemo_reporting_backup_2020_04_28_115452_5493101.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prescottdemo_reporting_backup_2020_04_28_115452_5493101', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prescottdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [prescottdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prescottdemo_warehouse_backup_2020_04_28_115452_5649346.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prescottdemo_warehouse_backup_2020_04_28_115452_5649346', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [proctoru];
GO
use [master];
GO
BACKUP DATABASE [proctoru] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\proctoru_backup_2020_04_28_115452_5805666.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'proctoru_backup_2020_04_28_115452_5805666', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [proctoru_lor];
GO
use [master];
GO
BACKUP DATABASE [proctoru_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\proctoru_lor_backup_2020_04_28_115452_5961731.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'proctoru_lor_backup_2020_04_28_115452_5961731', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [proctoru_reporting];
GO
use [master];
GO
BACKUP DATABASE [proctoru_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\proctoru_reporting_backup_2020_04_28_115452_6118079.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'proctoru_reporting_backup_2020_04_28_115452_6118079', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [proctoru_warehouse];
GO
use [master];
GO
BACKUP DATABASE [proctoru_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\proctoru_warehouse_backup_2020_04_28_115452_6118079.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'proctoru_warehouse_backup_2020_04_28_115452_6118079', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prodcorp];
GO
use [master];
GO
BACKUP DATABASE [prodcorp] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prodcorp_backup_2020_04_28_115452_6275980.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prodcorp_backup_2020_04_28_115452_6275980', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prodcorp_lor];
GO
use [master];
GO
BACKUP DATABASE [prodcorp_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prodcorp_lor_backup_2020_04_28_115452_6432434.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prodcorp_lor_backup_2020_04_28_115452_6432434', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prodcorp_reporting];
GO
use [master];
GO
BACKUP DATABASE [prodcorp_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prodcorp_reporting_backup_2020_04_28_115452_6588688.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prodcorp_reporting_backup_2020_04_28_115452_6588688', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [prodcorp_warehouse];
GO
use [master];
GO
BACKUP DATABASE [prodcorp_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\prodcorp_warehouse_backup_2020_04_28_115452_6744704.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'prodcorp_warehouse_backup_2020_04_28_115452_6744704', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [protos];
GO
use [master];
GO
BACKUP DATABASE [protos] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\protos_backup_2020_04_28_115452_6900704.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'protos_backup_2020_04_28_115452_6900704', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [protos_lor];
GO
use [master];
GO
BACKUP DATABASE [protos_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\protos_lor_backup_2020_04_28_115452_6900704.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'protos_lor_backup_2020_04_28_115452_6900704', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [protos_reporting];
GO
use [master];
GO
BACKUP DATABASE [protos_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\protos_reporting_backup_2020_04_28_115452_7059051.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'protos_reporting_backup_2020_04_28_115452_7059051', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [protos_warehouse];
GO
use [master];
GO
BACKUP DATABASE [protos_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\protos_warehouse_backup_2020_04_28_115452_7214621.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'protos_warehouse_backup_2020_04_28_115452_7214621', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [purdue];
GO
use [master];
GO
BACKUP DATABASE [purdue] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\purdue_backup_2020_04_28_115452_7369777.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'purdue_backup_2020_04_28_115452_7369777', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [purdue_lor];
GO
use [master];
GO
BACKUP DATABASE [purdue_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\purdue_lor_backup_2020_04_28_115452_7525769.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'purdue_lor_backup_2020_04_28_115452_7525769', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [purdue_reporting];
GO
use [master];
GO
BACKUP DATABASE [purdue_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\purdue_reporting_backup_2020_04_28_115452_7682027.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'purdue_reporting_backup_2020_04_28_115452_7682027', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [purdue_warehouse];
GO
use [master];
GO
BACKUP DATABASE [purdue_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\purdue_warehouse_backup_2020_04_28_115452_7682027.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'purdue_warehouse_backup_2020_04_28_115452_7682027', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rachelhe];
GO
use [master];
GO
BACKUP DATABASE [rachelhe] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rachelhe_backup_2020_04_28_115452_7838080.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rachelhe_backup_2020_04_28_115452_7838080', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rachelhe_lor];
GO
use [master];
GO
BACKUP DATABASE [rachelhe_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rachelhe_lor_backup_2020_04_28_115452_7994583.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rachelhe_lor_backup_2020_04_28_115452_7994583', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rachelhe_reporting];
GO
use [master];
GO
BACKUP DATABASE [rachelhe_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rachelhe_reporting_backup_2020_04_28_115452_8151742.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rachelhe_reporting_backup_2020_04_28_115452_8151742', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rachelhe_warehouse];
GO
use [master];
GO
BACKUP DATABASE [rachelhe_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rachelhe_warehouse_backup_2020_04_28_115452_8307411.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rachelhe_warehouse_backup_2020_04_28_115452_8307411', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [randolph007demo];
GO
use [master];
GO
BACKUP DATABASE [randolph007demo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\randolph007demo_backup_2020_04_28_115452_8463066.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'randolph007demo_backup_2020_04_28_115452_8463066', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [randolph007demo_lor];
GO
use [master];
GO
BACKUP DATABASE [randolph007demo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\randolph007demo_lor_backup_2020_04_28_115452_8619824.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'randolph007demo_lor_backup_2020_04_28_115452_8619824', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [randolph007demo_reporting];
GO
use [master];
GO
BACKUP DATABASE [randolph007demo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\randolph007demo_reporting_backup_2020_04_28_115452_8619824.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'randolph007demo_reporting_backup_2020_04_28_115452_8619824', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [randolph007demo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [randolph007demo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\randolph007demo_warehouse_backup_2020_04_28_115452_8788452.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'randolph007demo_warehouse_backup_2020_04_28_115452_8788452', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rbhed];
GO
use [master];
GO
BACKUP DATABASE [rbhed] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rbhed_backup_2020_04_28_115452_8932819.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rbhed_backup_2020_04_28_115452_8932819', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rbhed_lor];
GO
use [master];
GO
BACKUP DATABASE [rbhed_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rbhed_lor_backup_2020_04_28_115452_9088135.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rbhed_lor_backup_2020_04_28_115452_9088135', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rbhed_reporting];
GO
use [master];
GO
BACKUP DATABASE [rbhed_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rbhed_reporting_backup_2020_04_28_115452_9247735.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rbhed_reporting_backup_2020_04_28_115452_9247735', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rbhed_warehouse];
GO
use [master];
GO
BACKUP DATABASE [rbhed_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rbhed_warehouse_backup_2020_04_28_115452_9400634.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rbhed_warehouse_backup_2020_04_28_115452_9400634', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [representedtech];
GO
use [master];
GO
BACKUP DATABASE [representedtech] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\representedtech_backup_2020_04_28_115452_9400634.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'representedtech_backup_2020_04_28_115452_9400634', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [representedtech_lor];
GO
use [master];
GO
BACKUP DATABASE [representedtech_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\representedtech_lor_backup_2020_04_28_115452_9557064.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'representedtech_lor_backup_2020_04_28_115452_9557064', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [representedtech_reporting];
GO
use [master];
GO
BACKUP DATABASE [representedtech_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\representedtech_reporting_backup_2020_04_28_115452_9713453.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'representedtech_reporting_backup_2020_04_28_115452_9713453', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [representedtech_warehouse];
GO
use [master];
GO
BACKUP DATABASE [representedtech_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\representedtech_warehouse_backup_2020_04_28_115452_9873910.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'representedtech_warehouse_backup_2020_04_28_115452_9873910', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rockysandbox];
GO
use [master];
GO
BACKUP DATABASE [rockysandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rockysandbox_backup_2020_04_28_115453_0038311.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rockysandbox_backup_2020_04_28_115453_0038311', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rockysandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [rockysandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rockysandbox_lor_backup_2020_04_28_115453_0182248.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rockysandbox_lor_backup_2020_04_28_115453_0182248', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rockysandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [rockysandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rockysandbox_reporting_backup_2020_04_28_115453_0338137.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rockysandbox_reporting_backup_2020_04_28_115453_0338137', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rockysandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [rockysandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rockysandbox_warehouse_backup_2020_04_28_115453_0494915.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rockysandbox_warehouse_backup_2020_04_28_115453_0494915', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rosalesent];
GO
use [master];
GO
BACKUP DATABASE [rosalesent] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rosalesent_backup_2020_04_28_115453_0494915.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rosalesent_backup_2020_04_28_115453_0494915', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rosalesent_lor];
GO
use [master];
GO
BACKUP DATABASE [rosalesent_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rosalesent_lor_backup_2020_04_28_115453_0651067.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rosalesent_lor_backup_2020_04_28_115453_0651067', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rosalesent_reporting];
GO
use [master];
GO
BACKUP DATABASE [rosalesent_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rosalesent_reporting_backup_2020_04_28_115453_0807284.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rosalesent_reporting_backup_2020_04_28_115453_0807284', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [rosalesent_warehouse];
GO
use [master];
GO
BACKUP DATABASE [rosalesent_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\rosalesent_warehouse_backup_2020_04_28_115453_0964660.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'rosalesent_warehouse_backup_2020_04_28_115453_0964660', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ryersonpd4edu];
GO
use [master];
GO
BACKUP DATABASE [ryersonpd4edu] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ryersonpd4edu_backup_2020_04_28_115453_1119554.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ryersonpd4edu_backup_2020_04_28_115453_1119554', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ryersonpd4edu_lor];
GO
use [master];
GO
BACKUP DATABASE [ryersonpd4edu_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ryersonpd4edu_lor_backup_2020_04_28_115453_1276745.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ryersonpd4edu_lor_backup_2020_04_28_115453_1276745', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ryersonpd4edu_reporting];
GO
use [master];
GO
BACKUP DATABASE [ryersonpd4edu_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ryersonpd4edu_reporting_backup_2020_04_28_115453_1432872.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ryersonpd4edu_reporting_backup_2020_04_28_115453_1432872', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ryersonpd4edu_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ryersonpd4edu_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ryersonpd4edu_warehouse_backup_2020_04_28_115453_1588287.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ryersonpd4edu_warehouse_backup_2020_04_28_115453_1588287', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sae];
GO
use [master];
GO
BACKUP DATABASE [sae] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sae_backup_2020_04_28_115453_1744680.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sae_backup_2020_04_28_115453_1744680', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sae_lor];
GO
use [master];
GO
BACKUP DATABASE [sae_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sae_lor_backup_2020_04_28_115453_1900893.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sae_lor_backup_2020_04_28_115453_1900893', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sae_reporting];
GO
use [master];
GO
BACKUP DATABASE [sae_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sae_reporting_backup_2020_04_28_115453_2057306.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sae_reporting_backup_2020_04_28_115453_2057306', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sae_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sae_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sae_warehouse_backup_2020_04_28_115453_2213740.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sae_warehouse_backup_2020_04_28_115453_2213740', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandboxa1];
GO
use [master];
GO
BACKUP DATABASE [sandboxa1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandboxa1_backup_2020_04_28_115453_2213740.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandboxa1_backup_2020_04_28_115453_2213740', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandboxa1_LOR];
GO
use [master];
GO
BACKUP DATABASE [sandboxa1_LOR] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandboxa1_LOR_backup_2020_04_28_115453_2369806.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandboxa1_LOR_backup_2020_04_28_115453_2369806', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandboxa1_Reporting];
GO
use [master];
GO
BACKUP DATABASE [sandboxa1_Reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandboxa1_Reporting_backup_2020_04_28_115453_2525875.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandboxa1_Reporting_backup_2020_04_28_115453_2525875', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandboxa1_Warehouse];
GO
use [master];
GO
BACKUP DATABASE [sandboxa1_Warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandboxa1_Warehouse_backup_2020_04_28_115453_2682059.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandboxa1_Warehouse_backup_2020_04_28_115453_2682059', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandro];
GO
use [master];
GO
BACKUP DATABASE [sandro] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandro_backup_2020_04_28_115453_2838444.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandro_backup_2020_04_28_115453_2838444', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandro_lor];
GO
use [master];
GO
BACKUP DATABASE [sandro_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandro_lor_backup_2020_04_28_115453_2994493.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandro_lor_backup_2020_04_28_115453_2994493', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandro_reporting];
GO
use [master];
GO
BACKUP DATABASE [sandro_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandro_reporting_backup_2020_04_28_115453_3150620.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandro_reporting_backup_2020_04_28_115453_3150620', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandro_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sandro_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandro_warehouse_backup_2020_04_28_115453_3307132.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandro_warehouse_backup_2020_04_28_115453_3307132', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandroenterprise];
GO
use [master];
GO
BACKUP DATABASE [sandroenterprise] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandroenterprise_backup_2020_04_28_115453_3307132.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandroenterprise_backup_2020_04_28_115453_3307132', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandroenterprise_lor];
GO
use [master];
GO
BACKUP DATABASE [sandroenterprise_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandroenterprise_lor_backup_2020_04_28_115453_3463320.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandroenterprise_lor_backup_2020_04_28_115453_3463320', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandroenterprise_reporting];
GO
use [master];
GO
BACKUP DATABASE [sandroenterprise_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandroenterprise_reporting_backup_2020_04_28_115453_3619804.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandroenterprise_reporting_backup_2020_04_28_115453_3619804', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sandroenterprise_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sandroenterprise_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sandroenterprise_warehouse_backup_2020_04_28_115453_3775685.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sandroenterprise_warehouse_backup_2020_04_28_115453_3775685', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sasha];
GO
use [master];
GO
BACKUP DATABASE [sasha] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sasha_backup_2020_04_28_115453_3932233.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sasha_backup_2020_04_28_115453_3932233', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sasha_lor];
GO
use [master];
GO
BACKUP DATABASE [sasha_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sasha_lor_backup_2020_04_28_115453_3932233.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sasha_lor_backup_2020_04_28_115453_3932233', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sasha_reporting];
GO
use [master];
GO
BACKUP DATABASE [sasha_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sasha_reporting_backup_2020_04_28_115453_4088438.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sasha_reporting_backup_2020_04_28_115453_4088438', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sasha_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sasha_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sasha_warehouse_backup_2020_04_28_115453_4244651.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sasha_warehouse_backup_2020_04_28_115453_4244651', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
--use [sdu1];
--GO
--use [master];
--GO
--BACKUP DATABASE [sdu1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sdu1_backup_2020_04_28_115453_4400987.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sdu1_backup_2020_04_28_115453_4400987', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [sdu1_lor];
--GO
--use [master];
--GO
--BACKUP DATABASE [sdu1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sdu1_lor_backup_2020_04_28_115453_4561312.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sdu1_lor_backup_2020_04_28_115453_4561312', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [sdu1_reporting];
--GO
--use [master];
--GO
--BACKUP DATABASE [sdu1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sdu1_reporting_backup_2020_04_28_115453_4713310.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sdu1_reporting_backup_2020_04_28_115453_4713310', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [sdu1_warehouse];
--GO
--use [master];
--GO
--BACKUP DATABASE [sdu1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sdu1_warehouse_backup_2020_04_28_115453_4713310.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sdu1_warehouse_backup_2020_04_28_115453_4713310', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
use [sejahtera];
GO
use [master];
GO
BACKUP DATABASE [sejahtera] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sejahtera_backup_2020_04_28_115453_4869576.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sejahtera_backup_2020_04_28_115453_4869576', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sejahtera_lor];
GO
use [master];
GO
BACKUP DATABASE [sejahtera_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sejahtera_lor_backup_2020_04_28_115453_5025797.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sejahtera_lor_backup_2020_04_28_115453_5025797', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sejahtera_reporting];
GO
use [master];
GO
BACKUP DATABASE [sejahtera_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sejahtera_reporting_backup_2020_04_28_115453_5182211.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sejahtera_reporting_backup_2020_04_28_115453_5182211', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sejahtera_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sejahtera_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sejahtera_warehouse_backup_2020_04_28_115453_5338125.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sejahtera_warehouse_backup_2020_04_28_115453_5338125', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sennanabase];
GO
use [master];
GO
BACKUP DATABASE [sennanabase] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sennanabase_backup_2020_04_28_115453_5494489.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sennanabase_backup_2020_04_28_115453_5494489', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sennanabase_lor];
GO
use [master];
GO
BACKUP DATABASE [sennanabase_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sennanabase_lor_backup_2020_04_28_115453_5651546.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sennanabase_lor_backup_2020_04_28_115453_5651546', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sennanabase_reporting];
GO
use [master];
GO
BACKUP DATABASE [sennanabase_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sennanabase_reporting_backup_2020_04_28_115453_5807132.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sennanabase_reporting_backup_2020_04_28_115453_5807132', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sennanabase_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sennanabase_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sennanabase_warehouse_backup_2020_04_28_115453_5807132.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sennanabase_warehouse_backup_2020_04_28_115453_5807132', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sessums];
GO
use [master];
GO
BACKUP DATABASE [sessums] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sessums_backup_2020_04_28_115453_5963869.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sessums_backup_2020_04_28_115453_5963869', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sessums_lor];
GO
use [master];
GO
BACKUP DATABASE [sessums_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sessums_lor_backup_2020_04_28_115453_6120361.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sessums_lor_backup_2020_04_28_115453_6120361', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sessums_reporting];
GO
use [master];
GO
BACKUP DATABASE [sessums_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sessums_reporting_backup_2020_04_28_115453_6274419.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sessums_reporting_backup_2020_04_28_115453_6274419', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sessums_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sessums_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sessums_warehouse_backup_2020_04_28_115453_6430554.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sessums_warehouse_backup_2020_04_28_115453_6430554', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [showcase];
GO
use [master];
GO
BACKUP DATABASE [showcase] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\showcase_backup_2020_04_28_115453_6587013.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'showcase_backup_2020_04_28_115453_6587013', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [showcase_lor];
GO
use [master];
GO
BACKUP DATABASE [showcase_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\showcase_lor_backup_2020_04_28_115453_6743307.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'showcase_lor_backup_2020_04_28_115453_6743307', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [showcase_reporting];
GO
use [master];
GO
BACKUP DATABASE [showcase_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\showcase_reporting_backup_2020_04_28_115453_6743307.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'showcase_reporting_backup_2020_04_28_115453_6743307', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [showcase_warehouse];
GO
use [master];
GO
BACKUP DATABASE [showcase_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\showcase_warehouse_backup_2020_04_28_115453_6899336.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'showcase_warehouse_backup_2020_04_28_115453_6899336', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [skidmore];
GO
use [master];
GO
BACKUP DATABASE [skidmore] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\skidmore_backup_2020_04_28_115453_7055586.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'skidmore_backup_2020_04_28_115453_7055586', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [skidmore_lor];
GO
use [master];
GO
BACKUP DATABASE [skidmore_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\skidmore_lor_backup_2020_04_28_115453_7211958.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'skidmore_lor_backup_2020_04_28_115453_7211958', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [skidmore_reporting];
GO
use [master];
GO
BACKUP DATABASE [skidmore_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\skidmore_reporting_backup_2020_04_28_115453_7368077.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'skidmore_reporting_backup_2020_04_28_115453_7368077', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [skidmore_warehouse];
GO
use [master];
GO
BACKUP DATABASE [skidmore_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\skidmore_warehouse_backup_2020_04_28_115453_7368077.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'skidmore_warehouse_backup_2020_04_28_115453_7368077', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smarterservices];
GO
use [master];
GO
BACKUP DATABASE [smarterservices] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smarterservices_backup_2020_04_28_115453_7524597.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smarterservices_backup_2020_04_28_115453_7524597', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smarterservices_lor];
GO
use [master];
GO
BACKUP DATABASE [smarterservices_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smarterservices_lor_backup_2020_04_28_115453_7680613.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smarterservices_lor_backup_2020_04_28_115453_7680613', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smarterservices_reporting];
GO
use [master];
GO
BACKUP DATABASE [smarterservices_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smarterservices_reporting_backup_2020_04_28_115453_7837052.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smarterservices_reporting_backup_2020_04_28_115453_7837052', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smarterservices_warehouse];
GO
use [master];
GO
BACKUP DATABASE [smarterservices_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smarterservices_warehouse_backup_2020_04_28_115453_7993084.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smarterservices_warehouse_backup_2020_04_28_115453_7993084', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smumnsandbox];
GO
use [master];
GO
BACKUP DATABASE [smumnsandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smumnsandbox_backup_2020_04_28_115453_8149412.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smumnsandbox_backup_2020_04_28_115453_8149412', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smumnsandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [smumnsandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smumnsandbox_lor_backup_2020_04_28_115453_8149412.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smumnsandbox_lor_backup_2020_04_28_115453_8149412', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smumnsandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [smumnsandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smumnsandbox_reporting_backup_2020_04_28_115453_8305522.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smumnsandbox_reporting_backup_2020_04_28_115453_8305522', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [smumnsandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [smumnsandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\smumnsandbox_warehouse_backup_2020_04_28_115453_8461735.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'smumnsandbox_warehouse_backup_2020_04_28_115453_8461735', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [spelman];
GO
use [master];
GO
BACKUP DATABASE [spelman] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\spelman_backup_2020_04_28_115453_8618005.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'spelman_backup_2020_04_28_115453_8618005', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [spelman_lor];
GO
use [master];
GO
BACKUP DATABASE [spelman_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\spelman_lor_backup_2020_04_28_115453_8774308.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'spelman_lor_backup_2020_04_28_115453_8774308', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [spelman_reporting];
GO
use [master];
GO
BACKUP DATABASE [spelman_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\spelman_reporting_backup_2020_04_28_115453_8774308.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'spelman_reporting_backup_2020_04_28_115453_8774308', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [spelman_warehouse];
GO
use [master];
GO
BACKUP DATABASE [spelman_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\spelman_warehouse_backup_2020_04_28_115453_8930796.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'spelman_warehouse_backup_2020_04_28_115453_8930796', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sportsscotland1];
GO
use [master];
GO
BACKUP DATABASE [sportsscotland1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sportsscotland1_backup_2020_04_28_115453_9086742.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sportsscotland1_backup_2020_04_28_115453_9086742', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sportsscotland1_lor];
GO
use [master];
GO
BACKUP DATABASE [sportsscotland1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sportsscotland1_lor_backup_2020_04_28_115453_9242959.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sportsscotland1_lor_backup_2020_04_28_115453_9242959', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sportsscotland1_reporting];
GO
use [master];
GO
BACKUP DATABASE [sportsscotland1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sportsscotland1_reporting_backup_2020_04_28_115453_9399279.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sportsscotland1_reporting_backup_2020_04_28_115453_9399279', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sportsscotland1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sportsscotland1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sportsscotland1_warehouse_backup_2020_04_28_115453_9555545.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sportsscotland1_warehouse_backup_2020_04_28_115453_9555545', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
--use [SQL_Trace];
--GO
--use [master];
--GO
--BACKUP DATABASE [SQL_Trace] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\SQL_Trace_backup_2020_04_28_115453_9711827.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'SQL_Trace_backup_2020_04_28_115453_9711827', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
use [ssctech];
GO
use [master];
GO
BACKUP DATABASE [ssctech] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ssctech_backup_2020_04_28_115453_9867844.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ssctech_backup_2020_04_28_115453_9867844', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ssctech_lor];
GO
use [master];
GO
BACKUP DATABASE [ssctech_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ssctech_lor_backup_2020_04_28_115454_0082084.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ssctech_lor_backup_2020_04_28_115454_0082084', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ssctech_reporting];
GO
use [master];
GO
BACKUP DATABASE [ssctech_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ssctech_reporting_backup_2020_04_28_115454_0188670.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ssctech_reporting_backup_2020_04_28_115454_0188670', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ssctech_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ssctech_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ssctech_warehouse_backup_2020_04_28_115454_0337039.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ssctech_warehouse_backup_2020_04_28_115454_0337039', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sunyfit];
GO
use [master];
GO
BACKUP DATABASE [sunyfit] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sunyfit_backup_2020_04_28_115454_0537636.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sunyfit_backup_2020_04_28_115454_0537636', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sunyfit_lor];
GO
use [master];
GO
BACKUP DATABASE [sunyfit_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sunyfit_lor_backup_2020_04_28_115454_0654929.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sunyfit_lor_backup_2020_04_28_115454_0654929', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sunyfit_reporting];
GO
use [master];
GO
BACKUP DATABASE [sunyfit_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sunyfit_reporting_backup_2020_04_28_115454_0805485.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sunyfit_reporting_backup_2020_04_28_115454_0805485', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [sunyfit_warehouse];
GO
use [master];
GO
BACKUP DATABASE [sunyfit_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\sunyfit_warehouse_backup_2020_04_28_115454_0961825.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'sunyfit_warehouse_backup_2020_04_28_115454_0961825', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tae];
GO
use [master];
GO
BACKUP DATABASE [tae] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tae_backup_2020_04_28_115454_1118038.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tae_backup_2020_04_28_115454_1118038', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tae_lor];
GO
use [master];
GO
BACKUP DATABASE [tae_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tae_lor_backup_2020_04_28_115454_1274128.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tae_lor_backup_2020_04_28_115454_1274128', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tae_reporting];
GO
use [master];
GO
BACKUP DATABASE [tae_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tae_reporting_backup_2020_04_28_115454_1430538.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tae_reporting_backup_2020_04_28_115454_1430538', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tae_warehouse];
GO
use [master];
GO
BACKUP DATABASE [tae_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tae_warehouse_backup_2020_04_28_115454_1586992.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tae_warehouse_backup_2020_04_28_115454_1586992', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [taecdemo];
GO
use [master];
GO
BACKUP DATABASE [taecdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\taecdemo_backup_2020_04_28_115454_1586992.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'taecdemo_backup_2020_04_28_115454_1586992', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [taecdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [taecdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\taecdemo_lor_backup_2020_04_28_115454_1743357.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'taecdemo_lor_backup_2020_04_28_115454_1743357', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [taecdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [taecdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\taecdemo_reporting_backup_2020_04_28_115454_1899426.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'taecdemo_reporting_backup_2020_04_28_115454_1899426', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [taecdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [taecdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\taecdemo_warehouse_backup_2020_04_28_115454_2055451.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'taecdemo_warehouse_backup_2020_04_28_115454_2055451', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tantelouisedemo];
GO
use [master];
GO
BACKUP DATABASE [tantelouisedemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tantelouisedemo_backup_2020_04_28_115454_2211971.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tantelouisedemo_backup_2020_04_28_115454_2211971', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tantelouisedemo_lor];
GO
use [master];
GO
BACKUP DATABASE [tantelouisedemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tantelouisedemo_lor_backup_2020_04_28_115454_2368106.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tantelouisedemo_lor_backup_2020_04_28_115454_2368106', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tantelouisedemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [tantelouisedemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tantelouisedemo_reporting_backup_2020_04_28_115454_2524433.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tantelouisedemo_reporting_backup_2020_04_28_115454_2524433', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tantelouisedemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [tantelouisedemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tantelouisedemo_warehouse_backup_2020_04_28_115454_2524433.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tantelouisedemo_warehouse_backup_2020_04_28_115454_2524433', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [techsmith];
GO
use [master];
GO
BACKUP DATABASE [techsmith] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\techsmith_backup_2020_04_28_115454_2680527.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'techsmith_backup_2020_04_28_115454_2680527', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [techsmith_lor];
GO
use [master];
GO
BACKUP DATABASE [techsmith_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\techsmith_lor_backup_2020_04_28_115454_2836789.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'techsmith_lor_backup_2020_04_28_115454_2836789', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [techsmith_reporting];
GO
use [master];
GO
BACKUP DATABASE [techsmith_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\techsmith_reporting_backup_2020_04_28_115454_2993002.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'techsmith_reporting_backup_2020_04_28_115454_2993002', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [techsmith_warehouse];
GO
use [master];
GO
BACKUP DATABASE [techsmith_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\techsmith_warehouse_backup_2020_04_28_115454_3149191.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'techsmith_warehouse_backup_2020_04_28_115454_3149191', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [terida];
GO
use [master];
GO
BACKUP DATABASE [terida] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\terida_backup_2020_04_28_115454_3305408.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'terida_backup_2020_04_28_115454_3305408', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [terida_lor];
GO
use [master];
GO
BACKUP DATABASE [terida_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\terida_lor_backup_2020_04_28_115454_3461756.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'terida_lor_backup_2020_04_28_115454_3461756', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [terida_reporting];
GO
use [master];
GO
BACKUP DATABASE [terida_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\terida_reporting_backup_2020_04_28_115454_3618042.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'terida_reporting_backup_2020_04_28_115454_3618042', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [terida_warehouse];
GO
use [master];
GO
BACKUP DATABASE [terida_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\terida_warehouse_backup_2020_04_28_115454_3618042.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'terida_warehouse_backup_2020_04_28_115454_3618042', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testout];
GO
use [master];
GO
BACKUP DATABASE [testout] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testout_backup_2020_04_28_115454_3774317.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testout_backup_2020_04_28_115454_3774317', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testout_lor];
GO
use [master];
GO
BACKUP DATABASE [testout_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testout_lor_backup_2020_04_28_115454_3930566.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testout_lor_backup_2020_04_28_115454_3930566', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testout_reporting];
GO
use [master];
GO
BACKUP DATABASE [testout_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testout_reporting_backup_2020_04_28_115454_4087009.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testout_reporting_backup_2020_04_28_115454_4087009', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testout_warehouse];
GO
use [master];
GO
BACKUP DATABASE [testout_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testout_warehouse_backup_2020_04_28_115454_4243140.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testout_warehouse_backup_2020_04_28_115454_4243140', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testshowcase];
GO
use [master];
GO
BACKUP DATABASE [testshowcase] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testshowcase_backup_2020_04_28_115454_4399316.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testshowcase_backup_2020_04_28_115454_4399316', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testshowcase_lor];
GO
use [master];
GO
BACKUP DATABASE [testshowcase_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testshowcase_lor_backup_2020_04_28_115454_4555537.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testshowcase_lor_backup_2020_04_28_115454_4555537', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testshowcase_reporting];
GO
use [master];
GO
BACKUP DATABASE [testshowcase_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testshowcase_reporting_backup_2020_04_28_115454_4555537.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testshowcase_reporting_backup_2020_04_28_115454_4555537', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [testshowcase_warehouse];
GO
use [master];
GO
BACKUP DATABASE [testshowcase_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\testshowcase_warehouse_backup_2020_04_28_115454_4711778.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'testshowcase_warehouse_backup_2020_04_28_115454_4711778', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [trocaire];
GO
use [master];
GO
BACKUP DATABASE [trocaire] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\trocaire_backup_2020_04_28_115454_4867979.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'trocaire_backup_2020_04_28_115454_4867979', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [trocaire_lor];
GO
use [master];
GO
BACKUP DATABASE [trocaire_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\trocaire_lor_backup_2020_04_28_115454_5024343.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'trocaire_lor_backup_2020_04_28_115454_5024343', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [trocaire_reporting];
GO
use [master];
GO
BACKUP DATABASE [trocaire_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\trocaire_reporting_backup_2020_04_28_115454_5180577.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'trocaire_reporting_backup_2020_04_28_115454_5180577', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [trocaire_warehouse];
GO
use [master];
GO
BACKUP DATABASE [trocaire_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\trocaire_warehouse_backup_2020_04_28_115454_5336777.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'trocaire_warehouse_backup_2020_04_28_115454_5336777', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [turnitin];
GO
use [master];
GO
BACKUP DATABASE [turnitin] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\turnitin_backup_2020_04_28_115454_5493228.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'turnitin_backup_2020_04_28_115454_5493228', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [turnitin_lor];
GO
use [master];
GO
BACKUP DATABASE [turnitin_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\turnitin_lor_backup_2020_04_28_115454_5649404.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'turnitin_lor_backup_2020_04_28_115454_5649404', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [turnitin_reporting];
GO
use [master];
GO
BACKUP DATABASE [turnitin_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\turnitin_reporting_backup_2020_04_28_115454_5805514.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'turnitin_reporting_backup_2020_04_28_115454_5805514', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [turnitin_warehouse];
GO
use [master];
GO
BACKUP DATABASE [turnitin_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\turnitin_warehouse_backup_2020_04_28_115454_5805514.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'turnitin_warehouse_backup_2020_04_28_115454_5805514', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tutdemo];
GO
use [master];
GO
BACKUP DATABASE [tutdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tutdemo_backup_2020_04_28_115454_5961952.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tutdemo_backup_2020_04_28_115454_5961952', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tutdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [tutdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tutdemo_lor_backup_2020_04_28_115454_6274358.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tutdemo_lor_backup_2020_04_28_115454_6274358', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tutdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [tutdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tutdemo_reporting_backup_2020_04_28_115454_6430738.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tutdemo_reporting_backup_2020_04_28_115454_6430738', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [tutdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [tutdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\tutdemo_warehouse_backup_2020_04_28_115454_6587037.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'tutdemo_warehouse_backup_2020_04_28_115454_6587037', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
--use [udeccltest];
--GO
--use [master];
--GO
--BACKUP DATABASE [udeccltest] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\udeccltest_backup_2020_04_28_115454_6743033.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'udeccltest_backup_2020_04_28_115454_6743033', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [udeccltest_lor];
--GO
--use [master];
--GO
--BACKUP DATABASE [udeccltest_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\udeccltest_lor_backup_2020_04_28_115454_6743033.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'udeccltest_lor_backup_2020_04_28_115454_6743033', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [udeccltest_reporting];
--GO
--use [master];
--GO
--BACKUP DATABASE [udeccltest_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\udeccltest_reporting_backup_2020_04_28_115454_6899291.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'udeccltest_reporting_backup_2020_04_28_115454_6899291', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
--use [udeccltest_warehouse];
--GO
--use [master];
--GO
--BACKUP DATABASE [udeccltest_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\udeccltest_warehouse_backup_2020_04_28_115454_7055721.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'udeccltest_warehouse_backup_2020_04_28_115454_7055721', SKIP, REWIND, NOUNLOAD,  STATS = 10
--GO
use [ufv];
GO
use [master];
GO
BACKUP DATABASE [ufv] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ufv_backup_2020_04_28_115454_7211811.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ufv_backup_2020_04_28_115454_7211811', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ufv_lor];
GO
use [master];
GO
BACKUP DATABASE [ufv_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ufv_lor_backup_2020_04_28_115454_7368036.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ufv_lor_backup_2020_04_28_115454_7368036', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ufv_reporting];
GO
use [master];
GO
BACKUP DATABASE [ufv_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ufv_reporting_backup_2020_04_28_115454_7527063.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ufv_reporting_backup_2020_04_28_115454_7527063', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ufv_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ufv_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ufv_warehouse_backup_2020_04_28_115454_7681097.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ufv_warehouse_backup_2020_04_28_115454_7681097', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ug1];
GO
use [master];
GO
BACKUP DATABASE [ug1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ug1_backup_2020_04_28_115454_7681097.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ug1_backup_2020_04_28_115454_7681097', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ug1_lor];
GO
use [master];
GO
BACKUP DATABASE [ug1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ug1_lor_backup_2020_04_28_115454_7837084.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ug1_lor_backup_2020_04_28_115454_7837084', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ug1_reporting];
GO
use [master];
GO
BACKUP DATABASE [ug1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ug1_reporting_backup_2020_04_28_115454_7993637.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ug1_reporting_backup_2020_04_28_115454_7993637', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ug1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ug1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ug1_warehouse_backup_2020_04_28_115454_8149789.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ug1_warehouse_backup_2020_04_28_115454_8149789', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uindy2];
GO
use [master];
GO
BACKUP DATABASE [uindy2] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uindy2_backup_2020_04_28_115454_8305653.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uindy2_backup_2020_04_28_115454_8305653', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uindy2_lor];
GO
use [master];
GO
BACKUP DATABASE [uindy2_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uindy2_lor_backup_2020_04_28_115454_8461788.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uindy2_lor_backup_2020_04_28_115454_8461788', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uindy2_reporting];
GO
use [master];
GO
BACKUP DATABASE [uindy2_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uindy2_reporting_backup_2020_04_28_115454_8618149.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uindy2_reporting_backup_2020_04_28_115454_8618149', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uindy2_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uindy2_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uindy2_warehouse_backup_2020_04_28_115454_8774534.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uindy2_warehouse_backup_2020_04_28_115454_8774534', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uleth];
GO
use [master];
GO
BACKUP DATABASE [uleth] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uleth_backup_2020_04_28_115454_8930640.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uleth_backup_2020_04_28_115454_8930640', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uleth_lor];
GO
use [master];
GO
BACKUP DATABASE [uleth_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uleth_lor_backup_2020_04_28_115454_8930640.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uleth_lor_backup_2020_04_28_115454_8930640', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uleth_reporting];
GO
use [master];
GO
BACKUP DATABASE [uleth_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uleth_reporting_backup_2020_04_28_115454_9087009.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uleth_reporting_backup_2020_04_28_115454_9087009', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uleth_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uleth_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uleth_warehouse_backup_2020_04_28_115454_9243365.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uleth_warehouse_backup_2020_04_28_115454_9243365', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ultimatemedical];
GO
use [master];
GO
BACKUP DATABASE [ultimatemedical] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ultimatemedical_backup_2020_04_28_115454_9413426.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ultimatemedical_backup_2020_04_28_115454_9413426', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ultimatemedical_lor];
GO
use [master];
GO
BACKUP DATABASE [ultimatemedical_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ultimatemedical_lor_backup_2020_04_28_115454_9555651.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ultimatemedical_lor_backup_2020_04_28_115454_9555651', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ultimatemedical_reporting];
GO
use [master];
GO
BACKUP DATABASE [ultimatemedical_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ultimatemedical_reporting_backup_2020_04_28_115454_9711713.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ultimatemedical_reporting_backup_2020_04_28_115454_9711713', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [ultimatemedical_warehouse];
GO
use [master];
GO
BACKUP DATABASE [ultimatemedical_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\ultimatemedical_warehouse_backup_2020_04_28_115454_9868073.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'ultimatemedical_warehouse_backup_2020_04_28_115454_9868073', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [une];
GO
use [master];
GO
BACKUP DATABASE [une] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\une_backup_2020_04_28_115455_0024355.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'une_backup_2020_04_28_115455_0024355', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [une_lor];
GO
use [master];
GO
BACKUP DATABASE [une_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\une_lor_backup_2020_04_28_115455_0180687.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'une_lor_backup_2020_04_28_115455_0180687', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [une_reporting];
GO
use [master];
GO
BACKUP DATABASE [une_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\une_reporting_backup_2020_04_28_115455_0336798.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'une_reporting_backup_2020_04_28_115455_0336798', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [une_warehouse];
GO
use [master];
GO
BACKUP DATABASE [une_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\une_warehouse_backup_2020_04_28_115455_0493068.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'une_warehouse_backup_2020_04_28_115455_0493068', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uniasselvid2l];
GO
use [master];
GO
BACKUP DATABASE [uniasselvid2l] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uniasselvid2l_backup_2020_04_28_115455_0493068.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uniasselvid2l_backup_2020_04_28_115455_0493068', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uniasselvid2l_lor];
GO
use [master];
GO
BACKUP DATABASE [uniasselvid2l_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uniasselvid2l_lor_backup_2020_04_28_115455_0650010.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uniasselvid2l_lor_backup_2020_04_28_115455_0650010', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uniasselvid2l_reporting];
GO
use [master];
GO
BACKUP DATABASE [uniasselvid2l_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uniasselvid2l_reporting_backup_2020_04_28_115455_0805490.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uniasselvid2l_reporting_backup_2020_04_28_115455_0805490', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uniasselvid2l_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uniasselvid2l_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uniasselvid2l_warehouse_backup_2020_04_28_115455_0961838.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uniasselvid2l_warehouse_backup_2020_04_28_115455_0961838', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uninorte];
GO
use [master];
GO
BACKUP DATABASE [uninorte] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uninorte_backup_2020_04_28_115455_1117997.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uninorte_backup_2020_04_28_115455_1117997', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uninorte_lor];
GO
use [master];
GO
BACKUP DATABASE [uninorte_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uninorte_lor_backup_2020_04_28_115455_1299843.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uninorte_lor_backup_2020_04_28_115455_1299843', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uninorte_reporting];
GO
use [master];
GO
BACKUP DATABASE [uninorte_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uninorte_reporting_backup_2020_04_28_115455_1488029.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uninorte_reporting_backup_2020_04_28_115455_1488029', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uninorte_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uninorte_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uninorte_warehouse_backup_2020_04_28_115455_1588991.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uninorte_warehouse_backup_2020_04_28_115455_1588991', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unmdemo];
GO
use [master];
GO
BACKUP DATABASE [unmdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unmdemo_backup_2020_04_28_115455_1747223.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unmdemo_backup_2020_04_28_115455_1747223', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unmdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [unmdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unmdemo_lor_backup_2020_04_28_115455_1899471.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unmdemo_lor_backup_2020_04_28_115455_1899471', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unmdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [unmdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unmdemo_reporting_backup_2020_04_28_115455_2058772.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unmdemo_reporting_backup_2020_04_28_115455_2058772', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unmdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [unmdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unmdemo_warehouse_backup_2020_04_28_115455_2211991.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unmdemo_warehouse_backup_2020_04_28_115455_2211991', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unsw1];
GO
use [master];
GO
BACKUP DATABASE [unsw1] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unsw1_backup_2020_04_28_115455_2368057.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unsw1_backup_2020_04_28_115455_2368057', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unsw1_lor];
GO
use [master];
GO
BACKUP DATABASE [unsw1_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unsw1_lor_backup_2020_04_28_115455_2528505.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unsw1_lor_backup_2020_04_28_115455_2528505', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unsw1_reporting];
GO
use [master];
GO
BACKUP DATABASE [unsw1_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unsw1_reporting_backup_2020_04_28_115455_2681080.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unsw1_reporting_backup_2020_04_28_115455_2681080', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [unsw1_warehouse];
GO
use [master];
GO
BACKUP DATABASE [unsw1_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\unsw1_warehouse_backup_2020_04_28_115455_2837879.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'unsw1_warehouse_backup_2020_04_28_115455_2837879', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [upstate];
GO
use [master];
GO
BACKUP DATABASE [upstate] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\upstate_backup_2020_04_28_115455_2995321.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'upstate_backup_2020_04_28_115455_2995321', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [upstate_lor];
GO
use [master];
GO
BACKUP DATABASE [upstate_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\upstate_lor_backup_2020_04_28_115455_3149780.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'upstate_lor_backup_2020_04_28_115455_3149780', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [upstate_reporting];
GO
use [master];
GO
BACKUP DATABASE [upstate_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\upstate_reporting_backup_2020_04_28_115455_3149780.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'upstate_reporting_backup_2020_04_28_115455_3149780', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [upstate_warehouse];
GO
use [master];
GO
BACKUP DATABASE [upstate_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\upstate_warehouse_backup_2020_04_28_115455_3305514.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'upstate_warehouse_backup_2020_04_28_115455_3305514', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uremington];
GO
use [master];
GO
BACKUP DATABASE [uremington] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uremington_backup_2020_04_28_115455_3461833.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uremington_backup_2020_04_28_115455_3461833', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uremington_lor];
GO
use [master];
GO
BACKUP DATABASE [uremington_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uremington_lor_backup_2020_04_28_115455_3618370.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uremington_lor_backup_2020_04_28_115455_3618370', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uremington_reporting];
GO
use [master];
GO
BACKUP DATABASE [uremington_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uremington_reporting_backup_2020_04_28_115455_3774382.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uremington_reporting_backup_2020_04_28_115455_3774382', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uremington_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uremington_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uremington_warehouse_backup_2020_04_28_115455_3930927.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uremington_warehouse_backup_2020_04_28_115455_3930927', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [usask];
GO
use [master];
GO
BACKUP DATABASE [usask] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\usask_backup_2020_04_28_115455_4086906.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'usask_backup_2020_04_28_115455_4086906', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [usask_lor];
GO
use [master];
GO
BACKUP DATABASE [usask_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\usask_lor_backup_2020_04_28_115455_4086906.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'usask_lor_backup_2020_04_28_115455_4086906', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [usask_reporting];
GO
use [master];
GO
BACKUP DATABASE [usask_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\usask_reporting_backup_2020_04_28_115455_4243885.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'usask_reporting_backup_2020_04_28_115455_4243885', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [usask_warehouse];
GO
use [master];
GO
BACKUP DATABASE [usask_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\usask_warehouse_backup_2020_04_28_115455_4413291.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'usask_warehouse_backup_2020_04_28_115455_4413291', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uvm];
GO
use [master];
GO
BACKUP DATABASE [uvm] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uvm_backup_2020_04_28_115455_4555815.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uvm_backup_2020_04_28_115455_4555815', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uvm_lor];
GO
use [master];
GO
BACKUP DATABASE [uvm_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uvm_lor_backup_2020_04_28_115455_4711909.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uvm_lor_backup_2020_04_28_115455_4711909', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uvm_reporting];
GO
use [master];
GO
BACKUP DATABASE [uvm_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uvm_reporting_backup_2020_04_28_115455_4868077.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uvm_reporting_backup_2020_04_28_115455_4868077', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [uvm_warehouse];
GO
use [master];
GO
BACKUP DATABASE [uvm_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\uvm_warehouse_backup_2020_04_28_115455_5025171.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'uvm_warehouse_backup_2020_04_28_115455_5025171', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [visions];
GO
use [master];
GO
BACKUP DATABASE [visions] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\visions_backup_2020_04_28_115455_5180654.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'visions_backup_2020_04_28_115455_5180654', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [visions_lor];
GO
use [master];
GO
BACKUP DATABASE [visions_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\visions_lor_backup_2020_04_28_115455_5336994.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'visions_lor_backup_2020_04_28_115455_5336994', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [visions_reporting];
GO
use [master];
GO
BACKUP DATABASE [visions_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\visions_reporting_backup_2020_04_28_115455_5336994.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'visions_reporting_backup_2020_04_28_115455_5336994', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [visions_warehouse];
GO
use [master];
GO
BACKUP DATABASE [visions_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\visions_warehouse_backup_2020_04_28_115455_5493346.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'visions_warehouse_backup_2020_04_28_115455_5493346', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wcu];
GO
use [master];
GO
BACKUP DATABASE [wcu] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wcu_backup_2020_04_28_115455_5649363.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wcu_backup_2020_04_28_115455_5649363', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wcu_lor];
GO
use [master];
GO
BACKUP DATABASE [wcu_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wcu_lor_backup_2020_04_28_115455_5805694.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wcu_lor_backup_2020_04_28_115455_5805694', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wcu_reporting];
GO
use [master];
GO
BACKUP DATABASE [wcu_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wcu_reporting_backup_2020_04_28_115455_5961887.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wcu_reporting_backup_2020_04_28_115455_5961887', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wcu_warehouse];
GO
use [master];
GO
BACKUP DATABASE [wcu_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wcu_warehouse_backup_2020_04_28_115455_6118214.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wcu_warehouse_backup_2020_04_28_115455_6118214', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wheaton];
GO
use [master];
GO
BACKUP DATABASE [wheaton] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wheaton_backup_2020_04_28_115455_6118214.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wheaton_backup_2020_04_28_115455_6118214', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wheaton_lor];
GO
use [master];
GO
BACKUP DATABASE [wheaton_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wheaton_lor_backup_2020_04_28_115455_6430628.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wheaton_lor_backup_2020_04_28_115455_6430628', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wheaton_reporting];
GO
use [master];
GO
BACKUP DATABASE [wheaton_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wheaton_reporting_backup_2020_04_28_115455_6586841.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wheaton_reporting_backup_2020_04_28_115455_6586841', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [wheaton_warehouse];
GO
use [master];
GO
BACKUP DATABASE [wheaton_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\wheaton_warehouse_backup_2020_04_28_115455_6586841.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'wheaton_warehouse_backup_2020_04_28_115455_6586841', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [willolabs];
GO
use [master];
GO
BACKUP DATABASE [willolabs] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\willolabs_backup_2020_04_28_115455_6743127.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'willolabs_backup_2020_04_28_115455_6743127', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [willolabs_lor];
GO
use [master];
GO
BACKUP DATABASE [willolabs_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\willolabs_lor_backup_2020_04_28_115455_6899414.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'willolabs_lor_backup_2020_04_28_115455_6899414', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [willolabs_reporting];
GO
use [master];
GO
BACKUP DATABASE [willolabs_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\willolabs_reporting_backup_2020_04_28_115455_7055680.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'willolabs_reporting_backup_2020_04_28_115455_7055680', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [willolabs_warehouse];
GO
use [master];
GO
BACKUP DATABASE [willolabs_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\willolabs_warehouse_backup_2020_04_28_115455_7211950.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'willolabs_warehouse_backup_2020_04_28_115455_7211950', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsandbox];
GO
use [master];
GO
BACKUP DATABASE [witsandbox] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsandbox_backup_2020_04_28_115455_7368265.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsandbox_backup_2020_04_28_115455_7368265', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsandbox_lor];
GO
use [master];
GO
BACKUP DATABASE [witsandbox_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsandbox_lor_backup_2020_04_28_115455_7368265.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsandbox_lor_backup_2020_04_28_115455_7368265', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsandbox_reporting];
GO
use [master];
GO
BACKUP DATABASE [witsandbox_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsandbox_reporting_backup_2020_04_28_115455_7524679.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsandbox_reporting_backup_2020_04_28_115455_7524679', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsandbox_warehouse];
GO
use [master];
GO
BACKUP DATABASE [witsandbox_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsandbox_warehouse_backup_2020_04_28_115455_7680634.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsandbox_warehouse_backup_2020_04_28_115455_7680634', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsdemo];
GO
use [master];
GO
BACKUP DATABASE [witsdemo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsdemo_backup_2020_04_28_115455_7836888.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsdemo_backup_2020_04_28_115455_7836888', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsdemo_lor];
GO
use [master];
GO
BACKUP DATABASE [witsdemo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsdemo_lor_backup_2020_04_28_115455_7993305.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsdemo_lor_backup_2020_04_28_115455_7993305', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsdemo_reporting];
GO
use [master];
GO
BACKUP DATABASE [witsdemo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsdemo_reporting_backup_2020_04_28_115455_8149580.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsdemo_reporting_backup_2020_04_28_115455_8149580', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [witsdemo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [witsdemo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\witsdemo_warehouse_backup_2020_04_28_115455_8305698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'witsdemo_warehouse_backup_2020_04_28_115455_8305698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [yujademo];
GO
use [master];
GO
BACKUP DATABASE [yujademo] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\yujademo_backup_2020_04_28_115455_8305698.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'yujademo_backup_2020_04_28_115455_8305698', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [yujademo_lor];
GO
use [master];
GO
BACKUP DATABASE [yujademo_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\yujademo_lor_backup_2020_04_28_115455_8461743.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'yujademo_lor_backup_2020_04_28_115455_8461743', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [yujademo_reporting];
GO
use [master];
GO
BACKUP DATABASE [yujademo_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\yujademo_reporting_backup_2020_04_28_115455_8618091.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'yujademo_reporting_backup_2020_04_28_115455_8618091', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [yujademo_warehouse];
GO
use [master];
GO
BACKUP DATABASE [yujademo_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\yujademo_warehouse_backup_2020_04_28_115455_8774374.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'yujademo_warehouse_backup_2020_04_28_115455_8774374', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [zoom];
GO
use [master];
GO
BACKUP DATABASE [zoom] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\zoom_backup_2020_04_28_115455_8930607.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'zoom_backup_2020_04_28_115455_8930607', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [zoom_lor];
GO
use [master];
GO
BACKUP DATABASE [zoom_lor] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\zoom_lor_backup_2020_04_28_115455_9086972.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'zoom_lor_backup_2020_04_28_115455_9086972', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [zoom_reporting];
GO
use [master];
GO
BACKUP DATABASE [zoom_reporting] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\zoom_reporting_backup_2020_04_28_115455_9243144.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'zoom_reporting_backup_2020_04_28_115455_9243144', SKIP, REWIND, NOUNLOAD,  STATS = 10
GO
use [zoom_warehouse];
GO
use [master];
GO
BACKUP DATABASE [zoom_warehouse] TO  DISK = N'Z:\SQL_Backups\Temp\Diffs\zoom_warehouse_backup_2020_04_28_115455_9399311.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'zoom_warehouse_backup_2020_04_28_115455_9399311', SKIP, REWIND, NOUNLOAD,  STATS = 10
--4:18
--4:24
--3:52