DECLARE @v1 BIGINT, @delay SMALLINT = 2, @time DATETIME;
-- Get CPU Utilization History for last 30 minutes (SQL 2008)
DECLARE @ts_now bigint = (SELECT cpu_ticks/(cpu_ticks/ms_ticks)FROM sys.dm_os_sys_info);  
SELECT @time = DATEADD(SECOND, @delay, '00:00:00');
 
SELECT @v1 = cntr_value 
FROM master.sys.dm_os_performance_counters
WHERE counter_name = 'Batch Requests/sec';
 
WAITFOR DELAY @time;
 
select 


(SELECT TOP(1) 'CPU%  = '+cast (SQLProcessUtilization as Char) 
               --SystemIdle AS [System Idle Process], 
               --100 - SystemIdle - SQLProcessUtilization AS [Other Process CPU Utilization], 
               
FROM ( 
	  SELECT record.value('(./Record/@id)[1]', 'int') AS record_id, 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') 
			AS [SystemIdle], 
			record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 
			'int') 
			AS [SQLProcessUtilization], [timestamp] 
	  FROM ( 
			SELECT [timestamp], CONVERT(xml, record) AS [record] 
			FROM sys.dm_os_ring_buffers 
			WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' 
			AND record LIKE '%<SystemHealth>%') AS x 
	  ) AS y 
) CPU,
(
SELECT 'BatchReq_Sec = '+ cast((cntr_value - @v1)/@delay as char)
FROM master.sys.dm_os_performance_counters
WHERE counter_name='Batch Requests/sec' ) Batch

--CPU%  = 11 BatchReq_Sec = 12602                         