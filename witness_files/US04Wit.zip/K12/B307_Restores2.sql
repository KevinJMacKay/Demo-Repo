RESTORE DATABASE [k12_LOR] FROM  DISK = N'Z:\SQL_Backups\Temp\k12_LOR\k12_LOR_FULL_2020_8_31__05_04_38_US04APSQLB302.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,
MOVE N'emptydatabase' TO N'I:\SQL_Data\k12_LOR.mdf'  ,MOVE N'emptydatabase_log' TO N'J:\SQL_Logs\k12_LOR_Log.ldf'
RESTORE DATABASE [k12_Reporting] FROM  DISK = N'Z:\SQL_Backups\Temp\k12_Reporting\k12_Reporting_FULL_2020_8_31__05_02_21_US04APSQLB302.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,
MOVE N'chronos_base_base_reporting' TO N'I:\SQL_Data\k12_Reporting.mdf'  ,MOVE N'chronos_base_base_reporting_log' TO N'J:\SQL_Logs\k12_Reporting_Log.ldf'
--RESTORE DATABASE [IPAS_k12] FROM  DISK = N'Z:\SQL_Backups\Temp\IPAS_k12\IPAS_k12_FULL_2020_9_7__05_10_28_US04APSQLB301.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,
--MOVE N'shibboleth' TO N'I:\SQL_Data\IPAS_k12.mdf'  ,MOVE N'shibboleth_log' TO N'J:\SQL_Logs\IPAS_k12_0.ldf'