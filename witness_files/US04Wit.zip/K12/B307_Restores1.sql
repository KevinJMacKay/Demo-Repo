RESTORE DATABASE [k12_Audit] FROM  DISK = N'Z:\SQL_Backups\Temp\k12_Audit\k12_Audit_FULL_2020_8_31__05_44_22_US04APSQLB302.bak' WITH FILE = 1, STATS = 5, NORECOVERY
,MOVE N'Audit' TO N'G:\SQL_Data\k12_Audit.mdf'  ,MOVE N'Audit_log' TO N'H:\SQL_Logs\k12_Audit_Log.ldf'
RESTORE DATABASE [K12_Audit_Archive] FROM  DISK = N'Z:\SQL_Backups\Temp\K12_Audit_Archive\K12_Audit_Archive_FULL_2020_8_31__05_11_29_US04APSQLB302.bak' WITH FILE = 1, STATS = 5, 
NORECOVERY  ,MOVE N'K12_Audit_Archive' TO N'G:\SQL_Data\K12_Audit_Archive.mdf'  ,MOVE N'K12_Audit_Archive_log' TO N'H:\SQL_Logs\K12_Audit_Archive_log.ldf'
