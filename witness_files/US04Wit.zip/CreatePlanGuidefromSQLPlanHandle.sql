--Pinning sproc to known good query plan.

--recompile suspect query example
USE K12;
GO
EXEC sp_recompile N's_LE_CONTENT_FetchAncestorsV2';
GO


--If query performance improves after recompile; capture plan handle and use for plan guide
--get plan handle
select 
    db_name(st.dbid) as database_name,
    object_name(st.objectid, st.dbid) sproc_name, 
       qs.statement_start_offset,
       qs.plan_handle
from sys.dm_exec_query_stats qs
cross apply sys.dm_exec_sql_text(qs.sql_handle) st
where object_name(st.objectid, st.dbid) = 's_LE_CONTENT_FetchAncestorsV2'

--OR

SELECT object_name(object_id, database_id) AS sproc_name,*
    FROM sys.dm_exec_procedure_stats 
WHERE object_name(object_id, database_id) Like 's_LE_CONTENT_FetchAncestorsV2%'

--Create Plan Guide using known good plan handle
EXEC sp_create_plan_guide_from_handle
  @name = 'Stable_FetchAncestorsV2',
  @plan_handle = 0x05000700509934618095B4C62C00000001000000000000000000000000000000000000000000000000000000, 
  @statement_start_offset = NULL;


-- Verify the plan guides are created.
SELECT * FROM sys.plan_guides;
GO

--Disable the plan guide.
EXEC sp_control_plan_guide N'DISABLE', N'Stable_FetchAncestorsV2';
GO
--Enable the plan guide.
EXEC sp_control_plan_guide N'ENABLE', N'Stable_FetchAncestorsV2';
GO
--Drop the plan guide.
EXEC sp_control_plan_guide N'DROP', N'Stable_FetchAncestorsV2';


--Additional reference: https://msdn.microsoft.com/en-us/library/bb964726.aspx


Select NAME from sys.all_objects
where name like 'sp_%'

SELECT query_plan
    FROM sys.dm_exec_query_stats AS qs 
    CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
    CROSS APPLY sys.dm_exec_text_query_plan(qs.plan_handle, DEFAULT, DEFAULT) AS qp
    WHERE st.text LIKE N'select NAME from sys.all_objects%' AND st.text LIKE N'%OPTION (FORCE ORDER)%'

-- Inspect the query plan handle by using dynamic management views.
SELECT * FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
CROSS APPLY sys.dm_exec_text_query_plan(qs.plan_handle, qs.statement_start_offset, qs.statement_end_offset) AS qp
WHERE text LIKE N'select NAME from sys.all_objects%';
GO
-- Create a plan guide for the query by specifying the query plan in the plan cache.
DECLARE @plan_handle varbinary(64);
DECLARE @offset int;
SELECT @plan_handle = plan_handle, @offset = qs.statement_start_offset
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
CROSS APPLY sys.dm_exec_text_query_plan(qs.plan_handle, qs.statement_start_offset, qs.statement_end_offset) AS qp
WHERE text LIKE N'select NAME from sys.all_objects%';

EXECUTE sp_create_plan_guide_from_handle 
    @name =  N'Guide1',
    @plan_handle = @plan_handle,
    @statement_start_offset = @offset;
GO
-- Verify that the plan guide is created.
SELECT * FROM sys.plan_guides
WHERE scope_batch LIKE N'select NAME from sys.all_objects%';
GO






