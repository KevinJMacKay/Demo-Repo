--Compatible with SQL 2014 / 2016

--FULL restore
/*
--Use this one...
Get-Childitem -Path Z:\SQL_Backups\FULL\k12 -Recurse |  where {$_.extension -eq ".bak" -OR $_.extension -eq ".trn"} | ForEach-Object  {$a = $_.fullname ; "('$a'),"}
Get-Childitem -Path M:\MP_Restore_37B\SQL_Backups\ -Recurse  | ForEach-Object  {$a = $_.fullname ; "('$a'),"}
Invoke-Command -ComputerName US04APSQLH202 -ScriptBlock {Get-Childitem -Path V:\SQL_Backups\FULL  -Recurse  | ForEach-Object  {$a = $_.fullname ; "('$a'),"}}

*/

IF OBJECT_ID (N'tempdb..#tmp') IS NOT NULL Drop table #tmp
IF OBJECT_ID (N'tempdb..#Results') IS NOT NULL Drop table #Results
IF OBJECT_ID (N'tempdb..#BackupPaths') IS NOT NULL Drop table #BackupPaths
IF OBJECT_ID (N'tempdb..#HeaderTable') IS NOT NULL Drop table #HeaderTable

create table #BackupPaths
(Path varchar(555) null)

insert into #BackupPaths
values
-----------------------paste backup paths below (including filename)-----test------------------


('V:\SQL_Backups\FULL\afbea\afbea_FULL_2021_12_20__06_36_33_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\afbea_lor\afbea_lor_FULL_2021_12_20__06_36_33_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\afbea_warehouse\afbea_warehouse_FULL_2021_12_20__06_36_32_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\alleganyc\alleganyc_FULL_2021_12_20__06_32_37_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\alleganyc_lor\alleganyc_lor_FULL_2021_12_20__06_32_37_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\alleganyc_reporting\alleganyc_reporting_FULL_2021_12_20__06_32_21_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\angelescollege\angelescollege_FULL_2021_12_20__07_50_20_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\angelescollege_LOR\angelescollege_LOR_FULL_2021_12_20__07_50_20_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\angelescollege_Warehouse\angelescollege_Warehouse_FULL_2021_12_20__07_50_19_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\aspen\aspen_FULL_2021_12_20__06_15_24_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\aspen_LOR\aspen_LOR_FULL_2021_12_20__06_15_23_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\aspen_Reporting\aspen_Reporting_FULL_2021_12_20__06_13_21_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\aspen_Warehouse\aspen_Warehouse_FULL_2021_12_20__06_13_20_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\atsinstitute\atsinstitute_FULL_2021_12_20__07_49_55_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\atsinstitute_lor\atsinstitute_lor_FULL_2021_12_20__07_49_55_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\beulah\beulah_FULL_2021_12_20__06_13_05_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\beulah_lor\beulah_lor_FULL_2021_12_20__06_13_05_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\beulah_reporting\beulah_reporting_FULL_2021_12_20__06_13_00_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\beulah_warehouse\beulah_warehouse_FULL_2021_12_20__06_13_00_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\binghamton\binghamton_FULL_2021_12_20__07_48_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\binghamton_lor\binghamton_lor_FULL_2021_12_20__07_48_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\binghamton_reporting\binghamton_reporting_FULL_2021_12_20__07_47_42_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\binghamton_warehouse\binghamton_warehouse_FULL_2021_12_20__07_47_42_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\bryancollege\bryancollege_FULL_2021_12_20__06_10_01_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\bryancollege_lor\bryancollege_lor_FULL_2021_12_20__06_10_00_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ccbc\ccbc_FULL_2021_12_20__06_00_04_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ccbc_lor\ccbc_lor_FULL_2021_12_20__06_00_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ccbc_warehouse\ccbc_warehouse_FULL_2021_12_20__06_00_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\cedvapwc\cedvapwc_FULL_2021_12_20__07_46_14_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\cedvapwc_lor\cedvapwc_lor_FULL_2021_12_20__07_46_14_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\cedvapwc_warehouse\cedvapwc_warehouse_FULL_2021_12_20__07_46_13_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\clintoncollege\clintoncollege_FULL_2021_12_20__05_59_54_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\clintoncollege_lor\clintoncollege_lor_FULL_2021_12_20__05_59_54_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\clintoncollege_reporting\clintoncollege_reporting_FULL_2021_12_20__05_59_50_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\cnm_CourseCatalog\cnm_CourseCatalog_FULL_2021_12_20__05_59_50_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\coloradodenveru\coloradodenveru_FULL_2021_12_20__07_46_07_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\coloradodenveru_LOR\coloradodenveru_LOR_FULL_2021_12_20__07_46_06_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\coloradodenveru_Warehouse\coloradodenveru_Warehouse_FULL_2021_12_20__07_46_05_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\colsubsidio\colsubsidio_FULL_2021_12_20__07_44_05_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\colsubsidio_lor\colsubsidio_lor_FULL_2021_12_20__07_44_05_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\colsubsidio_warehouse\colsubsidio_warehouse_FULL_2021_12_20__07_44_04_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\csmdlp_CourseCatalog\csmdlp_CourseCatalog_FULL_2021_12_20__07_44_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\cummingsinstitute\cummingsinstitute_FULL_2021_12_20__05_59_41_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\cummingsinstitute_LOR\cummingsinstitute_LOR_FULL_2021_12_20__05_59_41_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\erskinecollege\erskinecollege_FULL_2021_12_20__07_43_40_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\erskinecollege_lor\erskinecollege_lor_FULL_2021_12_20__07_43_39_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\erskinecollege_warehouse\erskinecollege_warehouse_FULL_2021_12_20__07_43_39_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\fgvesc\fgvesc_FULL_2021_12_20__05_51_42_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\fgvesc_lor\fgvesc_lor_FULL_2021_12_20__05_51_35_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\fgvesc_sis\fgvesc_sis_FULL_2021_12_20__05_50_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\fgvesc_warehouse\fgvesc_warehouse_FULL_2021_12_20__05_50_02_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\flvsprod\flvsprod_FULL_2021_12_20__07_43_09_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\flvsprod_lor\flvsprod_lor_FULL_2021_12_20__07_43_09_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\grupopositivo\grupopositivo_FULL_2021_12_20__05_41_50_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\grupopositivo_lor\grupopositivo_lor_FULL_2021_12_20__05_41_49_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\grupopositivo_reporting\grupopositivo_reporting_FULL_2021_12_20__05_39_44_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\grupopositivo_warehouse\grupopositivo_warehouse_FULL_2021_12_20__05_39_44_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\gsu\gsu_FULL_2021_12_20__06_51_15_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\gsu_LOR\gsu_LOR_FULL_2021_12_20__06_51_15_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\gsu_Reporting\gsu_Reporting_FULL_2021_12_20__06_48_06_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\iays\iays_FULL_2021_12_20__05_39_30_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\iays_lor\iays_lor_FULL_2021_12_20__05_39_29_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\iays_reporting\iays_reporting_FULL_2021_12_20__05_39_23_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ilearnnyc_CourseCatalog\ilearnnyc_CourseCatalog_FULL_2021_12_20__06_48_06_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\infinity\infinity_FULL_2021_12_20__05_36_53_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\infinity_LOR\infinity_LOR_FULL_2021_12_20__05_36_53_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\infinity_Reporting\infinity_Reporting_FULL_2021_12_20__05_36_33_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\IPAS_shss\IPAS_shss_FULL_2021_12_20__06_48_05_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\IPAS_ytc\IPAS_ytc_FULL_2021_12_20__06_48_05_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\itmerida\itmerida_FULL_2021_12_20__05_34_52_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\itmerida_lor\itmerida_lor_FULL_2021_12_20__05_34_52_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\jfk\jfk_FULL_2021_12_20__05_34_49_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\jfk_lor\jfk_lor_FULL_2021_12_20__05_34_48_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\jfk_warehouse\jfk_warehouse_FULL_2021_12_20__05_34_48_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lcc\lcc_FULL_2021_12_20__06_20_33_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\lcc_LOR\lcc_LOR_FULL_2021_12_20__06_20_29_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\lcc_Reporting\lcc_Reporting_FULL_2021_12_20__06_17_45_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\lcc_SIS\lcc_SIS_FULL_2021_12_20__06_17_43_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\lcomc\lcomc_FULL_2021_12_20__05_34_41_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lcomc_lor\lcomc_lor_FULL_2021_12_20__05_34_40_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lcomc_warehouse\lcomc_warehouse_FULL_2021_12_20__05_34_40_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\leap-es\leap-es_FULL_2021_12_20__05_21_41_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\leap-ptbr\leap-ptbr_FULL_2021_12_20__05_21_28_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lifepoint\lifepoint_FULL_2021_12_20__05_21_24_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lifepoint_lor\lifepoint_lor_FULL_2021_12_20__05_21_23_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lifepoint_reporting\lifepoint_reporting_FULL_2021_12_20__05_21_19_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lifepoint_warehouse\lifepoint_warehouse_FULL_2021_12_20__05_21_18_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\llac\llac_FULL_2021_12_20__05_21_15_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\llac_lor\llac_lor_FULL_2021_12_20__05_21_14_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\llac_warehouse\llac_warehouse_FULL_2021_12_20__05_21_13_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\lmu\lmu_FULL_2021_12_20__06_10_10_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\lmu_LOR\lmu_LOR_FULL_2021_12_20__06_10_09_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ludoteca\ludoteca_FULL_2021_12_20__06_09_52_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ludoteca_lor\ludoteca_lor_FULL_2021_12_20__06_09_51_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ludoteca_warehouse\ludoteca_warehouse_FULL_2021_12_20__06_09_50_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\marletteschools\marletteschools_FULL_2021_12_20__06_09_23_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\marletteschools_lor\marletteschools_lor_FULL_2021_12_20__06_09_23_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\marletteschools_warehouse\marletteschools_warehouse_FULL_2021_12_20__06_09_22_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\mccormick\mccormick_FULL_2021_12_20__05_21_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\mccormick_lor\mccormick_lor_FULL_2021_12_20__05_21_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\mccormick_warehouse\mccormick_warehouse_FULL_2021_12_20__05_21_02_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ndm\ndm_FULL_2021_12_20__05_20_22_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\ndm_lor\ndm_lor_FULL_2021_12_20__05_20_21_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\northmuskegon\northmuskegon_FULL_2021_12_20__06_09_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\northmuskegon_lor\northmuskegon_lor_FULL_2021_12_20__06_09_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\northmuskegon_warehouse\northmuskegon_warehouse_FULL_2021_12_20__06_09_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\nprc\nprc_FULL_2021_12_20__06_08_54_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\nprc_lor\nprc_lor_FULL_2021_12_20__06_08_54_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\nprc_warehouse\nprc_warehouse_FULL_2021_12_20__06_08_53_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\occ\occ_FULL_2021_12_20__05_52_06_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\occ_LOR\occ_LOR_FULL_2021_12_20__05_52_06_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\occ_Reporting\occ_Reporting_FULL_2021_12_20__05_49_51_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\occ_SIS\occ_SIS_FULL_2021_12_20__05_49_49_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\occ_Warehouse\occ_Warehouse_FULL_2021_12_20__05_49_49_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\otis\otis_FULL_2021_12_20__05_49_25_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\otis_lor\otis_lor_FULL_2021_12_20__05_49_24_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\otis_reporting\otis_reporting_FULL_2021_12_20__05_49_16_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\paceu\paceu_FULL_2021_12_20__05_10_49_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\paceu_lor\paceu_lor_FULL_2021_12_20__05_10_48_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\paceu_warehouse\paceu_warehouse_FULL_2021_12_20__05_10_48_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\pgalumni_coursecatalog\pgalumni_coursecatalog_FULL_2021_12_20__05_49_15_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\phcc\phcc_FULL_2021_12_20__05_49_04_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\phcc_LOR\phcc_LOR_FULL_2021_12_20__05_49_04_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\phcc_Warehouse\phcc_Warehouse_FULL_2021_12_20__05_49_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\sandusky\sandusky_FULL_2021_12_20__05_48_39_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\sandusky_lor\sandusky_lor_FULL_2021_12_20__05_48_38_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\sandusky_reporting\sandusky_reporting_FULL_2021_12_20__05_48_34_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\sandusky_warehouse\sandusky_warehouse_FULL_2021_12_20__05_48_33_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\sewanee\sewanee_FULL_2021_12_20__05_08_36_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\sewanee_lor\sewanee_lor_FULL_2021_12_20__05_08_35_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\shss\shss_FULL_2021_12_20__05_48_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\shss_LOR\shss_LOR_FULL_2021_12_20__05_48_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\shss_Warehouse\shss_Warehouse_FULL_2021_12_20__05_48_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\summitacademy\summitacademy_FULL_2021_12_20__05_46_20_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\summitacademy_lor\summitacademy_lor_FULL_2021_12_20__05_46_20_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\summitacademy_warehouse\summitacademy_warehouse_FULL_2021_12_20__05_46_19_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tamua\tamua_FULL_2021_12_20__05_41_23_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tamua_lor\tamua_lor_FULL_2021_12_20__05_41_22_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tamua_reporting\tamua_reporting_FULL_2021_12_20__05_40_51_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tamua_warehouse\tamua_warehouse_FULL_2021_12_20__05_40_50_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\teslauniversity\teslauniversity_FULL_2021_12_20__05_40_47_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\teslauniversity_lor\teslauniversity_lor_FULL_2021_12_20__05_40_46_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\teslauniversity_warehouse\teslauniversity_warehouse_FULL_2021_12_20__05_40_46_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tps\tps_FULL_2021_12_20__05_40_40_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tps_lor\tps_lor_FULL_2021_12_20__05_40_39_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\tps_warehouse\tps_warehouse_FULL_2021_12_20__05_40_38_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\traversecity\traversecity_FULL_2021_12_20__05_39_22_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\traversecity_lor\traversecity_lor_FULL_2021_12_20__05_39_22_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\traversecity_reporting\traversecity_reporting_FULL_2021_12_20__05_39_10_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\traversecity_warehouse\traversecity_warehouse_FULL_2021_12_20__05_39_09_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\trinitypd\trinitypd_FULL_2021_12_20__05_06_57_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\trinitypd_lor\trinitypd_lor_FULL_2021_12_20__05_06_56_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\trinitypd_warehouse\trinitypd_warehouse_FULL_2021_12_20__05_06_56_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uindy\uindy_FULL_2021_12_20__05_05_54_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uindy_lor\uindy_lor_FULL_2021_12_20__05_05_53_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uindy_warehouse\uindy_warehouse_FULL_2021_12_20__05_05_52_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uitvirtual\uitvirtual_FULL_2021_12_20__05_05_06_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uitvirtual_lor\uitvirtual_lor_FULL_2021_12_20__05_05_05_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uitvirtual_reporting\uitvirtual_reporting_FULL_2021_12_20__05_04_51_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uitvirtual_warehouse\uitvirtual_warehouse_FULL_2021_12_20__05_04_51_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\unicep\unicep_FULL_2021_12_20__05_37_52_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\unicep_LOR\unicep_LOR_FULL_2021_12_20__05_37_52_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\unicep_Reporting\unicep_Reporting_FULL_2021_12_20__05_37_24_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\unicep_Warehouse\unicep_Warehouse_FULL_2021_12_20__05_37_24_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\urson\urson_FULL_2021_12_20__05_04_48_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\urson_lor\urson_lor_FULL_2021_12_20__05_04_47_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\urson_warehouse\urson_warehouse_FULL_2021_12_20__05_04_47_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\usasd\usasd_FULL_2021_12_20__05_37_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\usasd_lor\usasd_lor_FULL_2021_12_20__05_37_02_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\usasd_warehouse\usasd_warehouse_FULL_2021_12_20__05_37_01_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\uscoreppephetest\uscoreppephetest_FULL_2021_12_20__05_04_44_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uscoreppephetest_lor\uscoreppephetest_lor_FULL_2021_12_20__05_04_43_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uscoreppephetest_reporting\uscoreppephetest_reporting_FULL_2021_12_20__05_04_41_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uscoreppephetest_warehouse\uscoreppephetest_warehouse_FULL_2021_12_20__05_04_40_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uvl\uvl_FULL_2021_12_20__05_04_18_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uvl_lor\uvl_lor_FULL_2021_12_20__05_04_17_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\uvl_warehouse\uvl_warehouse_FULL_2021_12_20__05_04_17_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\vcat\vcat_FULL_2021_12_20__05_03_04_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\vcat_lor\vcat_lor_FULL_2021_12_20__05_03_03_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\waldenmc\waldenmc_FULL_2021_12_20__05_02_56_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\waldenmc_lor\waldenmc_lor_FULL_2021_12_20__05_02_55_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\waldenmc_reporting\waldenmc_reporting_FULL_2021_12_20__05_02_51_US04APSQLH202.bak'),
('V:\SQL_Backups\FULL\williamwoods\williamwoods_FULL_2021_12_20__05_36_32_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\williamwoods_lor\williamwoods_lor_FULL_2021_12_20__05_36_31_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\williamwoods_warehouse\williamwoods_warehouse_FULL_2021_12_20__05_36_31_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ytc\ytc_FULL_2021_12_20__05_08_04_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ytc_LOR\ytc_LOR_FULL_2021_12_20__05_08_03_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ytc_Reporting\ytc_Reporting_FULL_2021_12_20__05_02_56_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ytc_SIS\ytc_SIS_FULL_2021_12_20__05_02_54_US04APSQLH201.bak'),
('V:\SQL_Backups\FULL\ytc_Warehouse\ytc_Warehouse_FULL_2021_12_20__05_02_53_US04APSQLH201.bak'),



--RESTORE HEADERONLY FROM DISK = N'V:\SQL_Backups\Temp\CFE\polestarpilates_FULL_2018_5_6__08_42_54_US04PSQL001D.bak'
--restore filelistonly from disk = 'V:\SQL_Backups\Temp\CFE\polestarpilates_FULL_2018_5_6__08_42_54_US04PSQL001D.bak'

-------------------------------------------------------------------------
('')--intenitional blank entry
declare @BackupPath varchar(525)
declare @dbname varchar(525)
declare @datapath varchar(525)
declare @logpath varchar(525)
declare @BackupType int
create table #Results (script varchar(max))
set @datapath = 'E:\SQL_Data\'
set @logpath = 'F:\SQL_Logs\'

--set @datapath = 'N:\MP_data_1\SQL_Data\'
--set @logpath = 'N:\MP_logs_1\SQL_Logs\'



WHILE (Select count(*) from #BackupPaths)>0
BEGIN
set @BackupPath = (select top 1 path from #BackupPaths)
IF LEN(@BackupPath)=0 BREAK
create table #tmp
(LogicalName nvarchar(128) ,PhysicalName nvarchar(260) ,Type char(1) ,FileGroupName nvarchar(128) ,Size numeric(20,0) ,MaxSize numeric(20,0),
Fileid bigint,CreateLSN numeric(25,0),DropLSN numeric(25, 0),UniqueID uniqueidentifier,ReadOnlyLSN numeric(25,0),ReadWriteLSN numeric(25,0),
BackupSizeInBytes bigint,SourceBlocSize int,FileGroupId int,LogGroupGUID uniqueidentifier,DifferentialBaseLSN numeric(25,0),
DifferentialBaseGUID uniqueidentifier,IsReadOnly bit,IsPresent bit,TDEThumbprint char(1),snapshoturl nvarchar(128))

IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '12%')--SQL2014
--drop columns not found in SQL 2008
	BEGIN
	ALTER TABLE #tmp drop COLUMN snapshoturl
	END

insert #tmp
EXEC ('restore filelistonly from disk = ''' + @BackupPath + '''')

--select * from #tmp
--Header table
create table #HeaderTable (BackupName  nvarchar(128),  BackupDescription  nvarchar(255) ,BackupType  smallint ,ExpirationDate  datetime ,
Compressed  bit ,Position  smallint ,DeviceType  tinyint ,UserName  nvarchar(128) ,ServerName  nvarchar(128) ,DatabaseName  nvarchar(128) ,
DatabaseVersion  int ,DatabaseCreationDate  datetime ,BackupSize  numeric(20,0) ,FirstLSN  numeric(25,0) ,LastLSN  numeric(25,0) ,
CheckpointLSN  numeric(25,0) ,DatabaseBackupLSN  numeric(25,0) ,BackupStartDate  datetime ,BackupFinishDate  datetime ,SortOrder  smallint ,
CodePage  smallint ,UnicodeLocaleId  int ,UnicodeComparisonStyle  int ,CompatibilityLevel  tinyint ,SoftwareVendorId  int ,SoftwareVersionMajor  int ,
SoftwareVersionMinor  int ,SoftwareVersionBuild  int ,MachineName  nvarchar(128) ,Flags  int ,BindingID  uniqueidentifier ,RecoveryForkID  uniqueidentifier ,
Collation  nvarchar(128) ,FamilyGUID  uniqueidentifier ,HasBulkLoggedData  bit ,IsSnapshot  bit ,IsReadOnly  bit ,IsSingleUser  bit ,HasBackupChecksums  bit ,
IsDamaged  bit ,BeginsLogChain  bit ,HasIncompleteMetaData  bit ,IsForceOffline  bit ,IsCopyOnly  bit ,FirstRecoveryForkID  uniqueidentifier ,
ForkPointLSN  numeric(25,0) NULL,RecoveryModel  nvarchar(60) ,DifferentialBaseLSN  numeric(25,0) NULL,DifferentialBaseGUID  uniqueidentifier ,
BackupTypeDescription  nvarchar(60) ,BackupSetGUID  uniqueidentifier NULL,CompressedBackupSize bigint NULL,	Containment	INT null,
KeyAlgorithm	nvarchar(60) null,EncryptorThumbprint	varbinary(20) null,EncryptorType nvarchar(60) null)

IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '11%')--SQL2012
--drop columns not found in SQL 2012
	BEGIN
	ALTER TABLE #HeaderTable drop COLUMN KeyAlgorithm
	ALTER TABLE #HeaderTable drop COLUMN EncryptorThumbprint
	ALTER TABLE #HeaderTable drop COLUMN EncryptorType
	END
IF EXISTS (SELECT * WHERE CONVERT(varchar(128), SERVERPROPERTY('ProductVersion')) LIKE '10%')--SQL2008
--drop columns not found in SQL 2008
	BEGIN
	ALTER TABLE #HeaderTable drop COLUMN KeyAlgorithm
	ALTER TABLE #HeaderTable drop COLUMN EncryptorThumbprint
	ALTER TABLE #HeaderTable drop COLUMN EncryptorType
	ALTER TABLE #HeaderTable drop COLUMN Containment
	END

INSERT INTO #HeaderTable 
EXEC('RESTORE HEADERONLY FROM DISK = N''' + @BackupPath+'''')
SET @dbname = (select DatabaseName from #HeaderTable)
SET @BackupType = (select BackupType from #HeaderTable)
print @dbname
print @BackupType

--Fulls
Declare @RestoreCMD varchar(max)
set @RestoreCMD = ''

SET @RestoreCMD = (select 'RESTORE DATABASE ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY
,MOVE N''' + t1.LogicalName+''' TO N'''+@datapath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'D' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'D'))

	delete from #tmp where type = 'D' AND fileid = (select min(fileid) from #tmp where type = 'D' AND @BackupType=1)

--Data Files - .mdf, .ndf
	 WHILE (Select count(*) from #tmp where type = 'D' AND @BackupType=1 )>0
	BEGIN

	set @RestoreCMD = @RestoreCMD + 
	(select '
,MOVE N''' + t1.LogicalName+''' TO N'''+@datapath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'D' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'D'))
 
	delete from #tmp where type = 'D' AND fileid = (select min(fileid) from #tmp where type = 'D' AND @BackupType=1)
	END
--MOD Files - _MOD
	 WHILE (Select count(*) from #tmp where type = 'S' AND @BackupType=1 )>0
	BEGIN

	set @RestoreCMD = @RestoreCMD + 
	(select '
,MOVE N''' + t1.LogicalName+''' TO N'''+@datapath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'S' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'S'))
 
	delete from #tmp where type = 'S' AND fileid = (select min(fileid) from #tmp where type = 'S' AND @BackupType=1)
	END
--Log Files - .ldf
	 WHILE (Select count(*) from #tmp where type = 'L' AND @BackupType=1)>0
	BEGIN

	set @RestoreCMD = @RestoreCMD + 
	(select '
,MOVE N''' + t1.LogicalName+''' TO N'''+@logpath+(RIGHT([PhysicalName],(CHARINDEX('\',REVERSE([PhysicalName]))-1)))+'''' 
	 from #tmp t1 where t1.type = 'L' AND @BackupType=1 AND t1.fileid = (select min(fileid) from #tmp where type = 'L'))
 
	delete from #tmp where type = 'L' AND fileid = (select min(fileid) from #tmp where type = 'L' AND @BackupType=1)
	END

IF (@BackupType=1)
	BEGIN
	insert into #Results
	Select @RestoreCMD
	END

--Diffs
insert into #Results
select 'RESTORE DATABASE ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY'
from #tmp t1 where t1.type = 'D' AND @BackupType=5 AND t1.fileid = 1

--Logs
insert into #Results
select 'RESTORE LOG ['+@dbname+'] FROM  DISK = N'''+ @BackupPath +''' WITH FILE = 1, STATS = 5, NORECOVERY'
from #tmp t1 where t1.type = 'D' AND @BackupType=2 AND t1.fileid = 1

drop table #tmp 
drop table #HeaderTable

Delete from #BackupPaths where path = @BackupPath
END

select * from #Results
drop table #Results
drop table #BackupPaths
