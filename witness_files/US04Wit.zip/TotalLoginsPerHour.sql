USE k12
SELECT DB_NAME(), YEAR(UL.AttemptDate) AS 'Year',MONTH(UL.AttemptDate) AS 'Month', DAY(UL.AttemptDate) AS 'Day', DATEPART(hh, UL.AttemptDate) AS 'Hour', COUNT(*) AS Total
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0 AND UL.AttemptDate >= '09/03/2019 06:55:00' AND UL.AttemptDate <= '09/15/2019 06:55:00' 
AND UL.UserName not in ('D2LSupport', 'd2lmonitor')
GROUP BY YEAR(UL.AttemptDate),MONTH(UL.AttemptDate), DAY(UL.AttemptDate), DATEPART(hh, UL.AttemptDate)
--GROUP BY OO.OrgShortName, DATEPART(hh, UL.AttemptDate)
ORDER BY YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate), DATEPART(hh, UL.AttemptDate)


--SELECT last("value") AS "Data Size" FROM "telegraf"."sqlserver_performance" WHERE ("counter" = 'Data File(s) Size (KB)' AND "sql_instance" =~ /^$Host$/) 




