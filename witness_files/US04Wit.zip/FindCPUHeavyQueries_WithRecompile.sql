/*
--recompile all sprocs tide to table
USE AdventureWorks2012;  
GO  
EXEC sp_recompile N'Sales.Customer';  
GO  


https://www.mssqltips.com/sqlservertip/4714/different-ways-to-flush-or-clear-sql-server-cache/
Clear All Cache

DBCC FLUSHPROCINDB(DatabaseID)

DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE (0x05000B009794241AF05BD9B60402000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x05000B009794241AF05BD9B60402000001000000000000000000000000000000000000000000000000000000)
0x05000B009794241AF05BD9B60402000001000000000000000000000000000000000000000000000000000000

Use usgq; 
Declare @dbid int = db_ID() 
--select @dbid
DBCC FLUSHPROCINDB (@dbId)



SELECT  deqs.query_hash ,
deqs.query_plan_hash ,
deqp.query_plan ,
deqs.sql_handle,
dest.text
FROM    sys.dm_exec_query_stats AS deqs
CROSS APPLY sys.dm_exec_query_plan(deqs.plan_handle) AS deqp
CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS dest
WHERE   deqs.query_hash = 0x512B70193BAC0F22;

0x020000006A5C8A0B5273AA5136012D3DFB0DCEDC148915FC0000000000000000000000000000000000000000


--Clear cache for entire database
--select name, database_ID from sys.databases
--where name = 'ilearnnyc'
--DBCC FLUSHPROCINDB (85)

DBCC FREEPROCCACHE (0x06000700DEB98222705EAF2ECC01000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x06000700DEB98222605FDFFBC701000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x06000700DEB98222605FDFFBC701000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x050007007083204DB092477BC601000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x05000A00028F8321E0AE259CBF02000001000000000000000000000000000000000000000000000000000000)

DBCC FREEPROCCACHE (0x05001700259C71511086274BC501000001000000000000000000000000000000000000000000000000000000)
DBCC FREEPROCCACHE (0x0500170034E01E1830D961D4C401000001000000000000000000000000000000000000000000000000000000)
*/
WITH SystemIO AS
(
      SELECT 
            SUM(total_worker_time) AS [totalSystemCPU],
            SUM(execution_count) AS [totalExecutionsInCache]
      FROM sys.dm_exec_query_stats
),
TopTwenty AS
(
      SELECT TOP 20 
            [Row Number] = ROW_NUMBER() OVER (ORDER BY total_worker_time DESC),
            [Query Text] = CASE 
                  WHEN [sql_handle] IS NULL THEN ' '
                  ELSE (SUBSTRING(ST.TEXT,(QS.statement_start_offset + 2) / 2,
                        (CASE 
                              WHEN QS.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX),ST.text)) * 2
                              ELSE QS.statement_end_offset
                              END - QS.statement_start_offset) / 2))
                  END,
            [Execution Count] = execution_count,
            [Total CPU] = total_worker_time,
            [DB Name] = DB_NAME(ST.dbid),
            [Object Name] = OBJECT_NAME(ST.objectid, ST.dbid),
            [SQL Handle] = [sql_handle],
            [Plan Handle] = [plan_handle]
      FROM sys.dm_exec_query_stats QS
      CROSS APPLY sys.dm_exec_sql_text ([sql_handle]) ST
      WHERE total_worker_time > 0
	 -- and OBJECT_NAME(ST.objectid, ST.dbid) like '%s_GRADE_OBJECT_GRADES_GetAllForExport_Organization%'
      ORDER BY [Row Number] ASC 
)
SELECT [totalSystemCPU], [totalExecutionsInCache],
      T20.[Row Number], T20.[Query Text], T20.[Execution Count], T20.[Total CPU], 
      T20.[DB Name], T20.[Object Name], T20.[SQL Handle],
      [Average CPU] = T20.[Total CPU] / (T20.[Execution Count] + 0.0),
      [System Percentage] = 100.0 * T20.[Total CPU] / ([totalSystemCPU]+0.0),
      [Cumulative Percentage] = 100.0 * SUM(T20_secondary.[Total CPU]) / ([totalSystemCPU]+0.0),
      [Max CPU] = MAX(T20_secondary.[Total CPU]),
      T20.[Plan Handle],
	  'DBCC FREEPROCCACHE ('+CONVERT(VARCHAR(1000), T20.[plan handle], 1)+')' AS RecompileScript
FROM TopTwenty T20
JOIN TopTwenty T20_secondary
      ON T20.[Row Number] >= T20_secondary.[Row Number]
CROSS JOIN SystemIO SIO
GROUP BY [totalSystemCPU], [totalExecutionsInCache], 
      T20.[Row Number],
      T20.[Query Text],
      T20.[Execution Count],
      T20.[Total CPU],
      T20.[DB Name],
      T20.[Object Name],
      T20.[SQL Handle],
      T20.[Plan Handle]

/*
SELECT TOP 20 
            [Row Number] = ROW_NUMBER() OVER (ORDER BY total_worker_time DESC),
            [Query Text] = CASE 
                  WHEN [sql_handle] IS NULL THEN ' '
                  ELSE (SUBSTRING(ST.TEXT,(QS.statement_start_offset + 2) / 2,
                        (CASE 
                              WHEN QS.statement_end_offset = -1 THEN LEN(CONVERT(NVARCHAR(MAX),ST.text)) * 2
                              ELSE QS.statement_end_offset
                              END - QS.statement_start_offset) / 2))
                  END,
            [Execution Count] = execution_count,
            [Total CPU] = total_worker_time,
            [DB Name] = DB_NAME(ST.dbid),
            [Object Name] = OBJECT_NAME(ST.objectid, ST.dbid),
            [SQL Handle] = [sql_handle],
            [Plan Handle] = [plan_handle]
      FROM sys.dm_exec_query_stats QS
      CROSS APPLY sys.dm_exec_sql_text ([sql_handle]) ST
      WHERE total_worker_time > 0
	  and OBJECT_NAME(ST.objectid, ST.dbid) like '%s_GRADE_OBJECT_GRADES_GetAllForExport_Organization%'
      ORDER BY [Row Number] ASC 

*/
