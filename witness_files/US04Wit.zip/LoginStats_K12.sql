select TT.[Year], TT.[Month], TT.[Day], COUNT(*) AS Total_Unique
from (SELECT UL.UserId, YEAR(UL.AttemptDate)  AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate)AS [Day], COUNT(*) AS Total
    FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
        INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
        ON UL.OrgId = OO.OrgId
    WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
        --AND UL.AttemptDate >= cast (getdate() AS date) --Today only
        AND UL.AttemptDate between '2020-08-23' AND '2020-09-30'  -- Specific date range
    GROUP BY UL.UserId,YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate)) TT
group by TT.[Year], TT.[Month], TT.[Day]
ORDER BY 1,2,3 desc

select TT.[Year], TT.[Month], TT.[Day], COUNT(*) AS Total_Unique
from (SELECT UL.UserId, YEAR(UL.AttemptDate)  AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate)AS [Day], COUNT(*) AS Total
    FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
        INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
        ON UL.OrgId = OO.OrgId
    WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
        --AND UL.AttemptDate >= cast (getdate() AS date) --Today only
        AND UL.AttemptDate between '2019-08-25' AND '2019-08-31'  -- Specific date range
    GROUP BY UL.UserId,YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate)) TT
group by TT.[Year], TT.[Month], TT.[Day]
ORDER BY 1,2,3 desc