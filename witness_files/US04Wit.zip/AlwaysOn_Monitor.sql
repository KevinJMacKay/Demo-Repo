

select db_name(database_id),is_primary_replica,synchronization_state_desc,secondary_lag_seconds,log_send_queue_size, 
log_send_rate, redo_queue_size, redo_rate,last_sent_time,last_received_time,
last_hardened_time,last_redone_time,last_commit_time
from sys.dm_hadr_database_replica_states 


select session_id, command, blocking_session_id, wait_time, wait_type, wait_resource   
from sys.dm_exec_requests where command = 'DB STARTUP' 