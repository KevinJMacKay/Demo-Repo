--https://www.sqlshack.com/max-worker-threads-for-sql-server-always-on-availability-group-databases/

--Step 1: Create an intermittent table to fetch all records from the system_health event session

--In this step, we want to pull all event session information into a dataimport table. We need to specify the location of the log folder containing these files.
drop table dataimport
SELECT [object_name], 
       CAST(event_data AS XML) AS c1
INTO dataimport
FROM sys.fn_xe_file_target_read_file('C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Log\system_health*.xel', NULL, NULL, NULL);
GO

--Step 2: Create another table to filter the records for the sp_server_diagnostics output

--In this step, we will filter the data from table 1 for the sp_server_diagnostics result and insert filtered data into another table ServerDiagnosticsdata.

SELECT c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') AS SdComponent, 
       c1
INTO ServerDiagnosticsdata
FROM dataimport
WHERE object_name = 'sp_server_diagnostics_component_result';

--Step 3: Filter the records for the QUERY_PROCESSING object

--In SQL Server, extended event session capture worker thread information in an XML format. In this step, we create a table to hold the XML data and insert the data into it for the QUERY_PROCESSING object.

CREATE TABLE [dbo].[QryProcessingOutput]
([c1] [XML] NULL
)
ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
GO
INSERT INTO QryProcessingOutput(c1)
       SELECT c1 AS snodes
       FROM ServerDiagnosticsdata
       WHERE SdComponent = 'QUERY_PROCESSING';

--Step 4: Retrieve the information from the ServerDiagnosticsdata table for the max worker threads
--We have the data in the ServerDiagnosticsdata table but the data is in the XML format. We cannot directly fetch the required data. We need to fetch a particular event and convert it into an appropriate data type.
--The extended event captures the information in the XML format as shown below.
--XML view of extended event
--Execute the following code to get these required columns data and insert it into a WorkerThreadData table.

SELECT c1.value('(./event/@timestamp)[1]', 'datetime') AS utctimestamp, 
       DATEADD(hh, +5.30, c1.value('(./event/@timestamp)[1]', 'datetime')) AS [timestamp], 
       c1.value('(event/data[@name="component"]/text)[1]', 'varchar(100)') AS [component_name], 
       c1.value('(event/data[@name="state"]/text)[1]', 'varchar(100)') AS [component_state], 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@maxWorkers)[1]', 'int') AS maxworkers, 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@workersCreated)[1]', 'int') AS workerscreated, 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@workersIdle)[1]', 'int') AS workersIdle, 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@tasksCompletedWithinInterval)[1]', 'int') AS tasksCompletedWithinInterval, 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@oldestPendingTaskWaitingTime)[1]', 'bigint') AS oldestPendingTaskWaitingTime, 
       c1.value('(./event//data[@name="data"]/value/queryProcessing/@pendingTasks)[1]', 'int') AS pendingTasks
INTO [WorkerThreadData]
FROM ServerDiagnosticsdata;

--Step 5: Retrieve the information from the ServerDiagnosticsdata table for the SQL Server Always On Availability Group max worker threads

SELECT  [utctimestamp]
      ,[timestamp]
      ,[component_name]
      ,[component_state]
      ,[maxworkers]
      ,[workerscreated]
      ,[workersIdle]
      ,[tasksCompletedWithinInterval]
      ,[oldestPendingTaskWaitingTime]
      ,[pendingTasks]
        FROM  [WorkerThreadData]
order by [timestamp]  desc


/*
Extended event data

Details of the output columns returned from the extended event session
Component_State: It gives you information that the worker thread is right, or it is about to utilized thoroughly

MaxWorkers: Max worker threads value depends upon the number of processors as defined in the beginning ting of the article. In my example, I have eight processors; therefore, it gives maximum worker threads 576

Workercreated: this number shows the worker thread created by the application

oldestPendingTaskWaitingTime: if there is any pending task and it is holding the worker threads, it shows the oldest pending task counts. 
Ideally, its value should be zero

Pending Tasks: It also shows the pending tasks counts, its value also should be zero for a healthy environment

*/