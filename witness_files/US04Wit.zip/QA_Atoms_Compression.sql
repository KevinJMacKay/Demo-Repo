DBCC SQLPERF(LOGSPACE);
GO

--sp_whoisactive

--1408322	0.1534983

--minnstateqaB
--database 5950272.06 MB
--freespace 36608.30 MB

--QA_Atoms Data - 422,388.531 MB
-- index 294,035.555 MB

--Tlog
--tempdb	99999.99	0.4458829
--minnstateqaB 213922.1	0.03676134
--minnstateqaB	338122.1	99.97917

---------------------------------------------

--- TBR_TEST/US04ATSQLN201/tbr_test
--- minnstateqa/US04ATSQLN202/minnstateqaA
--- k12TEST/US04ATSQLN301/k12testA
--- externalsupportca3/US04CPSQLN202/externalsupportca3


--US04ATSQLN201 --tbr_test
--QA_Atoms Data 501,997.992 MB
--QA_Atoms index 277,272.469 MB

--Database Name	Log Size (MB)	Log Space Used (%)
--tempdb	99999.99	1.50468
--tbr_test	43782.24	0.07973588

--US04CPSQLN202
--tempdb	99999.99	3.969602
--externalsupportca3	50112.68	0.03119532

--US04ATSQLN301
--K12_test - index 212,018.227 MB
--data 335,462.453 MB
--Database Name	Log Size (MB)	Log Space Used (%)
--k12testA	254296.6	1.211565



