-- Login: Shibboleth_SQLUser
CREATE LOGIN [Shibboleth_SQLUser] WITH PASSWORD = 0x0200981BFA0A2AA6D8BFDF371663DC765A1930A7B707E0D1EEC6106C82FE44230F9CE4C32D22994CAE05930EE2778EDBC9F13B867C825A6E514A946A955F5119149D24BE45E0 HASHED, SID = 0xD52AEC92E1D22541906AA0D4B542736F, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
-- Login: regis_test_SQLUser
CREATE LOGIN [regis_test_SQLUser] WITH PASSWORD = 0x020064466314CD739AE97A635B3CAC45911AF2E5933D8B1D332E73B294368B89F0B5DCC5C2FF611972103225080997959A80E48081B87F7D5722D7C6B1A3E88D085E6DD9A2F1 HASHED, SID = 0xA277CA09A99E1C409C7B57B362C0A810, DEFAULT_DATABASE = [master], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
 
RESTORE DATABASE [IPAS_regis_test] FROM  DISK = N'Z:\SQL_Backups\Temp\IPAS_regis_test\IPAS_regis_test_FULL_2020_3_16__05_18_18_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'shibboleth' TO N'E:\SQL_Data\IPAS_regis_test.mdf'  ,MOVE N'shibboleth_log' TO N'E:\SQL_Logs\IPAS_regis_test_Log.ldf'
RESTORE DATABASE [regis_test] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test\regis_test_FULL_2020_3_16__05_04_07_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'devbuild_zeus_0_base__build_main' TO N'E:\SQL_Data\regis_test.mdf'  ,MOVE N'devbuild_zeus_0_base__build_main_1' TO N'E:\SQL_Data\regis_test_Data1.ndf'  ,MOVE N'devbuild_zeus_0_base__build_main_log' TO N'E:\SQL_Logs\regis_test_Log.ldf'
RESTORE DATABASE [regis_test_LOR] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_LOR\regis_test_LOR_FULL_2020_3_16__05_04_06_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'emptydatabase' TO N'E:\SQL_Data\regis_test_LOR.mdf'  ,MOVE N'emptydatabase_1' TO N'E:\SQL_Data\regis_test_LOR_Data1.ndf'  ,MOVE N'emptydatabase_log' TO N'E:\SQL_Logs\regis_test_LOR_Log.ldf'
RESTORE DATABASE [regis_test_Reporting] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_Reporting\regis_test_Reporting_FULL_2020_3_16__05_02_36_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'devbuild_zeus_0_base__build_reporting' TO N'E:\SQL_Data\regis_test_Reporting.mdf'  ,MOVE N'devbuild_zeus_0_base__build_reporting_1' TO N'E:\SQL_Data\regis_test_Reporting_Data1.ndf'  ,MOVE N'devbuild_zeus_0_base__build_reporting_log' TO N'E:\SQL_Logs\regis_test_Reporting_Log.ldf'
RESTORE DATABASE [regis_test_SIS] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_SIS\regis_test_SIS_FULL_2020_3_16__05_02_34_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'emptydatabase' TO N'E:\SQL_Data\regis_test_SIS.mdf'  ,MOVE N'emptydatabase_1' TO N'E:\SQL_Data\regis_test_SIS_Data1.ndf'  ,MOVE N'emptydatabase_log' TO N'E:\SQL_Logs\regis_test_SIS_Log.ldf'
RESTORE DATABASE [regis_test_Warehouse] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_Warehouse\regis_test_Warehouse_FULL_2020_3_16__05_02_33_US04PSQL001Z.bak' WITH FILE = 1, STATS = 5, NORECOVERY  ,MOVE N'devbuild_Hercules_build_aw_warehouse' TO N'E:\SQL_Data\regis_test_Warehouse.mdf'  ,MOVE N'Regis_test_Warehouse_Data_2' TO N'E:\SQL_Data\regis_test_Warehouse_Data1.ndf'  ,MOVE N'Regis_test_Warehouse_Data_1' TO N'E:\SQL_Data\regis_test_Warehouse_Data2.ndf'  ,MOVE N'devbuild_Hercules_build_aw_warehouse_log' TO N'E:\SQL_Logs\regis_test_Warehouse_Log.ldf'


RESTORE DATABASE [IPAS_regis_test] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\IPAS_regis_test_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE [regis_test] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\regis_test_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE [regis_test_LOR] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\regis_test_LOR_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE [regis_test_Reporting] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\regis_test_Reporting_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE [regis_test_SIS] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\regis_test_SIS_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
RESTORE DATABASE [regis_test_Warehouse] FROM  DISK = N'Z:\SQL_Backups\Temp\regis_test_diffs\regis_test_Warehouse_backup_2020_03_18.bak' WITH FILE = 1, STATS = 5, NORECOVERY
--40sec

/*

update cname to: us04tgrp13.aue1.int.d2l.

RESTORE DATABASE [IPAS_regis_test]
RESTORE DATABASE [regis_test] 
RESTORE DATABASE [regis_test_LOR]   
RESTORE DATABASE [regis_test_Reporting] 
RESTORE DATABASE [regis_test_SIS]  
RESTORE DATABASE [regis_test_Warehouse]
*/

