--ALTER LOGIN [regis_test_SQLUser] DISABLE
--GO


use [IPAS_regis_test];
GO
use [master];
GO
BACKUP DATABASE [IPAS_regis_test] TO  DISK = N'Z:\SQL_Backups\IPAS_regis_test_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,    STATS = 10
GO
use [regis_test];
GO
use [master];
GO
BACKUP DATABASE [regis_test] TO  DISK = N'Z:\SQL_Backups\regis_test_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,    STATS = 10
GO
use [regis_test_LOR];
GO
use [master];
GO
BACKUP DATABASE [regis_test_LOR] TO  DISK = N'Z:\SQL_Backups\regis_test_LOR_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  STATS = 10
GO
use [regis_test_Reporting];
GO
use [master];
GO
BACKUP DATABASE [regis_test_Reporting] TO  DISK = N'Z:\SQL_Backups\regis_test_Reporting_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,   STATS = 10
GO
use [regis_test_SIS];
GO
use [master];
GO
BACKUP DATABASE [regis_test_SIS] TO  DISK = N'Z:\SQL_Backups\regis_test_SIS_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,    STATS = 10
GO
use [regis_test_Warehouse];
GO
use [master];
GO
BACKUP DATABASE [regis_test_Warehouse] TO  DISK = N'Z:\SQL_Backups\regis_test_Warehouse_backup_2020_03_18.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  STATS = 10
