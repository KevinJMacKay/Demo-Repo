Set nocount ON
Declare @SubnetA_OrigServer AS varchar(20)
Declare @SubnetB_OrigServer AS varchar(20)
Declare @SubnetA_NewServer AS varchar(20)
Declare @SubnetB_NewServer AS varchar(20)
Declare @DataDrive AS varchar(20)
Declare @LogDrive AS varchar(20)
SET @SubnetA_OrigServer = 'US04PSQL001W'
SET @SubnetB_OrigServer = 'US04PSQL001X'
SET @SubnetA_NewServer = 'US04PSQL001M'
SET @SubnetB_NewServer = 'US04PSQL001N' 
--SET @DataDrive = 'E:\SQL_Data'
--SET @LogDrive = 'F:\SQL_Logs'

--Expand AG to add additional replica
--@@@@@@@NOTE - Run LOG SHRINK script before AddAGReplicas.ps1 - Else backups will take a long time
--Run from existing replica SQL servers. Confirm \\...\Temp share exists
Select '******* Run LOG SHRINK script before AddAGReplicas.ps1'
select '.\AddAGReplicas.ps1 -NewReplicas '+ @SubnetA_NewServer+','+@SubnetB_NewServer +' -Listener "'+agl.[dns_name]+'" -DIFF' AS AddAGReplicas
from sys.availability_groups ag
INNER JOIN sys.availability_group_listeners agl
ON ag.group_id = agl.group_id
order by ag.name

--Check if users exist on New replica
Select ':connect '+@SubnetA_OrigServer AS SQL_Logins, '1'AS A
UNION
Select 'EXEC [dbo].[sp_help_revlogin]' AS SQL_Logins, '2'AS A
UNION
Select ':connect '+@SubnetA_NewServer AS SQL_Logins, '3'AS A
UNION
Select ':connect '+@SubnetB_NewServer AS SQL_Logins, '4'AS A
order by A

select '.\SQLUserCheck.ps1 -AGs "'+[name]+'" -DestinationServer '+ @SubnetA_NewServer+'' AS SQLUserCheck_1
from sys.availability_groups 
select '.\SQLUserCheck.ps1 -AGs "'+[name]+'" -DestinationServer '+ @SubnetB_NewServer+'' AS SQLUserCheck_2
from sys.availability_groups 

--Check for IP's used by each AG. Run on Any replica
--subnet IP's may change based on AWS Region.
Select 'Before Failovers Reassign IPs'
select ag.[name],'test-connection '+agl.[dns_name] + ' -count 1',aglip.[ip_address],aglip.state_desc,@SubnetB_OrigServer AS MoveIPFrom,  @SubnetB_NewServer AS MoveIPTo
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetA_OrigServer
UNION
select ag.[name],'test-connection '+agl.[dns_name] + ' -count 1',aglip.[ip_address],aglip.state_desc,@SubnetA_OrigServer AS MoveIPFrom,  @SubnetA_NewServer AS MoveIPTo
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetB_OrigServer
order by ag.[name] asc

--Update AG Properties
select ':connect '+primary_replica+'
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_OrigServer+''' WITH (FAILOVER_MODE = MANUAL)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_OrigServer+''' WITH (AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT) 
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_NewServer+''' WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_NewServer+''' WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_NewServer+''' WITH (FAILOVER_MODE = AUTOMATIC)
GO' 
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetA_OrigServer
UNION
select ':connect '+primary_replica+'
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_OrigServer+''' WITH (FAILOVER_MODE = MANUAL)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_OrigServer+''' WITH (AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT) 
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_NewServer+''' WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_NewServer+''' WITH (AVAILABILITY_MODE = SYNCHRONOUS_COMMIT)
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_NewServer+''' WITH (FAILOVER_MODE = AUTOMATIC)
GO'
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetB_OrigServer


Select '******* Update DBInfo *******'
Select '*******  Create Change Ticket *********','127 - DBA - Update global-dbinfo-repo'

--Schedule failovers - Run from Witness 
--*******  Create Change Ticket *********
Select '*******  Create Change Ticket *********','136 - DBA - Add failover scheduled task'
select 'Invoke-Expression "C:\DBA_Scheduled_Tasks\failoverAG_wDNS.ps1 -AG ""'+ag.[name]+'"" -DestinationServer '+ @SubnetA_NewServer+'"' 
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetB_OrigServer
UNION
select 'Invoke-Expression "C:\DBA_Scheduled_Tasks\failoverAG_wDNS.ps1 -AG ""'+ag.[name]+'"" -DestinationServer '+ @SubnetB_NewServer+'"' 
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetA_OrigServer

--In case...
--select '.\FlushDNS_byAG.ps1 -AGs "'+[dns_name]+'"' from sys.availability_group_listeners

--After failovers
Select 'After Failovers Reassign IPs','*******  Create Change Ticket *********','110 - DBA -  [Remove Replicas / Databases]'
select ag.[name],'test-connection '+agl.[dns_name] + ' -count 1',aglip.[ip_address],aglip.state_desc,@SubnetB_OrigServer AS MoveIPFrom,  @SubnetB_NewServer AS MoveIPTo
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetA_NewServer
UNION
select ag.[name],'test-connection '+agl.[dns_name] + ' -count 1',aglip.[ip_address],aglip.state_desc,@SubnetA_OrigServer AS MoveIPFrom,  @SubnetA_NewServer AS MoveIPTo
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetB_NewServer
order by ag.[name] asc

--Remove Old Replicas
select ':connect '+primary_replica AS RunOn,'ALTER AVAILABILITY GROUP ['+ag.[name]+'] REMOVE REPLICA ON '''+@SubnetA_OrigServer+''';' AS RemoveOldReplicas
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
UNION
select ':connect '+primary_replica AS RunOn,'ALTER AVAILABILITY GROUP ['+ag.[name]+'] REMOVE REPLICA ON '''+@SubnetB_OrigServer+''';' AS RemoveOldReplicas
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id

--Final Update of AG Properties
select ':connect '+primary_replica +'
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetA_NewServer+''' WITH (FAILOVER_MODE = AUTOMATIC)' AS SetToAutomatic
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetB_NewServer
UNION
select ':connect '+primary_replica +'
 ALTER AVAILABILITY GROUP ['+ag.[name]+'] MODIFY REPLICA ON N'''+@SubnetB_NewServer+''' WITH (FAILOVER_MODE = AUTOMATIC)' AS SetToAutomatic
from sys.availability_groups ag
inner join sys.availability_group_listeners agl
on ag.group_id = agl.group_id
inner join sys.availability_group_listener_ip_addresses aglip
on aglip.listener_id = agl.listener_id
inner join sys.dm_hadr_availability_group_states agstates
on ag.group_id = agstates.group_id
where aglip.state_desc = 'OFFLINE' AND agstates.primary_replica = @SubnetA_NewServer

--Drop databases on old servers
Select 'select ''DROP DATABASE [''+name+'']'' from sys.databases 
where database_id > 4 AND state_desc <> ''ONLINE''
order by name '

