IF (OBJECT_ID('tempdb..#count_results') IS NOT NULL)
drop table #count_results;
DECLARE @Starttime varchar (100)
DECLARE @Endtime varchar (100)
SET @Starttime = '2021-02-02 19:06'
SET @Endtime = '2021-02-02 20:26'
--*******************************************************************************************
	SELECT  [dd hh:mm:ss.mss],[collection_time],[session_id],[sql_text],[login_name],[wait_info]
	,[blocking_session_id],[tran_log_writes],[CPU],[tempdb_allocations],[tempdb_current],[reads]
	,[writes],[physical_reads],[query_plan],[used_memory],[status],[tran_start_time],[open_tran_count]
	,[percent_complete],[host_name],[database_name],[program_name],[start_time],[login_time],[request_id]
	  FROM [SQL_Trace].[dbo].[WhoIsActive]
	  WHERE 1=1
	  AND collection_time between @Starttime AND @Endtime
	  --AND login_name not in ('NT AUTHORITY\SYSTEM')
	  --AND login_name not in ('AUE1\aue1_SQL_Agent','AUE1\AUE1TaskAdmin')
	  --AND login_name ='PROE_SQLUser'
	  AND session_id = 1565
	  --AND CAST([sql_text] as nvarchar (max)) like '%DS_COMPETENCY_LOB_ACTIVITY%'
	  order by 2,1 desc
  --*******************************************************************************************
	SELECT
	count (CAST([sql_text] as nvarchar (max))) as [Query_Count],
	CAST([sql_text] as nvarchar (max)) as Query,
	SUM(cast(replace(replace([CPU], ' ', ''), ',', '') as int)) AS CPU,
	SUM(cast(replace(replace([reads], ' ', ''), ',', '') as int)) AS reads,
	[database_name],
	[start_time]
	INTO #count_results
	FROM [SQL_Trace].[dbo].[WhoIsActive]
	WHERE 1=1
	AND collection_time between @Starttime AND @Endtime
	  AND login_name not in ('NT AUTHORITY\SYSTEM')
	  AND login_name not in ('AUE1\aue1_SQL_Agent','AUE1\AUE1TaskAdmin')
	Group by CAST([sql_text] as nvarchar (max)),[database_name],Start_time
--***********************************************************************************************
	select top 10
	count(Query) as [Query_Count],
	Query,
	SUM(cpu) as cpu,
	SUM(reads) as reads,
	[database_name]
	from #count_results
	group by query,database_name
	order by 1 desc
	/*
	select *
	from #count_results
	order by 1 desc
	*/
--***********************************************************************************************
	SELECT AVG([CPUTimeAS%]),[Database] as [CPU_Average]
	FROM [SQL_Trace].[dbo].[CPU_Monitor]
	where collection_time between @Starttime AND @Endtime
	group by [Database]
	order by 1 desc
--***********************************************************************************************
	SELECT
	Count([wait_info]) cnt,
	SUBSTRING([wait_info], CHARINDEX(')', [wait_info]) + 1, LEN([wait_info]))wait_type,
	[database_name]
	FROM [SQL_Trace].[dbo].[WhoIsActive]
	WHERE 1=1
	AND collection_time between @Starttime AND @Endtime
	  AND login_name not in ('NT AUTHORITY\SYSTEM')
	  AND login_name not in ('AUE1\aue1_SQL_Agent','AUE1\AUE1TaskAdmin')
	group by SUBSTRING([wait_info], CHARINDEX(')', [wait_info]) + 1, LEN([wait_info])),[database_name]
	order by 1 desc


  


