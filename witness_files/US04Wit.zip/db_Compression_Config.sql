-- STEP 1: ADD/UPDATE JOBS FOR INDEX REBUILDS --

use master;
GO

-- Schedule index rebuild job using extended properties

DECLARE @DbName NVARCHAR(MAX)
DECLARE @RebuildId INT
DECLARE @IndexRebuilds TABLE
(
	Id INT IDENTITY PRIMARY KEY,
	TableName NVARCHAR(MAX),
	IndexName NVARCHAR(MAX),
	TargetLevel NVARCHAR(MAX)
)
INSERT INTO @IndexRebuilds (TableName, IndexName, TargetLevel)
VALUES
	('QA_ATOMS', 'PK_QA_ATOMS', 'PAGE'),
	('QA_ATOMS', 'IX_QA_ATOMS_Temp_Ver_Atom', 'PAGE')

DECLARE db_cursor CURSOR FOR
SELECT name
FROM sys.databases 
WHERE database_id > 4
AND Name = 'minnstateqaA'

OPEN db_cursor
FETCH NEXT FROM db_cursor INTO @DbName  

DECLARE @SQL NVARCHAR(MAX)

WHILE @@FETCH_STATUS = 0  
BEGIN
	DECLARE ix_cursor CURSOR FOR
	SELECT Id FROM @IndexRebuilds

	OPEN ix_cursor
	FETCH NEXT FROM ix_cursor INTO @RebuildId

	DECLARE @TableName NVARCHAR(MAX)
	DECLARE @IndexName NVARCHAR(MAX)
	DECLARE @TargetLevel NVARCHAR(MAX)

	WHILE @@FETCH_STATUS = 0  
	BEGIN
		SELECT
			@TableName = TableName,
			@IndexName = IndexName,
			@TargetLevel = TargetLevel
		FROM @IndexRebuilds
		WHERE Id = @RebuildId

		SET @SQL =
		'
		USE ' + QUOTENAME(@DbName) + ';
		IF(
			OBJECT_ID (N''' + @TableName + ''', N''U'') IS NOT NULL
		)
		BEGIN
			IF NOT EXISTS (
				SELECT *
				FROM sys.extended_properties EP
				INNER JOIN sys.objects OB
					ON OB.object_id = EP.major_id
				INNER JOIN sys.indexes IX
					ON IX.index_id = EP.minor_id
					AND IX.object_id = OB.object_id
				WHERE
					EP.[name] = N''Target Compression''
					AND OB.[name] = N''' + @TableName + '''
					AND IX.[name] = N''' + @IndexName + '''
			)
			BEGIN
				PRINT DB_NAME()
				EXEC sp_addextendedproperty
					@name = N''Target Compression'',
					@value = ''' + @TargetLevel + ''',
					@level0type = N''Schema'', @level0name = ''dbo'',
					@level1type = N''Table'',  @level1name = ''' + @TableName + ''',
					@level2type = N''Index'', @level2name = ''' + @IndexName + ''';
			END
			ELSE
			BEGIN
				PRINT DB_NAME()
				EXEC sp_updateextendedproperty
					@name = N''Target Compression'',
					@value = ''' + @TargetLevel + ''',
					@level0type = N''Schema'', @level0name = ''dbo'',
					@level1type = N''Table'',  @level1name = ''' + @TableName + ''',
					@level2type = N''Index'', @level2name = ''' + @IndexName + ''';
			END
		END
		'
		EXECUTE(@SQL)

		FETCH NEXT FROM ix_cursor INTO @RebuildId
	END

	CLOSE ix_cursor  
	DEALLOCATE ix_cursor 

	-- Fetch next database
	FETCH NEXT FROM db_cursor INTO @DbName
END 

CLOSE db_cursor  
DEALLOCATE db_cursor 