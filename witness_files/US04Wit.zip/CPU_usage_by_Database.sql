WITH CPU_Per_Db
AS
(SELECT 
 dmpa.DatabaseID
 , DB_Name(dmpa.DatabaseID) AS [Database]
 , SUM(dmqs.total_worker_time) AS CPUTimeAsMS
 FROM sys.dm_exec_query_stats dmqs 
 CROSS APPLY 
 (SELECT 
 CONVERT(INT, value) AS [DatabaseID] 
 FROM sys.dm_exec_plan_attributes(dmqs.plan_handle)
 WHERE attribute = N'dbid') dmpa
 GROUP BY dmpa.DatabaseID)
 
 SELECT 
 [Database] 
 ,[CPUTimeAsMS] 
 ,CAST([CPUTimeAsMS] * 1.0 / SUM([CPUTimeAsMS]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [CPUTimeAs%]
 FROM CPU_Per_Db
 where [Database] not in ('master','msdb','model', 'tempdb')
 ORDER BY [CPUTimeAsMS] DESC;

 --sp_whoisactive
 /*

 --by specific time
 DECLARE @Starttime varchar (100)
DECLARE @Endtime varchar (100)
SET @Starttime = '2020-09-08 18:55'
SET @Endtime = '2020-09-08 19:55'
SELECT AVG([CPUTimeAS%]),[Database] as [CPU_Average]
FROM [SQL_Trace].[dbo].[CPU_Monitor]
where collection_time between @Starttime AND @Endtime
group by [Database]
order by 1 desc

*/

WITH IOPS_Per_Db
AS
(SELECT 
 dmpa.DatabaseID
 , DB_Name(dmpa.DatabaseID) AS [Database]
 , SUM(dmqs.total_logical_reads + dmqs.total_logical_writes) AS IOPS_Activity
  FROM sys.dm_exec_query_stats dmqs 
 CROSS APPLY 
 (SELECT 
 CONVERT(INT, value) AS [DatabaseID] 
 FROM sys.dm_exec_plan_attributes(dmqs.plan_handle)
 WHERE attribute = N'dbid') dmpa
 GROUP BY dmpa.DatabaseID)
 

SELECT 
 [Database] 
 ,[IOPS_Activity] 
 ,CAST([IOPS_Activity] * 1.0 / SUM([IOPS_Activity]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [IOPS_Activity_As%]
 --,GETDATE() as [Collection_Time]
 FROM IOPS_Per_Db
 WHERE [Database] not in ('master','msdb','model','tempdb')
 ORDER BY [IOPS_Activity] DESC;

 WITH MemoryUsage_Per_Db
AS
(SELECT 
 dmpa.DatabaseID
 , DB_Name(dmpa.DatabaseID) AS [Database]
 , SUM(dmqs.total_used_grant_kb) AS Memory_Usage_in_KB
  FROM sys.dm_exec_query_stats dmqs 
 CROSS APPLY 
 (SELECT 
 CONVERT(INT, value) AS [DatabaseID] 
 FROM sys.dm_exec_plan_attributes(dmqs.plan_handle)
 WHERE attribute = N'dbid') dmpa
 GROUP BY dmpa.DatabaseID)
 
SELECT 
 [Database] 
 ,[Memory_Usage_in_KB] 
 ,CAST([Memory_Usage_in_KB] * 1.0 / SUM([Memory_Usage_in_KB]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [Memory_Usage_As%]
 --,GETDATE() as [Collection_Time]
 FROM MemoryUsage_Per_Db
 WHERE [Database] not in ('master','msdb','model','tempdb')
 ORDER BY [Memory_Usage_in_KB] DESC;