USE [master]
GO
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev17', FILENAME = N'Z:\tempdb\tempdb17.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev18', FILENAME = N'Z:\tempdb\tempdb18.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev19', FILENAME = N'Z:\tempdb\tempdb19.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev20', FILENAME = N'Z:\tempdb\tempdb20.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev21', FILENAME = N'Z:\tempdb\tempdb21.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev22', FILENAME = N'Z:\tempdb\tempdb22.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev23', FILENAME = N'Z:\tempdb\tempdb23.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)
ALTER DATABASE [tempdb] ADD FILE ( NAME = N'tempdev24', FILENAME = N'Z:\tempdb\tempdb24.ndf' , SIZE = 20480000KB , FILEGROWTH = 0)


GO
