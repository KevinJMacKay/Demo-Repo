-- prod
use snhu
go

select object_name(object_id), * from sys.dm_exec_procedure_stats where object_name(object_id) like '%FILE%'

-- not there, get any plan into cache: 
exec s_DataSet_GetRubricAssessmentCriteria_v5 1, 1, 0, 0
select object_name(object_id), * from sys.dm_exec_procedure_stats where object_name(object_id) like 's_DataSet_GetRubric%'

-- create any plan guide with handle:
exec sp_create_plan_guide_from_handle 
	's_DataSet_GetRubricAssessmentCriteria_v5 pinned plan',
	0x05000D00F4C97368505E9343DC00000001000000000000000000000000000000000000000000000000000000;

-- use ssms to script drop and create: Object Explorer -> Databases -> snhu -> Programmability -> Plan Guides
-- but then replace the very last parameter with the preferred plan:
-- important formatting notes: 
--   1) Remove anything that looks like <?xml version="1.0" encoding="utf-16"?> on the first line
--   2) single quotes need to be escaped ' ==> ''
--   3) I had success wrapping a query plan with hint syntax: @stmt='OPTION (USE PLAN N''<the plan>'')'

USE [snhu]
GO

/****** Object:  PlanGuide s_DataSet_GetRubricAssessmentCriteria_v5 pinned plan    Script Date: 8/1/2018 2:01:51 PM ******/
EXEC sp_control_plan_guide @operation = N'DROP', @name = N'[s_DataSet_GetRubricAssessmentCriteria_v5 pinned plan]'
GO

/****** Object:  PlanGuide s_DataSet_GetRubricAssessmentCriteria_v5 pinned plan    Script Date: 8/1/2018 2:01:51 PM ******/
EXEC sp_create_plan_guide @name = N'[s_DataSet_GetRubricAssessmentCriteria_v5 pinned plan]', 
@stmt = N'SELECT TOP( @BatchSize ) WITH TIES
    RA.AssessmentId,
    CAR.UserId,
    RA.RubricId,
    RC.Name AS CriterionName,
    RAC.Score,
    YARL.Name AS LevelAchieved,
    LEFT( RAC.Feedback, @TruncateLimit ) AS Feedback,
    RAC.IsScoreOverridden,
    RAC.CriterionId,
    OS.OrgUnitId
FROM dbo.[ORG_STRUCTURE] AS OS
INNER JOIN dbo.[RUBRICS] AS R ON
    R.OrgUnitId = OS.OrgUnitId
INNER JOIN dbo.RUBRIC_LEVELS AS RL ON
    RL.RubricId = R.RubricId
INNER JOIN dbo.RUBRIC_CRITERIA AS RC ON
    RC.RubricId = R.RubricId
INNER JOIN dbo.RUBRIC_ASSESSMENTS AS RA ON
    R.RubricId = RA.RubricId AND RL.LevelId = RA.LevelId
INNER JOIN dbo.RUBRIC_ASSESSMENT_CRITERIA AS RAC ON
    RAC.AssessmentId = RA.AssessmentId AND 
    RAC.RubricId = RA.RubricId AND
    RAC.CriterionId = RC.CriterionId
INNER JOIN dbo.COMPETENCY_ACTIVITY_RESULTS AS CAR ON
    CAR.AssessmentId = RA.AssessmentId AND 
    CAR.RubricId = RA.RubricId
LEFT OUTER JOIN dbo.RUBRIC_LEVELS as YARL ON
    YARL.RubricId = RAC.RubricId AND
    YARL.LevelId = RAC.LevelId
WHERE 
    OrganizationId = @OrgId AND
    ( 
        ( OS.OrgUnitId < @OrgUnitId )
    )
ORDER BY
    OS.OrgUnitId DESC', @type = N'OBJECT', @module_or_batch = N'[dbo].[s_DataSet_GetRubricAssessmentCriteria_v5]', @hints = N'OPTION (USE PLAN
N''<ShowPlanXML xmlns="http://schemas.microsoft.com/sqlserver/2004/07/showplan" Version="1.3.1" Build="12.0.5000.0">
  <BatchSequence>
    <Batch>
      <Statements>
        <StmtSimple StatementText="SELECT TOP( @BatchSize ) WITH TIES&#xA;    RA.AssessmentId,&#xA;    CAR.UserId,&#xA;    RA.RubricId,&#xA;    RC.Name AS CriterionName,&#xA;    RAC.Score,&#xA;    YARL.Name AS LevelAchieved,&#xA;    LEFT( RAC.Feedback, @TruncateLimit ) AS Feedback,&#xA;    RAC.IsScoreOverridden,&#xA;    RAC.CriterionId,&#xA;    OS.OrgUnitId&#xA;FROM dbo.[ORG_STRUCTURE] AS OS&#xA;INNER JOIN dbo.[RUBRICS] AS R ON&#xA;    R.OrgUnitId = OS.OrgUnitId&#xA;INNER JOIN dbo.RUBRIC_LEVELS AS RL ON&#xA;    RL.RubricId = R.RubricId&#xA;INNER JOIN dbo.RUBRIC_CRITERIA AS RC ON&#xA;    RC.RubricId = R.RubricId&#xA;INNER JOIN dbo.RUBRIC_ASSESSMENTS AS RA ON&#xA;    R.RubricId = RA.RubricId AND RL.LevelId = RA.LevelId&#xA;INNER JOIN dbo.RUBRIC_ASSESSMENT_CRITERIA AS RAC ON&#xA;    RAC.AssessmentId = RA.AssessmentId AND &#xA;    RAC.RubricId = RA.RubricId AND&#xA;    RAC.CriterionId = RC.CriterionId&#xA;INNER JOIN dbo.COMPETENCY_ACTIVITY_RESULTS AS CAR ON&#xA;    CAR.AssessmentId = RA.AssessmentId AND &#xA;    CAR.RubricId = RA.RubricId&#xA;LEFT OUTER JOIN dbo.RUBRIC_LEVELS as YARL ON&#xA;    YARL.RubricId = RAC.RubricId AND&#xA;    YARL.LevelId = RAC.LevelId&#xA;WHERE &#xA;    OrganizationId = @OrgId AND&#xA;    ( &#xA;        ( OS.OrgUnitId &lt; @OrgUnitId )&#xA;    )&#xA;ORDER BY&#xA;    OS.OrgUnitId DESC" StatementId="1" StatementCompId="4" StatementType="SELECT" RetrievedFromCache="true" StatementSubTreeCost="18685.2" StatementEstRows="9.88856e+007" StatementOptmLevel="FULL" QueryHash="0x7D5B3EF946C40D32" QueryPlanHash="0xAF0D741F9102C214" CardinalityEstimationModelVersion="120">
          <StatementSetOptions QUOTED_IDENTIFIER="true" ARITHABORT="false" CONCAT_NULL_YIELDS_NULL="true" ANSI_NULLS="true" ANSI_PADDING="true" ANSI_WARNINGS="true" NUMERIC_ROUNDABORT="false" />
          <QueryPlan CachedPlanSize="200" CompileTime="350" CompileCPU="306" CompileMemory="7504">
            <ThreadStat Branches="3" />
            <MemoryGrantInfo SerialRequiredMemory="2048" SerialDesiredMemory="1856864" />
            <OptimizerHardwareDependentProperties EstimatedAvailableMemoryGrant="640000" EstimatedPagesCached="640000" EstimatedAvailableDegreeOfParallelism="8" MaxCompileMemory="57526752" />
            <TraceFlags IsCompileTime="1">
              <TraceFlag Value="1118" Scope="Global" />
              <TraceFlag Value="2390" Scope="Global" />
              <TraceFlag Value="3226" Scope="Global" />
              <TraceFlag Value="4199" Scope="Global" />
            </TraceFlags>
            <RelOp NodeId="0" PhysicalOp="Compute Scalar" LogicalOp="Compute Scalar" EstimateRows="9.88856e+007" EstimateIO="0" EstimateCPU="9.88856" AvgRowSize="4594" EstimatedTotalSubtreeCost="18685.2" Parallel="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
              <OutputList>
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                <ColumnReference Column="Expr1010" />
              </OutputList>
              <ComputeScalar>
                <DefinedValues>
                  <DefinedValue>
                    <ColumnReference Column="Expr1010" />
                    <ScalarOperator ScalarString="substring([snhu].[dbo].[RUBRIC_ASSESSMENT_CRITERIA].[Feedback] as [RAC].[Feedback],(1),CONVERT_IMPLICIT(bigint,[@TruncateLimit],0))">
                      <Intrinsic FunctionName="substring">
                        <ScalarOperator>
                          <Identifier>
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                          </Identifier>
                        </ScalarOperator>
                        <ScalarOperator>
                          <Const ConstValue="(1)" />
                        </ScalarOperator>
                        <ScalarOperator>
                          <Identifier>
                            <ColumnReference Column="ConstExpr1011">
                              <ScalarOperator>
                                <Convert DataType="bigint" Style="0" Implicit="1">
                                  <ScalarOperator>
                                    <Identifier>
                                      <ColumnReference Column="@TruncateLimit" />
                                    </Identifier>
                                  </ScalarOperator>
                                </Convert>
                              </ScalarOperator>
                            </ColumnReference>
                          </Identifier>
                        </ScalarOperator>
                      </Intrinsic>
                    </ScalarOperator>
                  </DefinedValue>
                </DefinedValues>
                <RelOp NodeId="1" PhysicalOp="Top" LogicalOp="Top" EstimateRows="9.88856e+007" EstimateIO="0" EstimateCPU="9.88856" AvgRowSize="4594" EstimatedTotalSubtreeCost="18675.3" Parallel="0" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                  <OutputList>
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                  </OutputList>
                  <Top RowCount="0" IsPercent="0" WithTies="1">
                    <TieColumns>
                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                    </TieColumns>
                    <TopExpression>
                      <ScalarOperator ScalarString="[@BatchSize]">
                        <Identifier>
                          <ColumnReference Column="@BatchSize" />
                        </Identifier>
                      </ScalarOperator>
                    </TopExpression>
                    <RelOp NodeId="2" PhysicalOp="Parallelism" LogicalOp="Gather Streams" EstimateRows="9.88856e+007" EstimateIO="0" EstimateCPU="4356.53" AvgRowSize="4594" EstimatedTotalSubtreeCost="18665.5" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                      <OutputList>
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                      </OutputList>
                      <Parallelism>
                        <OrderBy>
                          <OrderByColumn Ascending="0">
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                          </OrderByColumn>
                        </OrderBy>
                        <RelOp NodeId="3" PhysicalOp="Nested Loops" LogicalOp="Left Outer Join" EstimateRows="9.88856e+007" EstimateIO="0" EstimateCPU="25.8339" AvgRowSize="4594" EstimatedTotalSubtreeCost="14308.9" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                          <OutputList>
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                          </OutputList>
                          <NestedLoops Optimized="0" WithOrderedPrefetch="1">
                            <OuterReferences>
                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="LevelId" />
                              <ColumnReference Column="Expr1017" />
                            </OuterReferences>
                            <RelOp NodeId="5" PhysicalOp="Nested Loops" LogicalOp="Inner Join" EstimateRows="4.94428e+007" EstimateIO="0" EstimateCPU="16.6524" AvgRowSize="4352" EstimatedTotalSubtreeCost="6466.19" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                              <OutputList>
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="LevelId" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                              </OutputList>
                              <NestedLoops Optimized="0" WithOrderedPrefetch="1">
                                <OuterReferences>
                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="CriterionId" />
                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                  <ColumnReference Column="Expr1016" />
                                </OuterReferences>
                                <RelOp NodeId="7" PhysicalOp="Nested Loops" LogicalOp="Inner Join" EstimateRows="3.18706e+007" EstimateIO="0" EstimateCPU="16.6524" AvgRowSize="315" EstimatedTotalSubtreeCost="1410.15" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                  <OutputList>
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="CriterionId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                  </OutputList>
                                  <NestedLoops Optimized="0" WithOrderedPrefetch="1">
                                    <OuterReferences>
                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                      <ColumnReference Column="Expr1015" />
                                    </OuterReferences>
                                    <RelOp NodeId="9" PhysicalOp="Sort" LogicalOp="Sort" EstimateRows="5.40625e+006" EstimateIO="0.00140766" EstimateCPU="69.3763" AvgRowSize="47" EstimatedTotalSubtreeCost="509.655" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                      <OutputList>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                      </OutputList>
                                      <MemoryFractions Input="0.310112" Output="1" />
                                      <Sort Distinct="0">
                                        <OrderBy>
                                          <OrderByColumn Ascending="0">
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                          </OrderByColumn>
                                        </OrderBy>
                                        <RelOp NodeId="10" PhysicalOp="Hash Match" LogicalOp="Inner Join" EstimateRows="5.40625e+006" EstimateIO="0" EstimateCPU="31.019" AvgRowSize="47" EstimatedTotalSubtreeCost="440.277" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                          <OutputList>
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                          </OutputList>
                                          <MemoryFractions Input="0.807109" Output="0.689888" />
                                          <Hash>
                                            <DefinedValues />
                                            <HashKeysBuild>
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                            </HashKeysBuild>
                                            <HashKeysProbe>
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                            </HashKeysProbe>
                                            <ProbeResidual>
                                              <ScalarOperator ScalarString="[snhu].[dbo].[COMPETENCY_ACTIVITY_RESULTS].[RubricId] as [CAR].[RubricId]=[snhu].[dbo].[RUBRIC_ASSESSMENTS].[RubricId] as [RA].[RubricId] AND [snhu].[dbo].[COMPETENCY_ACTIVITY_RESULTS].[AssessmentId] as [CAR].[AssessmentId]=[snhu].[dbo].[RUBRIC_ASSESSMENTS].[AssessmentId] as [RA].[AssessmentId]">
                                                <Logical Operation="AND">
                                                  <ScalarOperator>
                                                    <Compare CompareOp="EQ">
                                                      <ScalarOperator>
                                                        <Identifier>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                        </Identifier>
                                                      </ScalarOperator>
                                                      <ScalarOperator>
                                                        <Identifier>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                        </Identifier>
                                                      </ScalarOperator>
                                                    </Compare>
                                                  </ScalarOperator>
                                                  <ScalarOperator>
                                                    <Compare CompareOp="EQ">
                                                      <ScalarOperator>
                                                        <Identifier>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                                        </Identifier>
                                                      </ScalarOperator>
                                                      <ScalarOperator>
                                                        <Identifier>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                        </Identifier>
                                                      </ScalarOperator>
                                                    </Compare>
                                                  </ScalarOperator>
                                                </Logical>
                                              </ScalarOperator>
                                            </ProbeResidual>
                                            <RelOp NodeId="11" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="5.76282e+006" EstimateIO="0" EstimateCPU="3.71148" AvgRowSize="27" EstimatedTotalSubtreeCost="321.501" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                              <OutputList>
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                              </OutputList>
                                              <Parallelism PartitioningType="Hash">
                                                <PartitionColumns>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                </PartitionColumns>
                                                <RelOp NodeId="12" PhysicalOp="Hash Match" LogicalOp="Inner Join" EstimateRows="5.76282e+006" EstimateIO="0" EstimateCPU="16.421" AvgRowSize="27" EstimatedTotalSubtreeCost="317.789" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                  <OutputList>
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                  </OutputList>
                                                  <MemoryFractions Input="0.841004" Output="0.192891" />
                                                  <Hash>
                                                    <DefinedValues />
                                                    <HashKeysBuild>
                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                    </HashKeysBuild>
                                                    <HashKeysProbe>
                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                    </HashKeysProbe>
                                                    <ProbeResidual>
                                                      <ScalarOperator ScalarString="[snhu].[dbo].[RUBRIC_LEVELS].[RubricId] as [RL].[RubricId]=[snhu].[dbo].[RUBRIC_ASSESSMENTS].[RubricId] as [RA].[RubricId] AND [snhu].[dbo].[RUBRIC_LEVELS].[LevelId] as [RL].[LevelId]=[snhu].[dbo].[RUBRIC_ASSESSMENTS].[LevelId] as [RA].[LevelId]">
                                                        <Logical Operation="AND">
                                                          <ScalarOperator>
                                                            <Compare CompareOp="EQ">
                                                              <ScalarOperator>
                                                                <Identifier>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                </Identifier>
                                                              </ScalarOperator>
                                                              <ScalarOperator>
                                                                <Identifier>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                                </Identifier>
                                                              </ScalarOperator>
                                                            </Compare>
                                                          </ScalarOperator>
                                                          <ScalarOperator>
                                                            <Compare CompareOp="EQ">
                                                              <ScalarOperator>
                                                                <Identifier>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                                </Identifier>
                                                              </ScalarOperator>
                                                              <ScalarOperator>
                                                                <Identifier>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                                </Identifier>
                                                              </ScalarOperator>
                                                            </Compare>
                                                          </ScalarOperator>
                                                        </Logical>
                                                      </ScalarOperator>
                                                    </ProbeResidual>
                                                    <RelOp NodeId="13" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="1.38072e+006" EstimateIO="0" EstimateCPU="0.910907" AvgRowSize="27" EstimatedTotalSubtreeCost="12.4299" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                      <OutputList>
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                      </OutputList>
                                                      <Parallelism PartitioningType="Hash">
                                                        <PartitionColumns>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                        </PartitionColumns>
                                                        <RelOp NodeId="14" PhysicalOp="Hash Match" LogicalOp="Inner Join" EstimateRows="1.38072e+006" EstimateIO="0" EstimateCPU="3.30464" AvgRowSize="27" EstimatedTotalSubtreeCost="11.519" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                          <OutputList>
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                          </OutputList>
                                                          <MemoryFractions Input="0.809385" Output="0.158996" />
                                                          <Hash>
                                                            <DefinedValues />
                                                            <HashKeysBuild>
                                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                            </HashKeysBuild>
                                                            <HashKeysProbe>
                                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                            </HashKeysProbe>
                                                            <ProbeResidual>
                                                              <ScalarOperator ScalarString="[snhu].[dbo].[RUBRIC_LEVELS].[RubricId] as [RL].[RubricId]=[snhu].[dbo].[RUBRICS].[RubricId] as [R].[RubricId]">
                                                                <Compare CompareOp="EQ">
                                                                  <ScalarOperator>
                                                                    <Identifier>
                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                    </Identifier>
                                                                  </ScalarOperator>
                                                                  <ScalarOperator>
                                                                    <Identifier>
                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                    </Identifier>
                                                                  </ScalarOperator>
                                                                </Compare>
                                                              </ScalarOperator>
                                                            </ProbeResidual>
                                                            <RelOp NodeId="15" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="196822" EstimateIO="0" EstimateCPU="0.117789" AvgRowSize="19" EstimatedTotalSubtreeCost="1.7625" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                              <OutputList>
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                              </OutputList>
                                                              <Parallelism PartitioningType="Hash">
                                                                <PartitionColumns>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                </PartitionColumns>
                                                                <RelOp NodeId="16" PhysicalOp="Hash Match" LogicalOp="Inner Join" EstimateRows="196822" EstimateIO="0" EstimateCPU="0.380288" AvgRowSize="19" EstimatedTotalSubtreeCost="1.64471" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                  <OutputList>
                                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                  </OutputList>
                                                                  <MemoryFractions Input="1" Output="0.190615" />
                                                                  <Hash>
                                                                    <DefinedValues />
                                                                    <HashKeysBuild>
                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                    </HashKeysBuild>
                                                                    <HashKeysProbe>
                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                    </HashKeysProbe>
                                                                    <RelOp NodeId="17" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="80492.1" EstimateIO="0" EstimateCPU="0.0526099" AvgRowSize="11" EstimatedTotalSubtreeCost="0.413699" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                      <OutputList>
                                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                      </OutputList>
                                                                      <Parallelism PartitioningType="Hash">
                                                                        <PartitionColumns>
                                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                        </PartitionColumns>
                                                                        <RelOp NodeId="18" PhysicalOp="Index Seek" LogicalOp="Index Seek" EstimateRows="80492.1" EstimateIO="0.340293" EstimateCPU="0.0144843" AvgRowSize="11" EstimatedTotalSubtreeCost="0.354778" TableCardinality="107232" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                          <OutputList>
                                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                          </OutputList>
                                                                          <IndexScan Ordered="1" ScanDirection="FORWARD" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                                                            <DefinedValues>
                                                                              <DefinedValue>
                                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                              </DefinedValue>
                                                                            </DefinedValues>
                                                                            <Object Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Index="[IX_ORG_STRUCTURE]" Alias="[OS]" IndexKind="NonClustered" Storage="RowStore" />
                                                                            <SeekPredicates>
                                                                              <SeekPredicateNew>
                                                                                <SeekKeys>
                                                                                  <Prefix ScanType="EQ">
                                                                                    <RangeColumns>
                                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrganizationId" />
                                                                                    </RangeColumns>
                                                                                    <RangeExpressions>
                                                                                      <ScalarOperator ScalarString="[@OrgId]">
                                                                                        <Identifier>
                                                                                          <ColumnReference Column="@OrgId" />
                                                                                        </Identifier>
                                                                                      </ScalarOperator>
                                                                                    </RangeExpressions>
                                                                                  </Prefix>
                                                                                </SeekKeys>
                                                                              </SeekPredicateNew>
                                                                            </SeekPredicates>
                                                                            <Predicate>
                                                                              <ScalarOperator ScalarString="[snhu].[dbo].[ORG_STRUCTURE].[OrgUnitId] as [OS].[OrgUnitId]&lt;[@OrgUnitId]">
                                                                                <Compare CompareOp="LT">
                                                                                  <ScalarOperator>
                                                                                    <Identifier>
                                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[ORG_STRUCTURE]" Alias="[OS]" Column="OrgUnitId" />
                                                                                    </Identifier>
                                                                                  </ScalarOperator>
                                                                                  <ScalarOperator>
                                                                                    <Identifier>
                                                                                      <ColumnReference Column="@OrgUnitId" />
                                                                                    </Identifier>
                                                                                  </ScalarOperator>
                                                                                </Compare>
                                                                              </ScalarOperator>
                                                                            </Predicate>
                                                                          </IndexScan>
                                                                        </RelOp>
                                                                      </Parallelism>
                                                                    </RelOp>
                                                                    <RelOp NodeId="19" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="198771" EstimateIO="0" EstimateCPU="0.113754" AvgRowSize="19" EstimatedTotalSubtreeCost="0.850721" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                      <OutputList>
                                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                      </OutputList>
                                                                      <Parallelism PartitioningType="Hash">
                                                                        <PartitionColumns>
                                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                        </PartitionColumns>
                                                                        <RelOp NodeId="20" PhysicalOp="Index Scan" LogicalOp="Index Scan" EstimateRows="198771" EstimateIO="0.692014" EstimateCPU="0.0313024" AvgRowSize="19" EstimatedTotalSubtreeCost="0.723316" TableCardinality="227511" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                          <OutputList>
                                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                          </OutputList>
                                                                          <IndexScan Ordered="0" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                                                            <DefinedValues>
                                                                              <DefinedValue>
                                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="RubricId" />
                                                                              </DefinedValue>
                                                                              <DefinedValue>
                                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                              </DefinedValue>
                                                                            </DefinedValues>
                                                                            <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Index="[PK_RUBRICS]" Alias="[R]" IndexKind="NonClustered" Storage="RowStore" />
                                                                            <Predicate>
                                                                              <ScalarOperator ScalarString="[snhu].[dbo].[RUBRICS].[OrgUnitId] as [R].[OrgUnitId]&lt;[@OrgUnitId]">
                                                                                <Compare CompareOp="LT">
                                                                                  <ScalarOperator>
                                                                                    <Identifier>
                                                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRICS]" Alias="[R]" Column="OrgUnitId" />
                                                                                    </Identifier>
                                                                                  </ScalarOperator>
                                                                                  <ScalarOperator>
                                                                                    <Identifier>
                                                                                      <ColumnReference Column="@OrgUnitId" />
                                                                                    </Identifier>
                                                                                  </ScalarOperator>
                                                                                </Compare>
                                                                              </ScalarOperator>
                                                                            </Predicate>
                                                                          </IndexScan>
                                                                        </RelOp>
                                                                      </Parallelism>
                                                                    </RelOp>
                                                                  </Hash>
                                                                </RelOp>
                                                              </Parallelism>
                                                            </RelOp>
                                                            <RelOp NodeId="22" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="1.59268e+006" EstimateIO="0" EstimateCPU="0.805976" AvgRowSize="23" EstimatedTotalSubtreeCost="6.45182" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                              <OutputList>
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                              </OutputList>
                                                              <Parallelism PartitioningType="Hash">
                                                                <PartitionColumns>
                                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                </PartitionColumns>
                                                                <RelOp NodeId="23" PhysicalOp="Index Scan" LogicalOp="Index Scan" EstimateRows="1.59268e+006" EstimateIO="5.42683" EstimateCPU="0.219013" AvgRowSize="23" EstimatedTotalSubtreeCost="5.64584" TableCardinality="1.59268e+006" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                                  <OutputList>
                                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                                  </OutputList>
                                                                  <IndexScan Ordered="0" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                                                    <DefinedValues>
                                                                      <DefinedValue>
                                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="RubricId" />
                                                                      </DefinedValue>
                                                                      <DefinedValue>
                                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[RL]" Column="LevelId" />
                                                                      </DefinedValue>
                                                                    </DefinedValues>
                                                                    <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Index="[IX_RUBRIC_LEVELS_LevelId]" Alias="[RL]" IndexKind="NonClustered" Storage="RowStore" />
                                                                  </IndexScan>
                                                                </RelOp>
                                                              </Parallelism>
                                                            </RelOp>
                                                          </Hash>
                                                        </RelOp>
                                                      </Parallelism>
                                                    </RelOp>
                                                    <RelOp NodeId="25" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="6.66138e+006" EstimateIO="0" EstimateCPU="4.51557" AvgRowSize="31" EstimatedTotalSubtreeCost="288.938" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                      <OutputList>
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                      </OutputList>
                                                      <Parallelism PartitioningType="Hash">
                                                        <PartitionColumns>
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                        </PartitionColumns>
                                                        <RelOp NodeId="26" PhysicalOp="Clustered Index Scan" LogicalOp="Clustered Index Scan" EstimateRows="6.66138e+006" EstimateIO="283.507" EstimateCPU="0.91596" AvgRowSize="31" EstimatedTotalSubtreeCost="284.423" TableCardinality="6.66138e+006" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                          <OutputList>
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                          </OutputList>
                                                          <IndexScan Ordered="0" ForcedIndex="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                                            <DefinedValues>
                                                              <DefinedValue>
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="AssessmentId" />
                                                              </DefinedValue>
                                                              <DefinedValue>
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="RubricId" />
                                                              </DefinedValue>
                                                              <DefinedValue>
                                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Alias="[RA]" Column="LevelId" />
                                                              </DefinedValue>
                                                            </DefinedValues>
                                                            <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENTS]" Index="[IX_RUBRIC_ASSESSMENTS_AssociationId]" Alias="[RA]" IndexKind="Clustered" Storage="RowStore" />
                                                          </IndexScan>
                                                        </RelOp>
                                                      </Parallelism>
                                                    </RelOp>
                                                  </Hash>
                                                </RelOp>
                                              </Parallelism>
                                            </RelOp>
                                            <RelOp NodeId="28" PhysicalOp="Parallelism" LogicalOp="Repartition Streams" EstimateRows="6.92354e+006" EstimateIO="0" EstimateCPU="4.45329" AvgRowSize="27" EstimatedTotalSubtreeCost="87.7573" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                              <OutputList>
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                              </OutputList>
                                              <Parallelism PartitioningType="Hash">
                                                <PartitionColumns>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                                </PartitionColumns>
                                                <RelOp NodeId="29" PhysicalOp="Clustered Index Scan" LogicalOp="Clustered Index Scan" EstimateRows="6.92354e+006" EstimateIO="82.352" EstimateCPU="0.952007" AvgRowSize="27" EstimatedTotalSubtreeCost="83.304" TableCardinality="6.92354e+006" Parallel="1" EstimateRebinds="0" EstimateRewinds="0" EstimatedExecutionMode="Row">
                                                  <OutputList>
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                                  </OutputList>
                                                  <IndexScan Ordered="0" ForcedIndex="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                                    <DefinedValues>
                                                      <DefinedValue>
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="UserId" />
                                                      </DefinedValue>
                                                      <DefinedValue>
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                      </DefinedValue>
                                                      <DefinedValue>
                                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                                      </DefinedValue>
                                                    </DefinedValues>
                                                    <Object Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Index="[PK_COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" IndexKind="Clustered" Storage="RowStore" />
                                                  </IndexScan>
                                                </RelOp>
                                              </Parallelism>
                                            </RelOp>
                                          </Hash>
                                        </RelOp>
                                      </Sort>
                                    </RelOp>
                                    <RelOp NodeId="31" PhysicalOp="Clustered Index Seek" LogicalOp="Clustered Index Seek" EstimateRows="5.89514" EstimateIO="0.003125" EstimateCPU="0.000163485" AvgRowSize="275" EstimatedTotalSubtreeCost="883.843" TableCardinality="1.33761e+006" Parallel="1" EstimateRebinds="1.3633e+006" EstimateRewinds="4.04295e+006" EstimatedExecutionMode="Row">
                                      <OutputList>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="CriterionId" />
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                                      </OutputList>
                                      <IndexScan Ordered="1" ScanDirection="FORWARD" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                        <DefinedValues>
                                          <DefinedValue>
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="CriterionId" />
                                          </DefinedValue>
                                          <DefinedValue>
                                            <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="Name" />
                                          </DefinedValue>
                                        </DefinedValues>
                                        <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Index="[PK_RUBRIC_CRITERIA]" Alias="[RC]" IndexKind="Clustered" Storage="RowStore" />
                                        <SeekPredicates>
                                          <SeekPredicateNew>
                                            <SeekKeys>
                                              <Prefix ScanType="EQ">
                                                <RangeColumns>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="RubricId" />
                                                </RangeColumns>
                                                <RangeExpressions>
                                                  <ScalarOperator ScalarString="[snhu].[dbo].[COMPETENCY_ACTIVITY_RESULTS].[RubricId] as [CAR].[RubricId]">
                                                    <Identifier>
                                                      <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                    </Identifier>
                                                  </ScalarOperator>
                                                </RangeExpressions>
                                              </Prefix>
                                            </SeekKeys>
                                          </SeekPredicateNew>
                                        </SeekPredicates>
                                      </IndexScan>
                                    </RelOp>
                                  </NestedLoops>
                                </RelOp>
                                <RelOp NodeId="32" PhysicalOp="Clustered Index Seek" LogicalOp="Clustered Index Seek" EstimateRows="1" EstimateIO="0.003125" EstimateCPU="0.0001581" AvgRowSize="4069" EstimatedTotalSubtreeCost="5039.38" TableCardinality="6.09216e+007" Parallel="1" EstimateRebinds="3.17156e+007" EstimateRewinds="154992" EstimatedExecutionMode="Row">
                                  <OutputList>
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="LevelId" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                                  </OutputList>
                                  <IndexScan Ordered="1" ScanDirection="FORWARD" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                    <DefinedValues>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                                      </DefinedValue>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                                      </DefinedValue>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="LevelId" />
                                      </DefinedValue>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Score" />
                                      </DefinedValue>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="IsScoreOverridden" />
                                      </DefinedValue>
                                      <DefinedValue>
                                        <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="Feedback" />
                                      </DefinedValue>
                                    </DefinedValues>
                                    <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Index="[PK_RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" IndexKind="Clustered" Storage="RowStore" />
                                    <SeekPredicates>
                                      <SeekPredicateNew>
                                        <SeekKeys>
                                          <Prefix ScanType="EQ">
                                            <RangeColumns>
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="AssessmentId" />
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="CriterionId" />
                                            </RangeColumns>
                                            <RangeExpressions>
                                              <ScalarOperator ScalarString="[snhu].[dbo].[COMPETENCY_ACTIVITY_RESULTS].[AssessmentId] as [CAR].[AssessmentId]">
                                                <Identifier>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="AssessmentId" />
                                                </Identifier>
                                              </ScalarOperator>
                                              <ScalarOperator ScalarString="[snhu].[dbo].[COMPETENCY_ACTIVITY_RESULTS].[RubricId] as [CAR].[RubricId]">
                                                <Identifier>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[COMPETENCY_ACTIVITY_RESULTS]" Alias="[CAR]" Column="RubricId" />
                                                </Identifier>
                                              </ScalarOperator>
                                              <ScalarOperator ScalarString="[snhu].[dbo].[RUBRIC_CRITERIA].[CriterionId] as [RC].[CriterionId]">
                                                <Identifier>
                                                  <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_CRITERIA]" Alias="[RC]" Column="CriterionId" />
                                                </Identifier>
                                              </ScalarOperator>
                                            </RangeExpressions>
                                          </Prefix>
                                        </SeekKeys>
                                      </SeekPredicateNew>
                                    </SeekPredicates>
                                  </IndexScan>
                                </RelOp>
                              </NestedLoops>
                            </RelOp>
                            <RelOp NodeId="33" PhysicalOp="Clustered Index Seek" LogicalOp="Clustered Index Seek" EstimateRows="1" EstimateIO="0.003125" EstimateCPU="0.0001581" AvgRowSize="267" EstimatedTotalSubtreeCost="7816.91" TableCardinality="1.59268e+006" Parallel="1" EstimateRebinds="0" EstimateRewinds="4.94428e+007" EstimatedExecutionMode="Row">
                              <OutputList>
                                <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                              </OutputList>
                              <IndexScan Ordered="1" ScanDirection="FORWARD" ForcedIndex="0" ForceSeek="0" ForceScan="0" NoExpandHint="0" Storage="RowStore">
                                <DefinedValues>
                                  <DefinedValue>
                                    <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="Name" />
                                  </DefinedValue>
                                </DefinedValues>
                                <Object Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Index="[PK_RUBRIC_LEVELS]" Alias="[YARL]" IndexKind="Clustered" Storage="RowStore" />
                                <SeekPredicates>
                                  <SeekPredicateNew>
                                    <SeekKeys>
                                      <Prefix ScanType="EQ">
                                        <RangeColumns>
                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="RubricId" />
                                          <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_LEVELS]" Alias="[YARL]" Column="LevelId" />
                                        </RangeColumns>
                                        <RangeExpressions>
                                          <ScalarOperator ScalarString="[snhu].[dbo].[RUBRIC_ASSESSMENT_CRITERIA].[RubricId] as [RAC].[RubricId]">
                                            <Identifier>
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="RubricId" />
                                            </Identifier>
                                          </ScalarOperator>
                                          <ScalarOperator ScalarString="[snhu].[dbo].[RUBRIC_ASSESSMENT_CRITERIA].[LevelId] as [RAC].[LevelId]">
                                            <Identifier>
                                              <ColumnReference Database="[snhu]" Schema="[dbo]" Table="[RUBRIC_ASSESSMENT_CRITERIA]" Alias="[RAC]" Column="LevelId" />
                                            </Identifier>
                                          </ScalarOperator>
                                        </RangeExpressions>
                                      </Prefix>
                                    </SeekKeys>
                                  </SeekPredicateNew>
                                </SeekPredicates>
                              </IndexScan>
                            </RelOp>
                          </NestedLoops>
                        </RelOp>
                      </Parallelism>
                    </RelOp>
                  </Top>
                </RelOp>
              </ComputeScalar>
            </RelOp>
            <ParameterList>
              <ColumnReference Column="@BatchSize" ParameterCompiledValue="(100000)" />
              <ColumnReference Column="@TruncateLimit" ParameterCompiledValue="(1000)" />
              <ColumnReference Column="@OrgUnitId" ParameterCompiledValue="(88487)" />
              <ColumnReference Column="@OrgId" ParameterCompiledValue="(6606)" />
            </ParameterList>
          </QueryPlan>
        </StmtSimple>
      </Statements>
    </Batch>
  </BatchSequence>
</ShowPlanXML>'')'
GO

