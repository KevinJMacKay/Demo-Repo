--Connect as DAC
--Admin:US04APSQLN109
DBCC SQLPERF (LOGSPACE);
GO

SELECT  *
FROM    sys.dm_exec_requests 
order by start_time desc

USE [Depaul] 
DBCC OPENTRAN 

DECLARE @SQLScript NVARCHAR(MAX)
SELECT @SQLScript = ISNULL(@SQLScript,'') + 'DBCC OPENTRAN('+ Name +');'
FROM sys.databases
EXEC (@SQLScript)

--sp_whoisactive

--684	0	2023-01-01 19:32:18.713	suspended	SELECT
--249	0	2023-01-01 19:10:43.490	suspended	SELECT

select * from sys.databases


ALTER DATABASE [tempdb] MODIFY FILE ( NAME = N'templog', FILENAME = N'Z:\tempdb\templog.ldf' , SIZE = 112400000KB , FILEGROWTH = 0 )
GO

--Kill 684




  