USE [msdb]
GO

/****** Object:  StoredProcedure [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1]    Script Date: 3/12/2019 12:21:49 PM ******/
DROP PROCEDURE [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1]
GO

/****** Object:  StoredProcedure [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1]    Script Date: 3/12/2019 12:21:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1]

@DBName SYSNAME,
@JobName SYSNAME,
@ProcessStartTime DATETIME,
@ProcessDuration INT

AS

SET NOCOUNT ON

/*

--Check results for past 7 days
SELECT *
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [TimeCompleted] > Getdate()-1
AND databasename = 'dmutest'
ORDER BY [TimeCompleted] desc

SELECT DatabaseName,count(DatabaseName) ObjectCount, convert(char(11),TimeCompleted) RunDate
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [TimeCompleted] > Getdate()-7
group by DatabaseName , convert(char(11),TimeCompleted)

EXEC [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1] @DBName = 'dmutest', @JobName = 'IT DBIntegrityCheck', @ProcessStartTime = '2018-09-17 14:29:00', @ProcessDuration ='75'

*/


------------------start making additional customizations here-------------------
/*
DECLARE @DBIntegrity_HistoryKeepThreshold INT		--Keep DBIntegrity update history for this many days

IF EXISTS (SELECT * FROM [msdb].[dbo].[D2LJobsConfigValues] WHERE [DatabaseName] = @DBName AND [JobName] = @JobName AND [ConfigName] = 'DBIntegrity_HistoryKeepThreshold')
BEGIN
	SELECT @DBIntegrity_HistoryKeepThreshold= CAST(ConfigValue AS INT) FROM [msdb].[dbo].[D2LJobsConfigValues] WHERE [DatabaseName] = @DBName AND [JobName] = @JobName AND [ConfigName] = 'DBIntegrity_HistoryKeepThreshold'
END
ELSE
BEGIN
	SELECT @DBIntegrity_HistoryKeepThreshold = CAST(ConfigValue AS INT) FROM [msdb].[dbo].[D2LJobsConfigValues] WHERE [JobName] = @JobName AND [ConfigName] = 'DBIntegrity_HistoryKeepThreshold'
END
-----
*/
--PRINT @DBIntegrity_HistoryKeepThreshold

------------------stop making customizations here---------------------

DECLARE @CollectDBIntegrityCmd NVARCHAR(MAX)
DECLARE @ErrorMessage NVARCHAR(MAX)
DECLARE @CurrentDBIntegrityCmd NVARCHAR(MAX)
DECLARE @CurrentDBIntegrityCmd_CHECKCATALOG NVARCHAR(MAX)
DECLARE @CurrentDBIntegrityCmd_CHECKALLOC NVARCHAR(MAX)

--Verify DB exists....
IF NOT EXISTS(SELECT name FROM sys.databases WHERE name = @DBName)
BEGIN
	GOTO ERROR_EXIT_HERE
END

------------------------------------------------------------------------------------
---- Save progress of the completed actions (to MSDN database)
------------------------------------------------------------------------------------

/*
IF (OBJECT_ID('msdb.dbo.D2LDBIntegrityCheckHistory') IS NULL)
BEGIN

	CREATE TABLE msdb.dbo.D2LDBIntegrityCheckHistory
	( 
		[DatabaseName] sysname, 
		[DatabaseId] int, 
		[TableName] sysname NULL,
		[TableSchema] sysname NULL, 
		[Action] nvarchar(max) NULL,
		[Error] nvarchar(max) NULL,
		[TimeStarted] DATETIME NULL,
		[TimeCompleted] DATETIME NULL
	) 
END;
--------------Maintenance-------------------------------------
DELETE FROM msdb.dbo.D2LDBIntegrityCheckHistory 
WHERE DatabaseName = @DBName
AND TimeCompleted < DATEADD(DD, -@DBIntegrity_HistoryKeepThreshold, GETDATE())
--------------------------------------------------------------
*/

--Print 'Run CHECKCATALOG'
--Run CHECKCATALOG
DECLARE @TimeStartedTemp1 DATETIME
DECLARE @Error1 nvarchar(max)

		SET @CurrentDBIntegrityCmd_CHECKCATALOG = 'USE [' + @DBName + '] DBCC CHECKCATALOG WITH NO_INFOMSGS'

	--Update the start time
	SET @TimeStartedTemp1 = GETDATE();

	INSERT INTO msdb.dbo.D2LDBIntegrityCheckHistory
	SELECT @DBName,DB_ID(@DBName),'DBCC CHECKCATALOG',NULL,@CurrentDBIntegrityCmd_CHECKCATALOG,NULL,@TimeStartedTemp1,NULL
		
	--PRINT(@CurrentUpdateStatsCmd);
	EXEC(@CurrentDBIntegrityCmd_CHECKCATALOG);
	SET @Error1 = @@ERROR

	--Update the time completed
		UPDATE msdb.dbo.D2LDBIntegrityCheckHistory
	SET Error = @Error1, TimeCompleted = GETDATE()
	WHERE [DatabaseName] = @DBName
	AND [TimeStarted] = @TimeStartedTemp1;

--Run CHECKALLOC  
DECLARE @TimeStartedTemp2 DATETIME
DECLARE @Error2 nvarchar(max)

		SET @CurrentDBIntegrityCmd_CHECKALLOC = 'USE [' + @DBName + '] DBCC CHECKALLOC  WITH NO_INFOMSGS'

	--Update the start time
	SET @TimeStartedTemp1 = GETDATE();

	INSERT INTO msdb.dbo.D2LDBIntegrityCheckHistory
	SELECT @DBName,DB_ID(@DBName),'DBCC CHECKALLOC',NULL,@CurrentDBIntegrityCmd_CHECKALLOC,NULL,@TimeStartedTemp1,NULL
		
	--PRINT(@CurrentUpdateStatsCmd);
	EXEC(@CurrentDBIntegrityCmd_CHECKALLOC);
	SET @Error1 = @@ERROR

	--Update the time completed
		UPDATE msdb.dbo.D2LDBIntegrityCheckHistory
	SET Error = @Error1, TimeCompleted = GETDATE()
	WHERE [DatabaseName] = @DBName
	AND [TimeStarted] = @TimeStartedTemp1;
	


--------------------------------------------------------------
----Load D2LStatsUpdateHistory with Table Names
--------------------------------------------------------------

SET @CollectDBIntegrityCmd = 'USE [' + @DBName + ']

INSERT msdb.dbo.D2LDBIntegrityCheckHistory
SELECT DISTINCT
	DB_NAME() AS [Col1],
	DB_ID() AS [Col2],
    t.name as tablename,
	SCHEMA_NAME(t.schema_id) AS [Col5],
	NULL AS [Col11],
	NULL AS [Col12],
	NULL AS [Col13],
	NULL AS [Col14]
FROM sys.tables t 
WHERE t.name not in
(
	SELECT [TableName] FROM msdb.dbo.D2LDBIntegrityCheckHistory
	WHERE [TimeCompleted] IS NULL
	AND [DatabaseName] = '''+ @DBName + '''
)
AND
t.name not in
(
	SELECT distinct [TableName] FROM msdb.dbo.D2LDBIntegrityCheckHistory
	WHERE [TimeCompleted] >= GetDate() -7
	AND 
	[DatabaseName] = '''+ @DBName + '''
)
'

--PRINT (CollectDBIntegrityCmd)
EXEC (@CollectDBIntegrityCmd)

--Print 'Start Cursor'
-----------------Process D2LDBIntegrityCheckHistory Table------------------
DECLARE @SchemaN SYSNAME
DECLARE @TableN SYSNAME
DECLARE @TimeStartedTemp DATETIME
DECLARE @Error nvarchar(max)
DECLARE @Mailbody nvarchar(max)

DECLARE cDBIntegrity CURSOR FOR
SELECT [TableName],	[TableSchema]
FROM msdb.dbo.D2LDBIntegrityCheckHistory
WHERE TimeCompleted IS NULL
AND DatabaseName = @DBName
Order BY [TimeStarted] DESC

OPEN cDBIntegrity
FETCH NEXT FROM cDBIntegrity INTO @TableN, @SchemaN
WHILE @@FETCH_STATUS = 0 AND (datediff(minute,@ProcessStartTime,getdate())) < @ProcessDuration
	BEGIN
	
		BEGIN TRY	
		--Print 'Begin Try'
			SET @CurrentDBIntegrityCmd = 'USE [' + @DBName + ']	DBCC CHECKTABLE (''[' + @SchemaN + '].[' + @TableN + ']'',NOINDEX) WITH PHYSICAL_ONLY,NO_INFOMSGS'
	
			--Update the start time
			SET @TimeStartedTemp = GETDATE();

			UPDATE msdb.dbo.D2LDBIntegrityCheckHistory
			SET [TimeStarted] = @TimeStartedTemp, [Action] = @CurrentDBIntegrityCmd
			WHERE [TableSchema] = @SchemaN
			AND [TableName] = @TableN
			AND [DatabaseName] = @DBName
			AND [TimeCompleted] is null;
		
			--Run command
			EXEC(@CurrentDBIntegrityCmd);
			--PRINT @CurrentDBIntegrityCmd
			SET @Error = @@ERROR

			--Update the time completed
			UPDATE msdb.dbo.D2LDBIntegrityCheckHistory
			SET Error = @Error, TimeCompleted = GETDATE()
			WHERE [TableSchema] = @SchemaN
			AND [TableName] = @TableN
			AND [DatabaseName] = @DBName
			AND [TimeStarted] = @TimeStartedTemp;

				IF @error <> '0'
				BEGIN
				SET @Mailbody = 
				'DBCC Check found error on '+@@SERVERNAME+' when running command:
				'+ @CurrentDBIntegrityCmd +'
				Run the following to investigate error:
				SELECT * FROM msdb.dbo.D2LDBIntegrityCheckHistory
				where error <> ''0'''
				EXEC msdb.dbo.sp_send_dbmail
				@recipients =N'D2LDBA@desire2learn.com',
				@subject = 'DBCC Check Found Error',
				--@body_format ='HTML',
				@body = @Mailbody,
				@profile_name ='SQL Admin'
				END

		END TRY
	
		BEGIN CATCH

			UPDATE msdb.dbo.D2LDBIntegrityCheckHistory
			SET Error = ERROR_MESSAGE(), TimeCompleted = GETDATE()
			WHERE [TableSchema] = @SchemaN
			AND [TableName] = @TableN
			AND [DatabaseName] = @DBName
			AND [TimeStarted] = @TimeStartedTemp;

			IF ERROR_MESSAGE() <> '0'
				BEGIN
				SET @Mailbody = 
				'DBCC Check found error on '+@@SERVERNAME+' when running command:
				'+ @CurrentDBIntegrityCmd +'
				Run the following to investigate error:
				SELECT * FROM msdb.dbo.D2LDBIntegrityCheckHistory
				where error <> ''0'''
				EXEC msdb.dbo.sp_send_dbmail
				@recipients =N'D2LDBA@desire2learn.com',
				@subject = 'DBCC Check Found Error',
				--@body_format ='HTML',
				@body = @Mailbody,
				@profile_name ='SQL Admin'
				END

		END CATCH


	FETCH NEXT FROM cDBIntegrity INTO @TableN, @SchemaN;

END
		
CLOSE cDBIntegrity
DEALLOCATE cDBIntegrity


GOTO SUCCESS_EXIT_HERE

ERROR_EXIT_HERE:
SELECT @ErrorMessage = 'The DB called "' + @DBName + '" doesn''t exist!'
RAISERROR (@ErrorMessage, 10, 1) WITH LOG, NOWAIT --informational only

SUCCESS_EXIT_HERE:
SELECT @ErrorMessage = 'All done!'
RAISERROR (@ErrorMessage, 10, 1) WITH LOG, NOWAIT --informational only





GO

