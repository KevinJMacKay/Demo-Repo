/*
.\SQLWrapper_DBInfo_AWS.ps1 -SQLServers 
Test
us04tsql002a,us04tsql002b,us04tsql002c,us04tsql002d,us04tsql003a,us04tsql003b,us04tsql004a 
clus 05
US04PSQL005A,US04PSQL005B,US04PSQL005C,US04PSQL005D,US04RSQL005A



-Query "SELECT top 1 [TimeCompleted] FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory] ORDER BY [TimeCompleted] desc"




*/
sp_whoisactive

select * FROM SYS.MASTER_FILES

SELECT *
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [TimeStarted]  is null
And [TimeCompleted] is null


SELECT *
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [TimeCompleted] > Getdate()-10
--AND databasename = 'dmutest'
ORDER BY [TimeCompleted] desc

SELECT DatabaseName,count(DatabaseName) ObjectCount, convert(char(11),TimeCompleted) RunDate
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [TimeCompleted] > Getdate()-7
group by DatabaseName , convert(char(11),TimeCompleted)
order by convert(char(11),TimeCompleted) desc


SELECT DatabaseName, TableName, DateDiff(MINUTE,TimeStarted,TimeCompleted),TimeStarted,TimeCompleted
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE 1=1
--AND [TimeCompleted] > Getdate()-30
AND DateDiff(SECOND,TimeStarted,TimeCompleted) > 50
ORDER BY DateDiff(SECOND,TimeStarted,TimeCompleted) desc

select count(*) from tbr..mail

SELECT min([timeStarted]),max([TimeCompleted]),datediff(minute,min([timeStarted]),max([TimeCompleted]))
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [timeStarted] > '2019-03-06 09:00:00'

SELECT Count(*)
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [timeStarted] > '2019-03-07 13:07:00'
--WHERE [timeStarted] > '2019-03-06 00:00:00' AND 
--[TimeCompleted] < '2019-03-06 09:00:00'



SELECT min([timeStarted]),max([TimeCompleted]),datediff(minute,min([timeStarted]),max([TimeCompleted]))
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
WHERE [timeStarted] > '2019-03-06 00:00:00' AND 
[TimeCompleted] < '2019-03-06 09:00:00'

