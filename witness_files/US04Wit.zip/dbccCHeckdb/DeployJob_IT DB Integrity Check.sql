USE [msdb]
GO

/****** Object:  Job [IT DB Integrity Check]    Script Date: 3/20/2019 1:11:50 PM ******/
EXEC msdb.dbo.sp_delete_job @job_name=N'IT DB Integrity Check', @delete_unused_schedule=1
GO

/****** Object:  Job [IT DB Integrity Check]    Script Date: 3/20/2019 1:11:50 PM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/20/2019 1:11:50 PM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'IT DB Integrity Check', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Create Table - D2LDBIntegrityCheckHistory]    Script Date: 3/20/2019 1:11:50 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Create Table - D2LDBIntegrityCheckHistory', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (OBJECT_ID(''msdb.dbo.D2LDBIntegrityCheckHistory'') IS NULL)
BEGIN

	CREATE TABLE msdb.dbo.D2LDBIntegrityCheckHistory
	( 
		[DatabaseName] sysname, 
		[DatabaseId] int, 
		[TableName] sysname NULL,
		[TableSchema] sysname NULL, 
		[Action] nvarchar(max) NULL,
		[Error] nvarchar(max) NULL,
		[TimeStarted] DATETIME NULL,
		[TimeCompleted] DATETIME NULL
	) 
END;

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N''[dbo].[D2LDBIntegrityCheckHistory]'') AND name = N''IX_DBN_TabN_TabS_TimeC'')
CREATE NONCLUSTERED INDEX [IX_DBN_TabN_TabS_TimeC] ON [dbo].[D2LDBIntegrityCheckHistory]
(
	[DatabaseName] ASC,
	[TableName] ASC,
	[TableSchema] ASC,
	[TimeCompleted] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO



IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N''[dbo].[D2LDBIntegrityCheckHistory]'') AND name = N''IX_DBN_TabN_TabS_TimeS'')
CREATE NONCLUSTERED INDEX [IX_DBN_TabN_TabS_TimeS] ON [dbo].[D2LDBIntegrityCheckHistory]
(
	[DatabaseName] ASC,
	[TableName] ASC,
	[TableSchema] ASC,
	[TimeStarted] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO

', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run - IT DB Integrity Check]    Script Date: 3/20/2019 1:11:50 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run - IT DB Integrity Check', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON

DECLARE @command NVARCHAR(MAX)
DECLARE @command_temp AS NVARCHAR(MAX)
DECLARE @selectDB AS NVARCHAR(128) = ''''
DECLARE @ProcessStartTime AS NVARCHAR(128)
DECLARE @ProcessDuration varchar(3) 

Select @ProcessStartTime =  CONVERT(nvarchar(30), Getdate(), 121)
Select @ProcessDuration = ''150''

--Print @ProcessStartTime
--Print @ProcessDuration

USE master

IF (OBJECT_ID(''tempdb..#ALL_DBS'') IS NOT NULL)
DROP TABLE #ALL_DBS

CREATE TABLE #ALL_DBS
(
	[priority] int identity (1,1),
	[name] sysname
)

--Start with last incomplete DB before going back to the beginning of the list
INSERT INTO #ALL_DBS (name)
SELECT [name]
FROM master.sys.databases 
WHERE 
database_id > 4
AND
[is_read_only] <> 1
AND 
[state_desc] = ''ONLINE''
AND
-----------
name in
(select DISTINCT ADC.database_name 
from 
sys.availability_databases_cluster ADC 
inner join 
sys.dm_hadr_availability_replica_states HARS 
on ADC.group_id = HARS.group_id 
inner join sys.availability_group_listeners AGL 
on HARS.group_id = AGL.group_id 
where is_local = ''TRUE'' 
and HARS.role_desc = ''PRIMARY'' 
UNION
select DISTINCT name 
from master.sys.databases 
where name not in
(
select database_name from
sys.availability_databases_cluster ADC 
)
)
---------
AND
[name] >= (SELECT ISNULL(MAX([DatabaseName]), ''-1'')
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
	WHERE [TimeCompleted] IS NULL)
ORDER BY [name]

--Now add any DBs that come before the "start point DB" which didn''t get reindexed today
INSERT INTO #ALL_DBS (name)
SELECT top 100 [name]
FROM master.sys.databases 
WHERE 
database_id > 4
AND
[is_read_only] <> 1
AND 
[state_desc] = ''ONLINE''
AND
[name] < (SELECT ISNULL(MAX([DatabaseName]), ''-1'')
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
	WHERE [TimeCompleted] IS NULL)
AND
-----------
name in
(select DISTINCT ADC.database_name 
from 
sys.availability_databases_cluster ADC 
inner join 
sys.dm_hadr_availability_replica_states HARS 
on ADC.group_id = HARS.group_id 
inner join sys.availability_group_listeners AGL 
on HARS.group_id = AGL.group_id 
where is_local = ''TRUE'' 
and HARS.role_desc = ''PRIMARY'' 
UNION
select DISTINCT name 
from master.sys.databases 
where name not in
(
select database_name from
sys.availability_databases_cluster ADC 
)
)
---------
AND
[name] not in
(
	SELECT distinct [DatabaseName]
	FROM [msdb].[dbo].[D2LDBIntegrityCheckHistory]
	WHERE 
	DAY([TimeCompleted]) = DAY(GETDATE())
	AND
	MONTH([TimeCompleted]) = MONTH(GETDATE())
	AND
	YEAR([TimeCompleted]) = YEAR(GETDATE())
)
ORDER BY [name]

--select count(*) from #all_dbs

USE msdb

WHILE (SELECT COUNT(*) FROM #ALL_DBS) > 0 AND (datediff(minute,@ProcessStartTime,getdate())) < @ProcessDuration
BEGIN
	--Select''Start inner Loop''
	SELECT @selectdb = (SELECT TOP 1 name FROM #ALL_DBS ORDER BY [priority])

	SELECT @command_temp = ''USE msdb

	SET DEADLOCK_PRIORITY HIGH

	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;
	DECLARE @StartTime AS DATETIME
	DECLARE @EndTime AS DATETIME

	BEGIN TRY
		
		SET @StartTime = GETDATE()
		
		EXEC [dbo].[cs_CUSTOM_D2L_DBIntegrityCheck_v2.1] @DBName = '''''' +  @selectdb + '''''', @JobName = ''''IT DBIntegrityCheck'''',@ProcessStartTime = ''''''+@ProcessStartTime+'''''', @ProcessDuration = ''''''+@ProcessDuration+''''''
				
		SET @EndTime = GETDATE()

		SELECT @ErrorMessage = ''''dbo.cs_CUSTOM_D2L_DBIntegrityCheck_v2,1 succeeded on '' + @selectdb + '''''' + '''' (Execution time: '''' + CAST(DATEDIFF(second, @StartTime, @EndTime) AS NVARCHAR(100)) + '''' seconds)''''		

		RAISERROR (@ErrorMessage, 10, 1) WITH LOG, NOWAIT --informational only

	END TRY
	BEGIN CATCH

		SELECT @ErrorMessage = ''''Following error occured on database "'' + @selectdb + ''": ''''

		SELECT 
			@ErrorMessage = @ErrorMessage + ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();
	        
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState) WITH LOG, NOWAIT;
	
	END CATCH
	''
	--PRINT @command_temp
	EXEC(@command_temp)
		
	DELETE FROM #ALL_DBS WHERE [name] = @selectdb
END


DROP TABLE #ALL_DBS


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cleanup History]    Script Date: 3/20/2019 1:11:51 PM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cleanup History', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
declare @cnt int
declare @days int
Set @cnt = 0
Set @days = 90

IF EXISTS(select top 1 * FROM msdb.dbo.D2LDBIntegrityCheckHistory
where [TimeStarted] < getdate()-@days)
BEGIN

Set @cnt =(select count(*) FROM msdb.dbo.D2LDBIntegrityCheckHistory
			where [TimeStarted] < getdate()-@days)

delete FROM msdb.dbo.D2LDBIntegrityCheckHistory
where [TimeStarted] < getdate()-@days

Print ''Cleanup count: ''+convert(varchar(25),@cnt)

END', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160518, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=235959, 
		@schedule_uid=N'c97e0931-efe3-43ac-9d08-6dfa7aa21913'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


