--Unique Logins (across all orgs) today

select OrgShortName, COUNT(*) AS Total_Unique
from (SELECT OO.OrgShortName, COUNT(*) AS Total
    FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
        INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
        ON UL.OrgId = OO.OrgId
    WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
        AND UL.AttemptDate >= cast (getdate() AS date)
    GROUP BY OO.OrgShortName, UL.UserId
) TT
group by OrgShortName

--Unique Logins (across all orgs) broken down by year, month and day

select TT.[Year], TT.[Month], TT.[Day], COUNT(*) AS Total_Unique
from (SELECT UL.UserId, YEAR(UL.AttemptDate)  AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate)AS [Day], COUNT(*) AS Total
    FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
        INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
        ON UL.OrgId = OO.OrgId
    WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
        --AND UL.AttemptDate >= cast (getdate() AS date) --Today only
        AND UL.AttemptDate between '2020-09-01' AND '2020-09-30'  -- Specific date range
    GROUP BY UL.UserId,YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate)) TT
group by TT.[Year], TT.[Month], TT.[Day]
ORDER BY 1,2,3 desc
--ORDER BY 4 desc

--All logins (across all orgs) broken down by year, month, day

SELECT YEAR(UL.AttemptDate) AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate) AS [Day], COUNT(*) AS Total_Login
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
    INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
    ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
    AND UL.AttemptDate >= cast (getdate() AS date) --Today only
    --AND UL.AttemptDate between '2020-08-23' AND '2020-08-26'  -- Specific date range
GROUP BY  YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate)
ORDER BY 1,2,3 desc


--All logins (across all orgs) broken down by year, month, day, hour

SELECT YEAR(UL.AttemptDate) AS [Year], MONTH(UL.AttemptDate) AS [Month], DAY(UL.AttemptDate) AS [Day], datepart(HH,UL.AttemptDate) AS [Hour], COUNT(*) AS Total_Login
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
    INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK)
    ON UL.OrgId = OO.OrgId
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
    AND UL.AttemptDate >= cast (getdate() AS date) --Today only
    --AND UL.AttemptDate between '2020-08-23' AND '2020-08-26'  -- Specific date range
GROUP BY  YEAR(UL.AttemptDate), MONTH(UL.AttemptDate), DAY(UL.AttemptDate),datepart(HH,UL.AttemptDate)
ORDER BY 1,2,3 desc, 4 desc

-- Total Logins by Usertype over date range

SELECT rd.RoleName, vu.orgroleid, count(vu.orgroleid)AS LoginCount, CAST(UL.AttemptDate as Date) AS Date
FROM USER_LOGINATTEMPTS UL WITH (NOLOCK)
    INNER JOIN ORG_ORGANIZATIONS OO WITH (NOLOCK) ON UL.OrgId = OO.OrgId
    INNER JOIN vusers VU WITH (NOLOCK) ON UL.userid = vu.userID AND UL.OrgId = vu.OrgId
    INNER JOIN role_details RD WITH (NOLOCK) ON rd.roleid = vu.orgroleid
WHERE UL.StatusTypeId = 0 AND OO.OrgId > 0
    --AND UL.AttemptDate >= cast (getdate() AS date) --Today only
    AND UL.AttemptDate between '2020-08-23' AND '2020-08-25'  -- Specific date range
--AND vu.orgroleid in(106,108,112) --Specific role i.e. Student, Learning Coach, Teacher
GROUP BY  rd.RoleName, vu.orgroleid,CAST(UL.AttemptDate as Date)
ORDER BY 4 desc,3 desc

