SELECT[plan_handle] , [d].[Name] , [cp].[refcounts] , [cp].[usecounts] , [cp].[objtype] , [st].[dbid] , [st].[objectid] , [st].[text] , [qp].[query_plan]FROM sys.dm_exec_cached_plans cpCROSS APPLY sys.dm_exec_sql_text ( cp.plan_handle ) stCROSS APPLY sys.dm_exec_query_plan ( cp.plan_handle ) qpINNER JOIN sys.databases d on [d].[database_id] = [st].[dbid]where [st].[text] like '%s_REQUEST_LOGGING_USERS_PATHS_DAYS_Update%'option (RECOMPILE)--usgxDBCC FREEPROCCACHE (0x05000B009794241AF05BD9B60402000001000000000000000000000000000000000000000000000000000000)
--usgq
DBCC FREEPROCCACHE (0x05000600B177290520A7927FD002000001000000000000000000000000000000000000000000000000000000)
--above did not work for USGX-USGQ
--Had to run Alter on s_REQUEST_LOGGING_USERS_PATHS_DAYS_Update to force new plan
