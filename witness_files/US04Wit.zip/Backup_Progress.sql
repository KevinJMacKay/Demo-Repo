/*
sp_WhoIsActive

reads	writes	physical_reads
      1,244,131,810	          6,027,509	          9,990,471
      1,244,131,910	          6,027,527	          9,990,471
	  1,247,030,110	          6,387,321	         10,029,490
*/

SELECT session_id as SPID, command, a.text AS Query, start_time, percent_complete, dateadd(second,estimated_completion_time/1000, getdate()) as estimated_completion_time 
FROM sys.dm_exec_requests r CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) a 
WHERE r.command in ('BACKUP DATABASE','RESTORE DATABASE','BACKUP LOG')


